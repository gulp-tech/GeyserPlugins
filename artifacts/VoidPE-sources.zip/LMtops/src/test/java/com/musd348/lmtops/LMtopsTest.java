package com.musd348.lmtops;

import org.mockbukkit.mockbukkit.MockBukkit;
import org.mockbukkit.mockbukkit.ServerMock;
import org.bukkit.Material;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryAction;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryType;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.io.TempDir;
import java.nio.file.*;
import java.util.UUID;
import java.util.logging.Logger;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class LMtopsTest {
    @TempDir Path dataFolder;
    @Test void newDataIsCreatedAndExistingValuesSurvive() throws Exception {
        LMtops plugin = mock(LMtops.class);
        when(plugin.getDataFolder()).thenReturn(dataFolder.toFile());
        when(plugin.getLogger()).thenReturn(Logger.getAnonymousLogger());
        UUID id = UUID.randomUUID();
        DataManager d = new DataManager(plugin);
        d.addStat(id, "kills", 7);
        d.addStat(id, "blocks", 12);
        d.saveAll();
        assertTrue(Files.exists(dataFolder.resolve("playerdata.yml")));
        DataManager loaded = new DataManager(plugin);
        assertEquals(7, loaded.getStat(id, "kills"));
        loaded.addStat(id, "deaths", 2);
        loaded.saveAll();
        DataManager again = new DataManager(plugin);
        assertEquals(7, again.getStat(id, "kills"));
        assertEquals(12, again.getStat(id, "blocks"));
        assertEquals(2, again.getStat(id, "deaths"));
    }
    @Test void malformedDataIsNotReplaced() throws Exception {
        LMtops plugin = mock(LMtops.class);
        when(plugin.getDataFolder()).thenReturn(dataFolder.toFile());
        Path file = dataFolder.resolve("playerdata.yml");
        Files.writeString(file, "broken: [unterminated");
        assertThrows(IllegalStateException.class, () -> new DataManager(plugin));
        assertEquals("broken: [unterminated", Files.readString(file));
    }
    @Test void actualPlayerPointsLeaderboardPreservesNamesAndValues() {
        var api = mock(org.black_ixx.playerpoints.PlayerPointsAPI.class);
        var player = mock(org.black_ixx.playerpoints.models.SortedPlayer.class);
        UUID id = UUID.randomUUID();
        when(player.getUniqueId()).thenReturn(id);
        when(player.getUsername()).thenReturn("BedrockPlayer");
        when(player.getPoints()).thenReturn(1234);
        when(api.getTopSortedPoints(10)).thenReturn(java.util.List.of(player));
        assertEquals(java.util.List.of(new TopEntry(id, "BedrockPlayer", 1234)), TopManager.readPoints(api, 10));
        verify(api).getTopSortedPoints(10);
    }
    @Test void cancelledBlockBreakDoesNotIncreaseStatistics() {
        ServerMock server = MockBukkit.mock();
        try {
            MockBukkit.createMockPlugin("Vault");
            LMtops plugin = MockBukkit.load(LMtops.class);
            var world = server.addSimpleWorld("world");
            var player = server.addPlayer();
            var event = new org.bukkit.event.block.BlockBreakEvent(world.getBlockAt(1, 64, 1), player);
            event.setCancelled(true);
            server.getPluginManager().callEvent(event);
            assertEquals(0, plugin.getDataManager().getStat(player.getUniqueId(), "blocks"));
            event = new org.bukkit.event.block.BlockBreakEvent(world.getBlockAt(1, 64, 1), player);
            server.getPluginManager().callEvent(event);
            assertEquals(1, plugin.getDataManager().getStat(player.getUniqueId(), "blocks"));
        } finally { MockBukkit.unmock(); }
    }
    @Test void cachedLeaderboardIncludesTrackedPlayers() {
        ServerMock server = MockBukkit.mock();
        try {
            MockBukkit.createMockPlugin("Vault");
            LMtops plugin = MockBukkit.load(LMtops.class);
            var player = server.addPlayer();
            plugin.getDataManager().addStat(player.getUniqueId(), "kills", 8);
            plugin.getTopManager().stop();
            plugin.getTopManager().updateCache();
            server.getScheduler().performTicks(5);
            assertTrue(plugin.getTopManager().getTopKills().stream()
                    .anyMatch(e -> e.uuid().equals(player.getUniqueId()) && e.value() == 8));
        } finally { MockBukkit.unmock(); }
    }
    @SuppressWarnings("unchecked")
    @Test void onlinePlaytimeFlushDoesNotDoubleCount() throws Exception {
        ServerMock server = MockBukkit.mock();
        try {
            MockBukkit.createMockPlugin("Vault");
            LMtops plugin = MockBukkit.load(LMtops.class);
            var player = server.addPlayer();
            PlayerListener listener = new PlayerListener(plugin);
            var field = PlayerListener.class.getDeclaredField("joinTimes"); field.setAccessible(true);
            var times = (java.util.Map<UUID, Long>) field.get(listener);
            times.put(player.getUniqueId(), System.currentTimeMillis() - 65000L);
            listener.flushOnlineTime();
            long first = plugin.getDataManager().getStat(player.getUniqueId(), "playtime");
            assertTrue(first >= 65 && first <= 66);
            listener.flushOnlineTime();
            long second = plugin.getDataManager().getStat(player.getUniqueId(), "playtime");
            assertTrue(second >= first && second <= first + 1);
        } finally { MockBukkit.unmock(); }
    }
    @Test void menuItemsCannotBeTakenAndClickNavigates() {
        ServerMock server = MockBukkit.mock();
        try {
            MockBukkit.createMockPlugin("Vault");
            LMtops plugin = MockBukkit.load(LMtops.class);
            var player = server.addPlayer();
            plugin.getTopGUI().openMainMenu(player);
            var view = player.getOpenInventory();
            assertEquals(Material.DIAMOND_SWORD, view.getTopInventory().getItem(12).getType());
            var click = new InventoryClickEvent(view, InventoryType.SlotType.CONTAINER, 12, ClickType.LEFT, InventoryAction.PICKUP_ALL);
            plugin.getTopGUI().onClick(click);
            assertTrue(click.isCancelled());
            server.getScheduler().performOneTick();
            assertEquals(54, player.getOpenInventory().getTopInventory().getSize());
            var top = player.getOpenInventory();
            var back = new InventoryClickEvent(top, InventoryType.SlotType.CONTAINER, 49, ClickType.LEFT, InventoryAction.PICKUP_ALL);
            plugin.getTopGUI().onClick(back);
            assertTrue(back.isCancelled());
            server.getScheduler().performOneTick();
            assertEquals(27, player.getOpenInventory().getTopInventory().getSize());
        } finally { MockBukkit.unmock(); }
    }
}
