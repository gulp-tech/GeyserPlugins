# Purpurbedrock `26.2` (FINAL)

**Purpurbedrock `26.2`** — автономное высокопроизводительное серверное ядро на базе **Purpur `26.2` (`STABLE`)**, созданное специально для **Minecraft: Bedrock Edition с полной мульти-версией `1.21.0 — 26.60` (`v685 — v2225`)** и **100% нативной поддержкой всех Java-плагинов и сундучных Java-меню** — без зависимости от внешних плагинов GeyserMC или облачных API.

## Скачать готовое ядро

- **Готовый JAR (`26.2`)**: [`purpurbedrock-26.2.jar`](https://github.com/gulp-tech/Purpurbedrock/releases/download/v26.2.0-bedrock/purpurbedrock-26.2.jar)
- **Скрипт разблокировки LAN для Windows 10/11**: [`unlock-windows-lan.bat`](https://github.com/gulp-tech/Purpurbedrock/releases/download/v26.2.0-bedrock/unlock-windows-lan.bat) *(также создаётся автоматически при первом запуске ядра)*

---

## Что реализовано внутри ядра Purpurbedrock `26.2`

1. **Стабильная версия `26.2` (`26.2-R0.1-SNAPSHOT`) — работают все плагины**
   - Полная совместимость с `DeluxeMenus`, `packetevents 2.13.0`, `DecentHolograms`, `VoidItems`, `VoidTab`, `AuthMe`, `WorldEdit`, `WorldGuard`, `LuckPerms`, `Vault`, `PlaceholderAPI` и любыми Bukkit/Spigot/Paper/Purpur плагинами.
   - Встроенная защита `SimpleHelpMap` от сбоев `HelpTopicFactory` у кастомных плагинов.

2. **Полная независимость от внешнего GeyserMC и мгновенный вход**
   - Протокольный движок Bedrock `26.2` вшит напрямую в `purpur-server` (никаких папок `plugins/Geyser-Spigot`, никаких обращений к серверам GeyserMC/Mojang/bStats).
   - Языковой кэш встроен прямо в JAR — **первый и последующие запуски проходят мгновенно**, а игроки заходят на сервер **сразу без зависания «Поиск сервера / Загрузка ресурсов»** (`auth-type: offline`, `above-bedrock-nether-building: false`, `forward-player-ping: true`).
   - Прямой вход с Java Edition автоматически заблокирован на уровне `ServerHandshakePacketListenerImpl` / `ServerLoginPacketListenerImpl`.

3. **100% поддержка Java-меню (`9x1`–`9x6`)**
   - Нативная обработка кликов, отмены переноса предметов и мгновенных переходов между подменю прямо в `ServerGamePacketListenerImpl` + `JavaChestMenuManager` (`DeluxeMenus`, `ChestCommands`, любые кастомные `InventoryHolder` GUI открываются у игроков Bedrock как полноценные сундучные меню без фантомных предметов на курсоре).
   - Проверить встроенное Java-меню прямо из коробки: `/purpurbedrock menu` (или `/pb menu`).

4. **Видимость в локальной сети (LAN / вкладка «Миры») на Bedrock `26.40+`**
   - Включён двойной транспорт `transport: both`:
     - **UDP/TCP `19132`** — RakNet + HTTP/WebSocket сигналинг NetherNet
     - **UDP `19133` / `19134`** — WebRTC медиа-канал NetherNet
     - **UDP `7551`** — встроенный **`NetherNetDiscoverySignaling`**, благодаря которому новый интерфейс Bedrock (`Миры`) автоматически находит локальный сервер каждые 2 секунды!

5. **Встроенный Anti-Xray специально под Bedrock (`EngineMode.HIDE`)**
   - Автоматически включён во всех мирах (`BedrockAntiXrayHelper` + дефолты Paper `WorldConfiguration`):
     - **Обычный мир (`Y <= 320`, `lava-obscures: true`)**: скрывает `diamond_ore`, `deepslate_diamond_ore`, `emerald_ore`, `gold_ore`, `iron_ore`, `copper_ore`, `lapis_ore`, `redstone_ore`, `coal_ore` и `raw_iron_block` / `raw_copper_block`, заменяя несоприкасающиеся с воздухом жилы на камень/глубинный сланец.
     - **Незер (`Y <= 128`, `lava-obscures: true`)**: скрывает **`ancient_debris`** (древние обломки / незерит), `nether_gold_ore` и `nether_quartz_ore`, заменяя их на незерак.
   - Режим `HIDE` даёт **0 фейковых руд**, поэтому **не просаживает FPS на слабых телефонах** и практически не нагружает CPU сервера.

6. **Ноль флагов движения (`BedrockMovementGuard`) и ноль фантомных блоков (`BedrockGhostBlockResync`)**
   - Устранены ложные откаты `moved wrongly!` / `moved too quickly!` на лестницах, полублоках, коврах, воде и при спид-бриджинге Bedrock.
   - Повышен порог `PacketLimiter` (`1500 pkt / 7s`), `checkLimit` (`24` блока в бурсте для спид-бриджинга) и `bedrockMaxFloatingTicks` (`200`), а повторные `AcceptTeleportationPacket` по UDP/WebRTC больше не кикают игрока.
   - При любой отмене постановки или ломания блока (`WorldGuard`, спавн-протект, граница дистанции `6.75` блока, застревание `CLIPPED_INTO_BLOCK`) сервер мгновенно отправляет точную синхронизацию блока и всех 6 соседних граней + контрольный ресинк на следующем тике — **фантомных блоков нет вообще**.

7. **Боёвка Bedrock Edition (`1.8` без КД) + высокая оптимизация TPS**
   - Отключён кулдаун удара 1.9 (`attackStrengthTicker = 9999`), таблица урона мечей/топоров как на Bedrock, криты в спринте, сохранение спринта в комбо, мгновенный блок щитом + щит на шифте, откидывание снежками и яйцами.
   - Из коробки включены **Alternate Current Redstone** (в 5–10 раз быстрее ванильного редстоуна) и **`use-alternate-keepalive: true`**.

8. **Полная мульти-версия Bedrock `1.21.0 — 26.60` (`v685 — v2225`) + чистые диалоги и консоль**
   - Вшиты все **24 протокольных кодека** (`v685`, `v686`, `v712`, `v729`, `v748`, `v766`, `v776`, `v786`, `v800`, `v818`, `v819`, `v827`, `v844`, `v859`, `v860`, `v898`, `v924`, `v944`, `v975`, `v1001`, `v2168`, `v2169`, `v2193`, `v2225`) и **64 исторических палитр блоков/предметов/тегов/компонентов** с автоматическим маппингом новых блоков и предметов `26.2` на старых клиентах (`1.21.0–26.45`) без багов, киков и крашей.
   - Полностью убрано окно ожидания **`gui.waitingForResponse.title`** («Идёт ожидание нового диалога от сервера...») при переходах и закрытии Java Dialog-окон.
   - Устранён ложный вывод `[ERROR]: [STDERR] [sun.instrument.InstrumentationImpl] WARNING: A Java agent has been loaded dynamically` в `SysoutCatcher` при динамической загрузке ByteBuddy-агента плагинами на Java 25.

9. **Безупречная прогрузка чанков на Bedrock (`ChunkUtils.ensureChunkPublished` + Moonrise Sync)**
   - Устранены пустые/невидимые чанки при входе, стоянии на спавне, быстрых полётах, любых телепортациях (`/tp`, `/spawn`, `/warp`, `/rtp`, `AuthMe`), переходах между мирами и смене дальности прорисовки в настройках клиента Bedrock.
   - Движок гарантированно обновляет `NetworkChunkPublisherUpdatePacket` (с защитой высоты `Y` после смены измерения и буферным радиусом) **до** отправки каждого `LevelChunkPacket`, поэтому клиент Bedrock никогда не отбрасывает пришедшие чанки.
   - На стороне Moonrise (`Paper 26.2`) отключено занижение радиуса мобильными клиентами (`auto-config-send-distance: false`, убран начальный дефолт `2` чанка на стадии `CONFIGURATION`) и увеличена скорость отдачи чанков (`120 send/s`, `200 load/s`, `8 concurrent`, `batch=32`).

10. **Встроенные PlaceholderAPI-плейсхолдеры прямо из ядра (`%purpurbedrock_*%`)**
    - Автоматически регистрируются в `PlaceholderAPI` прямо из ядра (`persist = true`, сохраняются при `/papi reload`) без установки дополнительных плагинов или eCloud-расширений — сразу готовы для **`VoidTab`**, **скорбордов** и **`DeluxeMenus`**:
      - `%purpurbedrock_device%` — устройство игрока (`📱 Телефон`, `🖥 ПК`, `🎮 Геймпад`, `PlayStation`, `Xbox`, `Switch`)
      - `%purpurbedrock_input%` — режим управления в реальном времени (`Сенсор`, `Клавиатура+Мышь`, `Контроллер`)
      - `%purpurbedrock_version%` — точная версия клиента Bedrock игрока (например, `1.21.50` или `26.60`)
      - `%purpurbedrock_ping%` — реальный RTT пинг RakNet / NetherNet WebRTC в мс *(также пробрасывается напрямую в `Player#getPing()`)*
      - Дополнительные плейсхолдеры: `%purpurbedrock_ping_colored%`, `%purpurbedrock_os%`, `%purpurbedrock_protocol%`, `%purpurbedrock_ui%`, `%purpurbedrock_xuid%`, `%purpurbedrock_is_bedrock%`.

11. **Защита FPS телефона при появлении других игроков**
    - На Android/iOS и консолях другие игроки отображаются с лёгким ванильным скином `64×64` без тяжёлой persona-геометрии и плащей, которые могут блокировать рендер мобильного клиента на 10–20 секунд.
    - Собственный скин игрока всегда сохраняется; Windows-клиенты продолжают получать полные скины. Настройка: `bedrock.performance.safe-remote-player-skins: true`.

12. **Адаптивная оптимизация NPC без отключения логики**
    - Citizens подключается через безопасную reflection-интеграцию без compile-time зависимости; также распознаются FancyNPCs, ZNPCs и пользовательские NPC с обычными metadata/scoreboard-тегами.
    - Для каждого Bedrock-игрока применяется профиль `SAFE / BALANCED / HIGH` по устройству, RTT и TPS: ядро ограничивает только ненужную сетевую видимость дальних NPC, не удаляя сущности и не отключая AI, трейты, навигацию или Java-плагины.
    - NPC в радиусе взаимодействия всегда остаются видимыми; сканирование мира выполняется раз в 100 тиков, а `hide/show` — только при реальном изменении состояния.

---

## Быстрый запуск (Рекомендуемые флаги Aikars / G1GC + Java 25)

Удалите `Geyser-Spigot.jar` из папки `plugins/` (он больше **не нужен**!) и запустите сервер:

```bash
java -Xms4G -Xmx4G -XX:+EnableDynamicAgentLoading -XX:+UseG1GC -XX:+ParallelRefProcEnabled \
  -XX:MaxGCPauseMillis=100 -XX:+UnlockExperimentalVMOptions -XX:+DisableExplicitGC \
  -XX:G1NewSizePercent=30 -XX:G1MaxNewSizePercent=40 -XX:G1HeapRegionSize=8M \
  -XX:G1ReservePercent=20 -XX:InitiatingHeapOccupancyPercent=15 \
  -jar purpurbedrock-26.2.jar --nogui
```

### Как увидеть локальный сервер на том же ПК с Windows 10 / 11

Windows по умолчанию блокирует локальные UDP-пакеты для UWP/GDK-приложения Minecraft Bedrock (Loopback Isolation), поэтому сервер на этом же компьютере не отображается во вкладке **«Миры»** и не пускает по `127.0.0.1`, пока не снято ограничение.

**Решение в 1 клик:** нажмите правой кнопкой мыши по автоматически созданному файлу **`unlock-windows-lan.bat`** → **«Запуск от имени администратора»** (достаточно сделать **один раз**):

```bat
CheckNetIsolation LoopbackExempt -a -n="Microsoft.MinecraftUWP_8wekyb3d8bbwe"
```

После этого сервер сразу появится во вкладке **«Миры» (LAN)**, а также будет доступен напрямую по `127.0.0.1 : 19132` или локальному IP вашего ПК (`192.168.x.x : 19132`).

---

## Управление и конфигурация

- **Папка `bedrock/`** *(создаётся автоматически в корне сервера)*:
  - **`bedrock/cache/`** — кэш Bedrock:
    - **`bedrock/cache/player_skulls/`** — PNG-текстуры 3D-голов плагина **`HeadDatabase`** *(автоматически подхватываются ядром, сохраняются при перезапусках и собираются в `bedrock/cache/player_skulls.mcpack`)*
    - `bedrock/cache/images/`, `bedrock/cache/default_player_skins/`, `bedrock/cache/remote_packs/` и `GeyserIntegratedPack.mcpack`
  - **`bedrock/custom_mappings/`** — кастомные `.json` маппинги предметов, блоков, стеклянных панелей и голов (`Geyser-panes-mapping.json`, `Geyser-spheres-mapping.json`, `migrated-custom-skulls.json` и др.)
  - **`bedrock/extensions/`** — расширения Bedrock-движка (`GeyserJavaGlowing`, `VoidAnvilExtension` и др.)
  - **`bedrock/packs/`** — ресурспаки `.mcpack` и `.zip` (`VoidResourcePack.mcpack`, `VoidSpheres.mcpack`, `GeyserEvent-Pack.mcpack` и др.)
  - *Если в сборке осталась старая папка `plugins/Geyser-Spigot/`, при первом запуске ядро автоматически скопирует оттуда все недостающие файлы (включая `cache/player_skulls`) в `bedrock/`.*
- **`bedrock.yml`** *(в корне сервера)* — порт (`19132`), `webrtc-port` (`19133`), `lan-discovery` (`true`), `data-folder` (`bedrock`), `motd` и `max-players`.
- **`purpur.yml`** (`settings.bedrock.*` и `world-settings.default.gameplay-mechanics.bedrock-combat.*`) — тонкая настройка гейткипера, Anti-Xray, защиты от флагов, защиты от фантомных блоков, Java-меню, боёвки и авто-адаптации чанков/плагинов `26.3 -> 26.2`.
  - NPC: `bedrock.npc-optimization.enabled`, `update-interval-ticks`, профили `safe/balanced/high` (`distance`, `max-visible`) и `server-pressure-tps`. По умолчанию: `10` тиков; `32/12`, `48/24`, `64/40`; порог `18.5 TPS`.
- **Команда `/purpurbedrock` (`/pb`)**:
  - `/pb status` — сводка состояния ядра, TPS, чанков, PAPI, папок `bedrock/`, защиты от флагов/фантомных блоков и протокола
  - `/pb menu` — открыть встроенное интерактивное Java-меню диагностического центра (`27` слотов)
  - `/pb chunks [игрок]` — принудительно синхронизировать область прогрузки чанков игрока
  - `/pb papi [игрок]` — проверить статус и значения встроенных плейсхолдеров `%purpurbedrock_*%`
  - `/pb antixray` — проверить статус Bedrock Anti-Xray по всем мирам

---

## Отдельный адаптивный античит: `PurpurBedrockAC 26.2` (`purpurbedrock-anticheat/`)

В репозитории в полностью независимом модуле **`purpurbedrock-anticheat/`** (не затрагивающем код ядра) собирается готовый античит **`PurpurBedrockAC-26.2.jar`** (`plugins/PurpurBedrockAC-26.2.jar`):
- **Адаптивный спящий режим (`DORMANT → SLEEPING → WAKING → AWAKE`)**: спит при спокойной игре (`0% CPU`) и плавно, не спеша просыпается только для подозрительного игрока.
- **13 проверок без ложных флагов на Bedrock** (учитывает `Сенсор` / `ПК` / `Геймпад`, спид-бриджинг и пинг): `Reach`, `HitBox`, `KillAura`, `AutoClicker`, `Velocity`, `Fly`, `AirJump`, `Speed/BHop`, `Timer`, `Jesus`, `NoSlow`, `Scaffold`, `BadPackets`.
- **Компактная голограмма `AVG` над игроками** (`/pac holo`, право `purpurac.hologram`) — пакетно-изолированная для каждого модератора и без хитбокса (`0` сущностей в простое).
- **Меню истории игрока в стиле HolyWorld** (`/pac menu`, `/pac history <ник>`, право `purpurac.menu`) — **зелёные, оранжевые и красные** блоки истории и **блоки-инструкции по цветам внизу меню**.
- **Право на алерты** (`purpurac.alerts`, переключение `/pac alerts`) и гибкая кастомизация в `plugins/PurpurBedrockAC/config.yml`.
- Подробная документация: [`purpurbedrock-anticheat/README.md`](purpurbedrock-anticheat/README.md).
