/*
 * WorldEdit, a Minecraft world manipulation toolkit
 * Copyright (C) sk89q <http://www.sk89q.com>
 * Copyright (C) WorldEdit team and contributors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

package com.sk89q.worldedit.coremc.internal;

import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.google.common.collect.Streams;
import com.google.common.util.concurrent.Futures;
import com.sk89q.worldedit.EditSession;
import com.sk89q.worldedit.MaxChangedBlocksException;
import com.sk89q.worldedit.WorldEdit;
import com.sk89q.worldedit.WorldEditException;
import com.sk89q.worldedit.blocks.BaseItem;
import com.sk89q.worldedit.blocks.BaseItemStack;
import com.sk89q.worldedit.coremc.mixin.AccessorChunkMap;
import com.sk89q.worldedit.coremc.mixin.AccessorMinecraftServer;
import com.sk89q.worldedit.entity.BaseEntity;
import com.sk89q.worldedit.entity.Entity;
import com.sk89q.worldedit.extent.Extent;
import com.sk89q.worldedit.function.mask.AbstractExtentMask;
import com.sk89q.worldedit.function.mask.Mask;
import com.sk89q.worldedit.internal.Constants;
import com.sk89q.worldedit.math.BlockVector2;
import com.sk89q.worldedit.math.BlockVector3;
import com.sk89q.worldedit.math.Vector3;
import com.sk89q.worldedit.regions.Region;
import com.sk89q.worldedit.util.Direction;
import com.sk89q.worldedit.util.Location;
import com.sk89q.worldedit.util.SideEffect;
import com.sk89q.worldedit.util.SideEffectSet;
import com.sk89q.worldedit.util.TreeGenerator;
import com.sk89q.worldedit.util.concurrency.LazyReference;
import com.sk89q.worldedit.util.io.file.SafeFiles;
import com.sk89q.worldedit.world.AbstractWorld;
import com.sk89q.worldedit.world.RegenOptions;
import com.sk89q.worldedit.world.World;
import com.sk89q.worldedit.world.biome.BiomeType;
import com.sk89q.worldedit.world.block.BaseBlock;
import com.sk89q.worldedit.world.block.BlockState;
import com.sk89q.worldedit.world.block.BlockStateHolder;
import com.sk89q.worldedit.world.generation.ConfiguredFeatureType;
import com.sk89q.worldedit.world.generation.StructureType;
import com.sk89q.worldedit.world.generation.TreeType;
import com.sk89q.worldedit.world.generation.WorldEditTreeGeneration;
import com.sk89q.worldedit.world.item.ItemTypes;
import com.sk89q.worldedit.world.weather.WeatherType;
import com.sk89q.worldedit.world.weather.WeatherTypes;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.core.Registry;
import net.minecraft.core.SectionPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.data.worldgen.placement.EndPlacements;
import net.minecraft.data.worldgen.placement.TreePlacements;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerChunkCache;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Util;
import net.minecraft.world.Clearable;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.biome.Climate;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.chunk.ChunkAccess;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.chunk.PalettedContainer;
import net.minecraft.world.level.chunk.status.ChunkStatus;
import net.minecraft.world.level.dimension.LevelStem;
import net.minecraft.world.level.levelgen.densityfunction.SamplerContext;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.placement.PlacedFeature;
import net.minecraft.world.level.levelgen.structure.BoundingBox;
import net.minecraft.world.level.levelgen.structure.Structure;
import net.minecraft.world.level.levelgen.structure.StructureStart;
import net.minecraft.world.level.saveddata.WeatherData;
import net.minecraft.world.level.storage.LevelStorageSource;
import net.minecraft.world.level.storage.ServerLevelData;
import net.minecraft.world.level.storage.TagValueOutput;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import org.enginehub.linbus.tree.LinCompoundTag;

import java.lang.ref.WeakReference;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ThreadLocalRandom;
import javax.annotation.Nullable;

import static com.google.common.base.Preconditions.checkNotNull;
import static com.google.common.base.Preconditions.checkState;

/**
 * Shared implementation of a Minecraft world for platforms sharing native code.
 */
public final class CoreMcWorld extends AbstractWorld {

    private static final RandomSource random = RandomSource.create();

    private static Identifier getDimensionRegistryKey(ServerLevel world) {
        return Objects.requireNonNull(world.getServer(), "server cannot be null")
            .registryAccess()
            .lookupOrThrow(Registries.DIMENSION_TYPE)
            .getKey(world.dimensionType());
    }

    private final CoreMcPlatform platform;
    private final WeakReference<ServerLevel> worldRef;
    private final CoreMcWorldNativeAccess worldNativeAccess;

    /**
     * Construct a new world.
     *
     * @param platform the owning platform
     * @param world the world
     */
    public CoreMcWorld(CoreMcPlatform platform, ServerLevel world) {
        checkNotNull(world);
        this.platform = platform;
        this.worldRef = new WeakReference<>(world);
        this.worldNativeAccess = new CoreMcWorldNativeAccess(platform, worldRef);
    }

    /**
     * Get the underlying handle to the world.
     *
     * @return the world
     * @throws RuntimeException thrown if a reference to the world was lost (i.e. world was unloaded)
     */
    public ServerLevel getWorld() {
        ServerLevel world = worldRef.get();
        if (world != null) {
            return world;
        } else {
            throw new RuntimeException("The reference to the world was lost (i.e. the world may have been unloaded)");
        }
    }

    @Override
    public String getName() {
        return ((ServerLevelData) getWorld().getLevelData()).getLevelName();
    }

    @Override
    public String id() {
        return getName() + "_" + getDimensionRegistryKey(getWorld());
    }

    @Override
    public Path getStoragePath() {
        ServerLevel world = getWorld();
        return ((AccessorMinecraftServer) world.getServer()).getStorageSource().getDimensionPath(world.dimension());
    }

    @Override
    public <B extends BlockStateHolder<B>> boolean setBlock(BlockVector3 position, B block, SideEffectSet sideEffects) throws WorldEditException {
        clearContainerBlockContents(position);
        return worldNativeAccess.setBlock(position, block, sideEffects);
    }

    @Override
    public Set<SideEffect> applySideEffects(BlockVector3 position, BlockState previousType, SideEffectSet sideEffectSet) {
        worldNativeAccess.applySideEffects(position, previousType, sideEffectSet);
        return Sets.intersection(platform.getSupportedSideEffects(), sideEffectSet.getSideEffectsToApply());
    }

    @Override
    public int getBlockLightLevel(BlockVector3 position) {
        checkNotNull(position);
        return getWorld().getMaxLocalRawBrightness(platform.getAdapter().toBlockPos(position));
    }

    @Override
    public boolean clearContainerBlockContents(BlockVector3 position) {
        checkNotNull(position);
        BlockEntity tile = getWorld().getBlockEntity(platform.getAdapter().toBlockPos(position));
        if (tile instanceof Clearable clearable) {
            clearable.clearContent();
            return true;
        }
        return false;
    }

    @Override
    public BiomeType getBiome(BlockVector3 position) {
        checkNotNull(position);
        ChunkAccess chunk = getWorld().getChunk(position.x() >> 4, position.z() >> 4);
        return getBiomeInChunk(position, chunk);
    }

    private BiomeType getBiomeInChunk(BlockVector3 position, ChunkAccess chunk) {
        return platform.getAdapter().fromNativeBiome(
            chunk.getNoiseBiome(position.x() >> 2, position.y() >> 2, position.z() >> 2).value()
        );
    }

    @Override
    public boolean setBiome(BlockVector3 position, BiomeType biome) {
        checkNotNull(position);
        checkNotNull(biome);

        ChunkAccess chunk = getWorld().getChunk(position.x() >> 4, position.z() >> 4);
        // Screw it, we know it's really mutable...
        var biomeArray = (PalettedContainer<Holder<Biome>>) chunk.getSection(chunk.getSectionIndex(position.y())).getBiomes();
        biomeArray.getAndSetUnchecked(
            (position.x() >> 2) & 3, (position.y() >> 2) & 3, (position.z() >> 2) & 3,
            getWorld().registryAccess().lookupOrThrow(Registries.BIOME)
                .getOrThrow(ResourceKey.create(Registries.BIOME, Identifier.parse(biome.id())))
        );
        chunk.markUnsaved();
        return true;
    }

    private static final LoadingCache<ServerLevel, CoreMcFakePlayer> fakePlayers
        = CacheBuilder.newBuilder().weakKeys().softValues().build(CacheLoader.from(CoreMcFakePlayer::new));

    @Override
    public boolean useItem(BlockVector3 position, BaseItem item, Direction face) {
        ItemStack stack = platform.getAdapter().toNativeItemStack(new BaseItemStack(item.getType(), item.getNbtReference(), 1));
        ServerLevel world = getWorld();
        final CoreMcFakePlayer fakePlayer;
        try {
            fakePlayer = fakePlayers.get(world);
        } catch (ExecutionException _) {
            return false;
        }
        fakePlayer.setItemInHand(InteractionHand.MAIN_HAND, stack);
        fakePlayer.absSnapTo(position.x(), position.y(), position.z(),
            (float) face.toVector().toYaw(), (float) face.toVector().toPitch());
        final BlockPos blockPos = platform.getAdapter().toBlockPos(position);
        final BlockHitResult rayTraceResult = new BlockHitResult(platform.getAdapter().toVec3(position),
            platform.getAdapter().adapt(face), blockPos, false);
        UseOnContext itemUseContext = new UseOnContext(fakePlayer, InteractionHand.MAIN_HAND, rayTraceResult);
        InteractionResult used = stack.useOn(itemUseContext);
        if (!used.consumesAction()) {
            used = world.getBlockState(blockPos).useItemOn(stack, world, fakePlayer, InteractionHand.MAIN_HAND, rayTraceResult);
            if (!used.consumesAction()) {
                used = stack.getItem().use(world, fakePlayer, InteractionHand.MAIN_HAND);
            }
        }
        return used.consumesAction();
    }

    @Override
    public void dropItem(Vector3 position, BaseItemStack item) {
        checkNotNull(position);
        checkNotNull(item);

        if (item.getType() == ItemTypes.AIR) {
            return;
        }

        ItemEntity entity = new ItemEntity(getWorld(), position.x(), position.y(), position.z(), platform.getAdapter().toNativeItemStack(item));
        entity.setPickUpDelay(10);
        getWorld().addFreshEntity(entity);
    }

    @Override
    public void simulateBlockMine(BlockVector3 position) {
        BlockPos pos = platform.getAdapter().toBlockPos(position);
        getWorld().destroyBlock(pos, true);
    }

    @Override
    public boolean canPlaceAt(BlockVector3 position, BlockState blockState) {
        return platform.getAdapter().toNativeBlockState(blockState).canSurvive(getWorld(), platform.getAdapter().toBlockPos(position));
    }

    @Override
    public boolean regenerate(Region region, Extent extent, RegenOptions options) {
        if (options.getSeed().isPresent()) {
            throw new UnsupportedOperationException("26.1+ worldgen does not support overriding the seed for regen");
        }

        try {
            doRegen(region, extent, options);
        } catch (Exception e) {
            throw new IllegalStateException("Regen failed", e);
        }

        return true;
    }

    private void doRegen(Region region, Extent extent, RegenOptions options) throws Exception {
        Path tempDir = Files.createTempDirectory("WorldEditWorldGen");
        LevelStorageSource levelStorage = LevelStorageSource.createDefault(tempDir);
        try (LevelStorageSource.LevelStorageAccess session = levelStorage.createAccess("WorldEditTempGen")) {
            ServerLevel originalWorld = getWorld();

            ResourceKey<Level> worldRegKey = originalWorld.dimension();
            try (ServerLevel serverWorld = new ServerLevel(
                originalWorld.getServer(), Util.backgroundExecutor(), session,
                ((ServerLevelData) originalWorld.getLevelData()),
                worldRegKey,
                new LevelStem(
                    originalWorld.dimensionTypeRegistration(),
                    originalWorld.getChunkSource().getGenerator()
                ),
                originalWorld.isDebug(),
                originalWorld.getSeed(),
                // No spawners are needed for this world.
                ImmutableList.of(),
                // This controls ticking, we don't need it so set it to false.
                false
            )) {
                regenForWorld(region, extent, serverWorld, options);

                // drive the server executor until all tasks are popped off
                originalWorld.getServer().managedBlock(() -> originalWorld.getServer().getPendingTasksCount() == 0);
            }
        } finally {
            SafeFiles.tryHardToDeleteDir(tempDir);
        }
    }

    private void regenForWorld(Region region, Extent extent, ServerLevel serverWorld,
                               RegenOptions options) throws WorldEditException {
        List<CompletableFuture<ChunkAccess>> chunkLoadings = submitChunkLoadTasks(region, serverWorld);

        // drive executor until loading finishes
        ((AccessorChunkMap) serverWorld.getChunkSource().chunkMap).getMainThreadExecutor()
            .managedBlock(() -> {
                // bail out early if a future fails
                if (chunkLoadings.stream().anyMatch(ftr ->
                    ftr.isDone() && Futures.getUnchecked(ftr) == null
                )) {
                    return false;
                }
                return chunkLoadings.stream().allMatch(CompletableFuture::isDone);
            });

        Map<ChunkPos, ChunkAccess> chunks = new HashMap<>();
        for (CompletableFuture<ChunkAccess> future : chunkLoadings) {
            @Nullable
            ChunkAccess chunk = future.getNow(null);
            checkState(chunk != null, "Failed to generate a chunk, regen failed.");
            chunks.put(chunk.getPos(), chunk);
        }

        for (BlockVector3 vec : region) {
            BlockPos pos = platform.getAdapter().toBlockPos(vec);
            ChunkAccess chunk = chunks.get(ChunkPos.containing(pos));
            BlockStateHolder<?> state = platform.getAdapter().fromNativeBlockState(chunk.getBlockState(pos));
            BlockEntity blockEntity = chunk.getBlockEntity(pos);
            if (blockEntity != null) {
                CompoundTag tag = CoreMcLoggingProblemReporter.with(
                    () -> "serializing block entity at " + pos,
                    reporter -> {
                        var tagValueOutput = TagValueOutput.createWithContext(reporter, getWorld().registryAccess());
                        blockEntity.saveWithId(tagValueOutput);
                        return tagValueOutput.buildResult();
                    }
                );
                state = state.toBaseBlock(LazyReference.from(() -> NBTConverter.fromNative(tag)));
            }
            extent.setBlock(vec, state.toBaseBlock());

            if (options.shouldRegenBiomes()) {
                BiomeType biome = getBiomeInChunk(vec, chunk);
                extent.setBiome(vec, biome);
            }
        }
    }

    private List<CompletableFuture<ChunkAccess>> submitChunkLoadTasks(Region region, ServerLevel world) {
        List<CompletableFuture<ChunkAccess>> chunkLoadings = new ArrayList<>();
        // Pre-gen all the chunks
        for (BlockVector2 chunk : region.getChunks()) {
            chunkLoadings.add(
                world.getChunkSource().getChunkFuture(chunk.x(), chunk.z(), ChunkStatus.FEATURES, true)
                    .thenApply(either -> either.orElse(null))
            );
        }
        return chunkLoadings;
    }

    @SuppressWarnings("deprecation")
    @Nullable
    private static ResourceKey<PlacedFeature> createTreeFeatureGenerator(TreeGenerator.TreeType type) {
        return switch (type) {
            // Based off of the SaplingGenerator class, as well as uses of DefaultBiomeFeatures fields
            case TREE -> TreePlacements.OAK_CHECKED;
            case BIG_TREE -> TreePlacements.FANCY_OAK_CHECKED;
            case REDWOOD -> TreePlacements.SPRUCE_CHECKED;
            case TALL_REDWOOD -> TreePlacements.MEGA_SPRUCE_CHECKED;
            case MEGA_REDWOOD -> TreePlacements.MEGA_PINE_CHECKED;
            case BIRCH -> TreePlacements.BIRCH_CHECKED;
            case JUNGLE -> TreePlacements.MEGA_JUNGLE_TREE_CHECKED;
            case SMALL_JUNGLE -> TreePlacements.JUNGLE_TREE_CHECKED;
            case SHORT_JUNGLE -> TreePlacements.JUNGLE_TREE_CHECKED;
            case JUNGLE_BUSH -> TreePlacements.JUNGLE_BUSH;
            case SWAMP -> TreePlacements.OAK_CHECKED;
            case ACACIA -> TreePlacements.ACACIA_CHECKED;
            case DARK_OAK -> TreePlacements.DARK_OAK_CHECKED;
            case TALL_BIRCH -> TreePlacements.SUPER_BIRCH_BEES_0002;
            case WARPED_FUNGUS -> TreePlacements.WARPED_FUNGI;
            case CRIMSON_FUNGUS -> TreePlacements.CRIMSON_FUNGI;
            case CHORUS_PLANT -> EndPlacements.CHORUS_PLANT;
            case MANGROVE -> TreePlacements.MANGROVE_CHECKED;
            case TALL_MANGROVE -> TreePlacements.TALL_MANGROVE_CHECKED;
            case CHERRY -> TreePlacements.CHERRY_CHECKED;
            case PALE_OAK -> TreePlacements.PALE_OAK_CHECKED;
            case PALE_OAK_CREAKING -> TreePlacements.PALE_OAK_CREAKING_CHECKED;
            case RANDOM -> {
                // We're intentionally using index here to get a random tree type
                @SuppressWarnings("EnumOrdinal")
                TreeGenerator.TreeType randomTreeType = TreeGenerator.TreeType.values()[ThreadLocalRandom.current().nextInt(TreeGenerator.TreeType.values().length)];
                yield createTreeFeatureGenerator(randomTreeType);
            }
            default -> null;
        };
    }

    @SuppressWarnings("deprecation")
    @Override
    public boolean generateTree(TreeGenerator.TreeType type, EditSession editSession, BlockVector3 position) throws MaxChangedBlocksException {
        ServerLevel world = getWorld();
        PlacedFeature generator = Optional.ofNullable(createTreeFeatureGenerator(type))
            .map(k -> world.registryAccess().lookupOrThrow(Registries.PLACED_FEATURE).getValue(k))
            .orElse(null);
        ServerChunkCache chunkManager = world.getChunkSource();
        if (type == TreeGenerator.TreeType.CHORUS_PLANT) {
            position = position.add(0, 1, 0);
        }
        try (CoreMcServerLevelDelegateProxy.LevelAndProxy proxyLevel = CoreMcServerLevelDelegateProxy.newInstance(platform, editSession, world)) {
            return generator != null && generator.place(
                proxyLevel.level(), chunkManager.getGenerator(), random,
                platform.getAdapter().toBlockPos(position)
            );
        }
    }

    @Override
    public boolean generateTree(TreeType type, EditSession editSession, BlockVector3 position) throws MaxChangedBlocksException {
        Boolean customResult = WorldEditTreeGeneration.handleWorldEditTrees(this, type, editSession, position);
        if (customResult != null) {
            return customResult;
        }
        ServerLevel world = getWorld();
        PlacedFeature generator = world.registryAccess().lookupOrThrow(Registries.PLACED_FEATURE).getValue(Identifier.tryParse(type.id()));
        ServerChunkCache chunkManager = world.getChunkSource();
        try (CoreMcServerLevelDelegateProxy.LevelAndProxy proxyLevel = CoreMcServerLevelDelegateProxy.newInstance(platform, editSession, world)) {
            return generator != null && generator.place(
                proxyLevel.level(), chunkManager.getGenerator(), random,
                platform.getAdapter().toBlockPos(position)
            );
        }
    }

    @Override
    public boolean generateFeature(ConfiguredFeatureType type, EditSession editSession, BlockVector3 position) {
        ServerLevel world = getWorld();
        Feature feature = world.registryAccess().lookupOrThrow(Registries.FEATURE).getValue(Identifier.tryParse(type.id()));
        ServerChunkCache chunkManager = world.getChunkSource();
        try (CoreMcServerLevelDelegateProxy.LevelAndProxy proxyLevel = CoreMcServerLevelDelegateProxy.newInstance(platform, editSession, world)) {
            return feature != null && feature.place(
                proxyLevel.level(), chunkManager.getGenerator(), random,
                platform.getAdapter().toBlockPos(position)
            );
        } catch (MaxChangedBlocksException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public boolean generateStructure(StructureType type, EditSession editSession, BlockVector3 position) {
        ServerLevel world = getWorld();
        Registry<Structure> structureRegistry = world.registryAccess().lookupOrThrow(Registries.STRUCTURE);
        Structure structure = structureRegistry.getValue(Identifier.tryParse(type.id()));
        if (structure == null) {
            return false;
        }

        ServerChunkCache chunkManager = world.getChunkSource();
        Climate.Sampler climateSampler = chunkManager.randomState().createClimateSampler(
            SamplerContext.builder().enableCaches().build()
        );
        try (CoreMcServerLevelDelegateProxy.LevelAndProxy proxyLevel = CoreMcServerLevelDelegateProxy.newInstance(platform, editSession, world)) {
            ChunkPos chunkPos = ChunkPos.containing(new BlockPos(position.x(), position.y(), position.z()));
            StructureStart structureStart = structure.generate(
                structureRegistry.wrapAsHolder(structure), world.dimension(), world.registryAccess(),
                chunkManager.getGenerator(), chunkManager.getGenerator().getBiomeSource(), climateSampler, chunkManager.randomState(),
                world.getStructureTemplateManager(), world.getSeed(), chunkPos, 0, proxyLevel.level(),
                _ -> true
            );

            if (!structureStart.isValid()) {
                return false;
            } else {
                BoundingBox boundingBox = structureStart.getBoundingBox();
                ChunkPos min = new ChunkPos(SectionPos.blockToSectionCoord(boundingBox.minX()), SectionPos.blockToSectionCoord(boundingBox.minZ()));
                ChunkPos max = new ChunkPos(SectionPos.blockToSectionCoord(boundingBox.maxX()), SectionPos.blockToSectionCoord(boundingBox.maxZ()));
                ChunkPos.rangeClosed(min, max).forEach((chunkPosx) ->
                    structureStart.placeInChunk(
                        proxyLevel.level(), world.structureManager(), chunkManager.getGenerator(), world.getRandom(),
                        new BoundingBox(chunkPosx.getMinBlockX(), world.getMinY(), chunkPosx.getMinBlockZ(),
                            chunkPosx.getMaxBlockX(), world.getMaxY(), chunkPosx.getMaxBlockZ()),
                        chunkPosx
                    )
                );
                return true;
            }
        } catch (MaxChangedBlocksException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void checkLoadedChunk(BlockVector3 pt) {
        getWorld().getChunk(platform.getAdapter().toBlockPos(pt));
    }

    @Override
    public void fixAfterFastMode(Iterable<BlockVector2> chunks) {
        fixLighting(chunks);
    }

    @Override
    public void sendBiomeUpdates(Iterable<BlockVector2> chunks) {
        List<ChunkAccess> nativeChunks = chunks instanceof Collection<BlockVector2> chunkCollection ? Lists.newArrayListWithCapacity(chunkCollection.size()) : Lists.newArrayList();
        for (BlockVector2 chunk : chunks) {
            nativeChunks.add(getWorld().getChunk(chunk.x(), chunk.z(), ChunkStatus.BIOMES, false));
        }
        getWorld().getChunkSource().chunkMap.resendBiomesForChunks(nativeChunks);
    }

    @Override
    public void fixLighting(Iterable<BlockVector2> chunks) {
        ServerLevel world = getWorld();
        for (BlockVector2 chunk : chunks) {
            // Fetch the chunk after light initialization at least
            // We'll be doing a full relight anyways, so we don't need to be LIGHT yet
            world.getChunkSource().getLightEngine().lightChunk(world.getChunk(
                chunk.x(), chunk.z(), ChunkStatus.INITIALIZE_LIGHT
            ), false).exceptionally(t -> {
                WorldEdit.logger.warn("Failed to relight chunk at " + chunk, t);
                return null;
            });
        }
    }

    @Override
    public WeatherType getWeather() {
        WeatherData weatherData = getWorld().getServer().getWeatherData();
        if (weatherData.isThundering()) {
            return WeatherTypes.THUNDER_STORM;
        }
        if (weatherData.isRaining()) {
            return WeatherTypes.RAIN;
        }
        return WeatherTypes.CLEAR;
    }

    @Override
    public long getRemainingWeatherDuration() {
        WeatherData weatherData = getWorld().getServer().getWeatherData();
        if (weatherData.isThundering()) {
            return weatherData.getThunderTime();
        }
        if (weatherData.isRaining()) {
            return weatherData.getRainTime();
        }
        return weatherData.getClearWeatherTime();
    }

    @Override
    public void setWeather(WeatherType weatherType) {
        setWeather(weatherType, 0);
    }

    @Override
    public void setWeather(WeatherType weatherType, long duration) {
        WeatherData weatherData = getWorld().getServer().getWeatherData();
        if (weatherType == WeatherTypes.THUNDER_STORM) {
            weatherData.setClearWeatherTime(0);
            weatherData.setThundering(true);
            weatherData.setThunderTime((int) duration);
        } else if (weatherType == WeatherTypes.RAIN) {
            weatherData.setClearWeatherTime(0);
            weatherData.setRaining(true);
            weatherData.setRainTime((int) duration);
        } else if (weatherType == WeatherTypes.CLEAR) {
            weatherData.setRaining(false);
            weatherData.setThundering(false);
            weatherData.setClearWeatherTime((int) duration);
        }
    }

    @Override
    public int getMinY() {
        return getWorld().getMinY();
    }

    @Override
    public int getMaxY() {
        return getWorld().getMaxY();
    }

    @Override
    public BlockVector3 getSpawnPosition() {
        return platform.getAdapter().adapt(getWorld().getLevelData().getRespawnData().pos());
    }

    @Override
    public BlockState getBlock(BlockVector3 position) {
        net.minecraft.world.level.block.state.BlockState mcState = getWorld()
            .getChunk(position.x() >> 4, position.z() >> 4)
            .getBlockState(platform.getAdapter().toBlockPos(position));
        return platform.getAdapter().fromNativeBlockState(mcState);
    }

    @Override
    public BaseBlock getFullBlock(BlockVector3 position) {
        BlockPos pos = new BlockPos(position.x(), position.y(), position.z());
        // Avoid creation by using the CHECK mode -- if it's needed, it'll be re-created anyways
        BlockEntity tile = ((LevelChunk) getWorld().getChunk(pos)).getBlockEntity(pos, LevelChunk.EntityCreationType.CHECK);

        if (tile != null) {
            CompoundTag tag = CoreMcLoggingProblemReporter.with(
                () -> "serializing block entity at " + pos,
                reporter -> {
                    var tagValueOutput = TagValueOutput.createWithContext(reporter, getWorld().registryAccess());
                    tile.saveWithId(tagValueOutput);
                    return tagValueOutput.buildResult();
                }
            );
            return getBlock(position).toBaseBlock(LazyReference.from(() -> NBTConverter.fromNative(tag)));
        } else {
            return getBlock(position).toBaseBlock();
        }
    }

    @Override
    public int hashCode() {
        return getWorld().hashCode();
    }

    @Override
    public boolean equals(Object o) {
        return switch (o) {
            case CoreMcWorld other -> {
                ServerLevel otherWorld = other.worldRef.get();
                ServerLevel thisWorld = worldRef.get();
                yield otherWorld != null && otherWorld.equals(thisWorld);
            }
            case World world -> world.getName().equals(getName());
            case null, default -> false;
        };
    }

    @Override
    public List<? extends Entity> getEntities(Region region) {
        final ServerLevel world = getWorld();
        AABB box = new AABB(
            platform.getAdapter().toVec3(region.getMinimumPoint()),
            platform.getAdapter().toVec3(region.getMaximumPoint().add(BlockVector3.ONE))
        );
        List<net.minecraft.world.entity.Entity> nmsEntities = world.getEntities(
            (net.minecraft.world.entity.Entity) null,
            box,
            e -> region.contains(platform.getAdapter().adapt(e.blockPosition()))
        );
        return nmsEntities.stream()
            .map(e -> new CoreMcEntity(platform, e))
            .collect(ImmutableList.toImmutableList());
    }

    @Override
    public List<? extends Entity> getEntities() {
        final ServerLevel world = getWorld();
        return Streams.stream(world.getAllEntities())
            .map(entity -> new CoreMcEntity(platform, entity))
            .collect(ImmutableList.toImmutableList());
    }

    @Nullable
    @Override
    public Entity createEntity(Location location, BaseEntity entity) {
        ServerLevel world = getWorld();
        String entityId = entity.getType().id();
        final Optional<EntityType<?>> entityType = world.registryAccess().lookupOrThrow(Registries.ENTITY_TYPE).getOptional(Identifier.parse(entityId));
        if (entityType.isEmpty()) {
            return null;
        }
        LinCompoundTag linTag = entity.getNbt();
        CompoundTag tag;
        if (linTag != null) {
            tag = NBTConverter.toNative(linTag);
            removeUnwantedEntityTagsRecursively(tag);
        } else {
            tag = new CompoundTag();
        }
        tag.putString("id", entityId);

        net.minecraft.world.entity.Entity createdEntity = EntityType.loadEntityRecursive(entityType.get(), tag, world, EntitySpawnReason.COMMAND, loadedEntity -> {
            loadedEntity.absSnapTo(location.getX(), location.getY(), location.getZ(), location.getYaw(), location.getPitch());
            return loadedEntity;
        });
        if (createdEntity != null) {
            world.addFreshEntityWithPassengers(createdEntity);
            return new CoreMcEntity(platform, createdEntity);
        }
        return null;
    }

    private void removeUnwantedEntityTagsRecursively(CompoundTag tag) {
        for (String name : Constants.NO_COPY_ENTITY_NBT_FIELDS) {
            tag.remove(name);
        }

        // Adapted from net.minecraft.world.entity.EntityType#loadEntityRecursive
        tag.getList("Passengers").ifPresent(nbttaglist -> {
            for (int i = 0; i < nbttaglist.size(); ++i) {
                removeUnwantedEntityTagsRecursively(nbttaglist.getCompoundOrEmpty(i));
            }
        });
    }

    @Override
    public Mask createLiquidMask() {
        return new AbstractExtentMask(this) {
            @Override
            public boolean test(BlockVector3 vector) {
                return platform.getAdapter().toNativeBlockState(getExtent().getBlock(vector)).getBlock() instanceof LiquidBlock;
            }
        };
    }

    @Override
    public boolean isValid() {
        return worldRef.get() != null;
    }
}
