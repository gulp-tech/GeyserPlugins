/*
 * WorldEdit, a Minecraft world manipulation toolkit
 * Copyright (C) sk89q <http://www.sk89q.com>
 * Copyright (C) WorldEdit team and contributors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

package com.sk89q.worldedit.extension.factory;

import com.google.common.base.CharMatcher;
import com.sk89q.util.StringUtil;
import com.sk89q.worldedit.WorldEdit;
import com.sk89q.worldedit.extension.factory.parser.DefaultBlockParser;
import com.sk89q.worldedit.extension.input.InputParseException;
import com.sk89q.worldedit.extension.input.ParserContext;
import com.sk89q.worldedit.internal.registry.AbstractFactory;
import com.sk89q.worldedit.world.block.BaseBlock;

import java.util.HashSet;
import java.util.Set;

/**
 * A registry of known {@link BaseBlock}s. Provides methods to instantiate
 * new blocks from input.
 *
 * <p>Instances of this class can be taken from
 * {@link WorldEdit#getBlockFactory()}.</p>
 */
public class BlockFactory extends AbstractFactory<BaseBlock> {

    private static final CharMatcher LIST_DELIMITER = CharMatcher.is(',');

    /**
     * Create a new instance.
     *
     * @param worldEdit the WorldEdit instance.
     */
    public BlockFactory(WorldEdit worldEdit) {
        super(worldEdit, new DefaultBlockParser(worldEdit));
    }

    /**
     * Return a set of blocks from a comma-delimited list of blocks.
     *
     * @param input the input
     * @param context the context
     * @return a set of blocks
     * @throws InputParseException thrown in error with the input
     */
    public Set<BaseBlock> parseFromListInput(String input, ParserContext context) throws InputParseException {
        Set<BaseBlock> blocks = new HashSet<>();
        for (String token : StringUtil.splitOutsideBrackets(input, LIST_DELIMITER)) {
            blocks.add(parseFromInput(token, context));
        }
        return blocks;
    }

}
