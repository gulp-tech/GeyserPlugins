/*
 * WorldEdit, a Minecraft world manipulation toolkit
 * Copyright (C) sk89q <http://www.sk89q.com>
 * Copyright (C) WorldEdit team and contributors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

package com.sk89q.worldedit.command.tool;

import com.google.common.collect.Lists;
import com.sk89q.worldedit.EditSession;
import com.sk89q.worldedit.LocalConfiguration;
import com.sk89q.worldedit.LocalSession;
import com.sk89q.worldedit.MaxChangedBlocksException;
import com.sk89q.worldedit.entity.Player;
import com.sk89q.worldedit.extension.platform.Actor;
import com.sk89q.worldedit.extension.platform.Platform;
import com.sk89q.worldedit.math.BlockVector3;
import com.sk89q.worldedit.registry.state.Property;
import com.sk89q.worldedit.util.Direction;
import com.sk89q.worldedit.util.Location;
import com.sk89q.worldedit.util.formatting.text.TextComponent;
import com.sk89q.worldedit.util.formatting.text.TranslatableComponent;
import com.sk89q.worldedit.world.World;
import com.sk89q.worldedit.world.block.BaseBlock;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import javax.annotation.Nullable;

/**
 * A mode that cycles the data values of supported blocks.
 */
public class BlockDataCyler implements DoubleActionBlockTool {

    @Override
    public boolean canUse(Actor player) {
        return player.hasPermission("worldedit.tool.data-cycler");
    }

    private final Map<UUID, Property<?>> selectedProperties = new HashMap<>();

    private boolean handleCycle(LocalConfiguration config, Player player, LocalSession session,
                                Location clicked, boolean forward) {

        World world = BlockTool.requireWorld(clicked);

        BlockVector3 blockPoint = clicked.toVector().toBlockPoint();
        BaseBlock block = world.getFullBlock(blockPoint);

        if (!config.allowedDataCycleBlocks.isEmpty()
                && !player.hasPermission("worldedit.override.data-cycler")
                && !config.allowedDataCycleBlocks.contains(block.getBlockType().id())) {
            player.printError(TranslatableComponent.of("worldedit.tool.data-cycler.block-not-permitted"));
            return true;
        }

        if (block.getStates().isEmpty()) {
            player.printError(TranslatableComponent.of("worldedit.tool.data-cycler.cant-cycle"));
        } else {
            Property<?> currentProperty = selectedProperties.get(player.getUniqueId());

            if (currentProperty == null || (forward && block.getState(currentProperty) == null)) {
                currentProperty = block.getStates().keySet().stream().findFirst().get();
                selectedProperties.put(player.getUniqueId(), currentProperty);
            }

            if (forward) {
                block.getState(currentProperty);
                int index = currentProperty.values().indexOf(block.getState(currentProperty));
                index = (index + 1) % currentProperty.values().size();
                @SuppressWarnings("unchecked")
                Property<Object> objProp = (Property<Object>) currentProperty;
                BaseBlock newBlock = block.with(objProp, currentProperty.values().get(index));

                try (EditSession editSession = BlockTool.createEditSession(player, session, clicked)) {
                    editSession.disableBuffering();

                    try {
                        editSession.setBlock(blockPoint, newBlock);
                        player.printInfo(TranslatableComponent.of(
                                "worldedit.tool.data-cycler.new-value",
                                TextComponent.of(currentProperty.name()),
                                TextComponent.of(String.valueOf(currentProperty.values().get(index)))
                        ));
                    } catch (MaxChangedBlocksException _) {
                        player.printError(TranslatableComponent.of("worldedit.tool.max-block-changes"));
                    } finally {
                        session.remember(editSession);
                    }
                }
            } else {
                List<Property<?>> properties = Lists.newArrayList(block.getStates().keySet());
                int index = properties.indexOf(currentProperty);
                index = (index + 1) % properties.size();
                currentProperty = properties.get(index);
                selectedProperties.put(player.getUniqueId(), currentProperty);
                player.printInfo(TranslatableComponent.of("worldedit.tool.data-cycler.cycling", TextComponent.of(currentProperty.name())));
            }
        }

        return true;
    }

    @Override
    public boolean actPrimary(Platform server, LocalConfiguration config, Player player, LocalSession session, Location clicked, @Nullable Direction face) {
        return handleCycle(config, player, session, clicked, true);
    }

    @Override
    public boolean actSecondary(Platform server, LocalConfiguration config, Player player, LocalSession session, Location clicked, @Nullable Direction face) {
        return handleCycle(config, player, session, clicked, false);
    }

}
