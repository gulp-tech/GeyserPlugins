import buildlogic.getLibrary
import buildlogic.stringyLibs

plugins {
    id("com.gradleup.shadow")
    id("buildlogic.core-and-platform")
}

val platform = extensions.create<buildlogic.PlatformExtension>("platform")
platform.includeClasspath.convention(false)
platform.extraAttributes.convention(mapOf())

shadow {
    addShadowVariantIntoJavaComponent = false
}

tasks.named<com.github.jengelman.gradle.plugins.shadow.tasks.ShadowJar>("shadowJar") {
    archiveClassifier.set("dist")
    relocate("com.sk89q.jchronic", "com.sk89q.worldedit.jchronic")
    val jchronic = stringyLibs.getLibrary("jchronic").get()
    val linBusDeps = listOf(
        "common",
        "stream",
        "tree",
        "format-snbt"
    ).map { stringyLibs.getLibrary("linBus-$it").get() }
    val platformLibName = project.name.replace("worldedit-", "")
    dependencies {
        include(project(":worldedit-libs:core"))
        include(project(":worldedit-libs:$platformLibName"))
        include(project(":worldedit-core"))
        include(project(":worldedit-core-mc"))
        include(dependency(jchronic))
        linBusDeps.forEach {
            include(dependency(it))
        }
        exclude(dependency("com.google.code.findbugs:jsr305"))
    }
    exclude("GradleStart**")
    exclude(".cache")
    exclude("LICENSE*")
    exclude("META-INF/maven/**")
    minimize {
        // jchronic uses reflection to load things, so we need to exclude it from minimizing
        exclude(dependency(jchronic))
        // we provide the full lin-bus API, so don't minimize that
        linBusDeps.forEach {
            exclude(dependency(it))
        }
    }
}

afterEvaluate {
    tasks.named<Jar>("jar") {
        val kind = platform.kind.get()
        val includeClasspath = platform.includeClasspath.get()
        val extraAttributes = platform.extraAttributes.get()

        val version = providers.gradleProperty("version").get()
        inputs.property("version", version)
        val attributes = mutableMapOf(
            "Implementation-Version" to version,
            "WorldEdit-Version" to version,
            "WorldEdit-Kind" to kind.name,
            "Main-Class" to kind.mainClass
        )
        if (includeClasspath) {
            attributes["Class-Path"] = listOf("truezip", "truevfs", "js")
                .map { "$it.jar" }
                .flatMap { listOf(it, "WorldEdit/$it", "../$it", "../WorldEdit/$it") }
                .joinToString(separator = " ")
        }
        attributes.putAll(extraAttributes)
        manifest.attributes(attributes)
    }
}
