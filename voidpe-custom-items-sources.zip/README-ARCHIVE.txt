VoidPE — материалы по кастомным предметам/блокам/мобам (для разработки ядра)
===========================================================================

Состав архива
-------------
1. VoidTalismans/               — ПОЛНЫЕ исходники (Maven): pom.xml + src/
   Талисманы и сферы. Ключевые файлы:
     src/main/java/ru/voidpe/talismans/TalismanService.java — создание предметов,
       метка PDC voidtalismans:talisman_id, custom-model-data, item-model.
     src/main/resources/config.yml — определения предметов (сферы sphere1-4:
       material PAPER + custom-model-data 9001-9004 + item-model voidspheres:sphereN).
   Сборка: mvn -f VoidTalismans/pom.xml package.

2. HyperTNT.jar + HyperTNT/     — кастомные виды TNT.
   ВНИМАНИЕ: исходников HyperTNT в репозитории НЕТ (ни в дереве, ни в истории git)
   — только собранный jar (пакет mk.hypertnt, Maven-артефакт mk.hypertnt:HyperTNT)
   и рабочие конфиги. Реальные данные для проверки — конфиги:
     HyperTNT/tnts/tnt_basic.yml (и tnt_explosive, tnt_fire, tnt_heavy, tnt_obs,
     tnt_poseidon): предмет = ванильный TNT + custom_model_data + имя/лор;
     поведение (фитиль, радиус, подрыв) — там же.
   Известная проблема: тип поставленного кастомного TNT хранится в памяти
   плагина и теряется при рестарте (см. tools/test_hypertnt_configs.py).

3. VoidSpheres.mcpack           — Bedrock-пак сфер:
     attachables/sphere_1-4.json (identifier geyser_custom:sphereN, геометрия
       sphere_left/right, анимации wield), models/entity/sphere_*.geo.json,
     render_controllers/Sphere.render_controllers.json,
     textures/item/sphere_texture_*.png + sphere_icon_*.png (иконка в инвентаре),
     animations/sphere.json.

4. PistoletovPack.mcpack        — Bedrock-пак кастомного моба (zombie_horse):
     entity/zombie_horse.entity.json — ПЕРЕОПРЕДЕЛЕНИЕ minecraft:zombie_horse
       (внимание: меняет вид всех zombie_horse — ограничение текущего подхода),
     models/entity/pistoletov.geo.json, render_controllers/pistoletov.*,
     textures/entity/pistoletov/f000-f075.png — покадровая анимация
       (UV-анимация на Render Dragon не работает),
     sounds/sound_definitions.json + sounds/pistoletov/pirates.fsb (FSB5 Vorbis).

5. Geyser-spheres-mapping.json  — маппинг Geyser (класть в plugins/Geyser-Spigot/):
     minecraft:paper + type: definition + model voidspheres:sphereN
     -> bedrock_identifier geyser_custom:sphereN + bedrock_options.icon.
     Срабатывает ТОЛЬКО на бумагу с item-model voidspheres:sphereN;
     обычная бумага и бумага с другой моделью остаются ванильными.

Схема идентификации (коротко)
-----------------------------
Предмет: ванильный material + скрытая метка в PersistentDataContainer
(voidtalismans:talisman_id / voiditems:item_id) + визуал через
custom-model-data / item-model. Сервер определяет кастом по PDC,
Bedrock-вид — по маппингу Geyser (model -> geyser_custom:*) + пак с
attachable/иконкой. Паролей и ключей в конфигах нет (проверено).
