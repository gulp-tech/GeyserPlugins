package org.powernukkitx;

import org.powernukkitx.metadata.MetadataValue;
import org.powernukkitx.nbt.tag.CompoundTag;
import org.powernukkitx.plugin.Plugin;

import java.util.List;
import java.util.Locale;
import java.util.UUID;
import com.google.common.base.Preconditions;

/**
 * Describes an offline player.
 *
 * @author MagicDroidX(code) @ Nukkit Project
 * @author Fenxie Dama (javadoc) @ Nukkit Project
 * @see org.powernukkitx.Player
 * @since Nukkit 1.0 | Nukkit API 1.0.0
 */
public class OfflinePlayer implements IPlayer {
    private final Server server;
    private final UUID uuid;
    private final String name;
    private CompoundTag nbtTag;
    private CompoundTag nbtExtraTag;
    private CompoundTag nbtCustomTag;
    private final boolean playedBefore;

    /**
     * Initializes the object {@code OfflinePlayer}.
     *
     * @param server The server this player is in, as a {@code Server} object.
     * @param uuid   UUID of this player.
     * @since Nukkit 1.0 | Nukkit API 1.0.0
     */
    public OfflinePlayer(Server server, UUID uuid) {
        this(server, uuid, null);
    }

    public OfflinePlayer(Server server, String name) {
        this(server, null, name);
    }

    public OfflinePlayer(Server server, UUID uuid, String name) {
        this.server = server;

        if (uuid == null && name == null) {
            throw new IllegalArgumentException("Name and UUID cannot both be null");
        }

        UUID resolvedUuid = uuid != null ? uuid : this.server.lookupName(name).orElse(null);
        Server.PlayerDataRecord record = resolvedUuid != null ? this.server.getOfflinePlayerDataRecord(resolvedUuid, false) : null;

        this.uuid = resolvedUuid;
        this.nbtTag = record != null ? record.nbt() : new CompoundTag();
        this.nbtExtraTag = record != null ? record.pnxExtra() : new CompoundTag();
        this.nbtCustomTag = record != null ? record.custom() : new CompoundTag();
        this.playedBefore = record != null;

        String storedName = this.nbtExtraTag.getString("NameTag");
        this.name = name != null ? name : storedName.isBlank() ? null : storedName;
    }

    @Override
    public boolean isOnline() {
        return this.getPlayer() != null;
    }

    @Override
    public String getName() {
        return this.name;
    }

    @Override
    public UUID getUniqueId() {
        return this.uuid;
    }

    @Override
    public Server getServer() {
        return server;
    }

    @Override
    public CompoundTag getNbt() {
        Player player = this.getPlayer();
        return player != null ? player.getNbt() : this.nbtTag;
    }

    @Override
    public void setNbt(CompoundTag nbt) {
        Player player = this.getPlayer();
        if (player != null) {
            player.setNbt(nbt);
            return;
        }

        this.nbtTag = Preconditions.checkNotNull(nbt, "nbt");
    }

    @Override
    public CompoundTag getNbtExtra() {
        Player player = this.getPlayer();
        return player != null ? player.getNbtExtra() : this.nbtExtraTag;
    }

    @Override
    public void setNbtExtra(CompoundTag nbtExtra) {
        Player player = this.getPlayer();
        if (player != null) {
            player.setNbtExtra(nbtExtra);
            return;
        }

        this.nbtExtraTag = Preconditions.checkNotNull(nbtExtra, "nbtExtra");
    }

    @Override
    public CompoundTag getNbtCustom() {
        Player player = this.getPlayer();
        return player != null ? player.getNbtCustom() : this.nbtCustomTag;
    }

    @Override
    public void setNbtCustom(CompoundTag nbtCustom) {
        Player player = this.getPlayer();
        if (player != null) {
            player.setNbtCustom(nbtCustom);
            return;
        }

        this.nbtCustomTag = Preconditions.checkNotNull(nbtCustom, "nbtCustom");
    }

    @Override
    public void save() {
        Player player = this.getPlayer();
        if (player != null) {
            player.save();
            return;
        }

        Preconditions.checkState(this.uuid != null, "Cannot save player NBT data without a UUID");
        this.server.saveOfflinePlayerData(
            this.uuid,
            this.nbtTag.copy(),
            this.nbtExtraTag.copy(),
            this.nbtCustomTag.copy(),
            false
        );
    }

    @Override
    public boolean isOp() {
        return this.server.isOp(this.getName().toLowerCase(Locale.ENGLISH));
    }

    @Override
    public void setOp(boolean value) {
        if (value == this.isOp()) {
            return;
        }

        String name = this.getName().toLowerCase(Locale.ENGLISH);

        if (value) {
            this.server.addOp(name);
        } else {
            this.server.removeOp(name);
        }
    }

    @Override
    public boolean isBanned() {
        return this.server.getNameBans().isBanned(this.getName());
    }

    @Override
    public void setBanned(boolean value) {
        if (value) {
            this.server.getNameBans().addBan(this.getName(), null, null, null);
        } else {
            this.server.getNameBans().remove(this.getName());
        }
    }

    @Override
    public boolean isWhitelisted() {
        return this.server.isWhitelisted(this.getName().toLowerCase(Locale.ENGLISH));
    }

    @Override
    public void setWhitelisted(boolean value) {
        if (value) {
            this.server.addWhitelist(this.getName().toLowerCase(Locale.ENGLISH));
        } else {
            this.server.removeWhitelist(this.getName().toLowerCase(Locale.ENGLISH));
        }
    }

    @Override
    public Player getPlayer() {
        if (this.uuid != null) {
            return this.server.getPlayer(this.uuid).orElse(null);
        }
        return this.name != null ? this.server.getPlayerExact(this.name) : null;
    }

    @Override
    public Long getFirstPlayed() {
        return this.playedBefore ? this.getNbtExtra().getLong("firstPlayed") : null;
    }

    @Override
    public Long getLastPlayed() {
        return this.playedBefore ? this.getNbtExtra().getLong("lastPlayed") : null;
    }

    @Override
    public boolean hasPlayedBefore() {
        return this.playedBefore;
    }

    @Override
    public void setMetadata(String metadataKey, MetadataValue newMetadataValue) {
        this.server.getPlayerMetadata().setMetadata(this, metadataKey, newMetadataValue);
    }

    @Override
    public List<MetadataValue> getMetadata(String metadataKey) {
        return this.server.getPlayerMetadata().getMetadata(this, metadataKey);
    }

    @Override
    public MetadataValue getMetadata(String metadataKey, Plugin plugin) {
        return this.server.getPlayerMetadata().getMetadata(this, metadataKey, plugin);
    }

    @Override
    public boolean hasMetadata(String metadataKey) {
        return this.server.getPlayerMetadata().hasMetadata(this, metadataKey);
    }

    @Override
    public boolean hasMetadata(String metadataKey, Plugin plugin) {
        return this.server.getPlayerMetadata().hasMetadata(this, metadataKey, plugin);
    }

    @Override
    public void removeMetadata(String metadataKey, Plugin owningPlugin) {
        this.server.getPlayerMetadata().removeMetadata(this, metadataKey, owningPlugin);
    }
}
