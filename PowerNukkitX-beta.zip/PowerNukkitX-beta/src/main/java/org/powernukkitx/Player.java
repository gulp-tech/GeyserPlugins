package org.powernukkitx;

import com.github.benmanes.caffeine.cache.Cache;
import com.github.benmanes.caffeine.cache.Caffeine;
import com.google.common.base.Preconditions;
import com.google.common.base.Strings;
import com.google.common.collect.BiMap;
import com.google.common.collect.HashBiMap;
import com.google.common.collect.Sets;
import io.netty.buffer.Unpooled;
import io.netty.channel.Channel;
import io.netty.util.internal.EmptyArrays;
import io.netty.util.internal.PlatformDependent;
import it.unimi.dsi.fastutil.Pair;
import it.unimi.dsi.fastutil.bytes.ByteOpenHashSet;
import it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.longs.Long2ObjectLinkedOpenHashMap;
import it.unimi.dsi.fastutil.longs.LongIterator;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import lombok.Getter;
import lombok.Setter;
import lombok.Value;
import lombok.extern.slf4j.Slf4j;
import org.cloudburstmc.math.vector.Vector3f;
import org.cloudburstmc.math.vector.Vector3i;
import org.cloudburstmc.netty.channel.nethernet.NetherNetChannel;
import org.cloudburstmc.protocol.bedrock.BedrockServerSession;
import org.powernukkitx.entity.components.RideableComponent;
import org.powernukkitx.entity.passive.EntityParrot;
import org.cloudburstmc.protocol.bedrock.data.*;
import org.cloudburstmc.protocol.bedrock.data.actor.ActorDataTypes;
import org.cloudburstmc.protocol.bedrock.data.actor.ActorEvent;
import org.cloudburstmc.protocol.bedrock.data.actor.ActorFlags;
import org.cloudburstmc.protocol.bedrock.data.actor.ActorLink;
import org.cloudburstmc.protocol.bedrock.data.actor.PropertySyncData;
import org.cloudburstmc.protocol.bedrock.data.command.CommandData;
import org.cloudburstmc.protocol.bedrock.data.command.CommandEnumData;
import org.cloudburstmc.protocol.bedrock.data.command.CommandOriginData;
import org.cloudburstmc.protocol.bedrock.data.command.CommandOriginType;
import org.cloudburstmc.protocol.bedrock.data.command.CommandOutputType;
import org.cloudburstmc.protocol.bedrock.data.command.CommandOverloadData;
import org.cloudburstmc.protocol.bedrock.data.command.CommandParamData;
import org.cloudburstmc.protocol.bedrock.data.inventory.ContainerId;
import org.cloudburstmc.protocol.bedrock.data.inventory.InventoryLayout;
import org.cloudburstmc.protocol.bedrock.data.inventory.ItemData;
import org.cloudburstmc.protocol.bedrock.data.inventory.InventoryLeftTabIndex;
import org.cloudburstmc.protocol.bedrock.data.inventory.InventoryRightTabIndex;
import org.cloudburstmc.protocol.bedrock.data.inventory.ItemUseMethod;
import org.cloudburstmc.protocol.bedrock.data.payload.common.DimensionType;
import org.cloudburstmc.protocol.bedrock.data.payload.move.MovePlayerTeleportData;
import org.cloudburstmc.protocol.bedrock.data.payload.move.PositionMode;
import org.cloudburstmc.protocol.bedrock.data.payload.move.TeleportationCause;
import org.cloudburstmc.protocol.bedrock.data.payload.scoreboard.ChangeEntityScore;
import org.cloudburstmc.protocol.bedrock.data.payload.scoreboard.ChangeFakePlayerScore;
import org.cloudburstmc.protocol.bedrock.data.payload.scoreboard.ChangePlayerScore;
import org.cloudburstmc.protocol.bedrock.data.payload.scoreboard.RemoveScore;
import org.cloudburstmc.protocol.bedrock.data.payload.shape.PrimitiveShapeDataPayload;
import org.cloudburstmc.protocol.bedrock.data.payload.text.AuthorAndMessage;
import org.cloudburstmc.protocol.bedrock.data.payload.text.MessageAndParams;
import org.cloudburstmc.protocol.bedrock.data.payload.text.MessageOnly;
import org.cloudburstmc.protocol.bedrock.data.payload.text.TextPacketBody;
import org.cloudburstmc.protocol.bedrock.packet.*;
import org.cloudburstmc.protocol.bedrock.util.ChainValidationResult;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.jetbrains.annotations.UnmodifiableView;
import org.powernukkitx.AdventureSettings.Type;
import org.powernukkitx.api.UnintendedClientBehaviour;
import org.powernukkitx.api.UsedByReflection;
import org.powernukkitx.block.Block;
import org.powernukkitx.block.BlockAir;
import org.powernukkitx.block.BlockBed;
import org.powernukkitx.block.BlockEndPortal;
import org.powernukkitx.block.BlockID;
import org.powernukkitx.block.BlockLiquid;
import org.powernukkitx.block.BlockRespawnAnchor;
import org.powernukkitx.block.BlockWood;
import org.powernukkitx.block.BlockWool;
import org.powernukkitx.block.customblock.CustomBlock;
import org.powernukkitx.blockentity.BlockEntity;
import org.powernukkitx.blockentity.BlockEntityItemFrame;
import org.powernukkitx.blockentity.BlockEntitySign;
import org.powernukkitx.blockentity.BlockEntitySpawnable;
import org.powernukkitx.camera.PlayerCamera;
import org.powernukkitx.command.Command;
import org.powernukkitx.command.CommandSender;
import org.powernukkitx.command.data.CommandDataVersions;
import org.powernukkitx.command.data.CommandOverload;
import org.powernukkitx.command.data.NukkitCommandData;
import org.powernukkitx.command.utils.RawText;
import org.powernukkitx.dialog.window.FormWindowDialog;
import org.powernukkitx.entity.Attribute;
import org.powernukkitx.entity.Entity;
import org.powernukkitx.entity.EntityHuman;
import org.powernukkitx.entity.EntityInteractable;
import org.powernukkitx.entity.EntityLiving;
import org.powernukkitx.entity.components.NameableComponent;
import org.powernukkitx.entity.data.human.Skin;
import org.powernukkitx.entity.data.warden.WardenWarningData;
import org.powernukkitx.entity.item.EntityFishingHook;
import org.powernukkitx.entity.item.EntityItem;
import org.powernukkitx.entity.item.EntityXpOrb;
import org.powernukkitx.entity.mob.EntityBoss;
import org.powernukkitx.entity.projectile.EntityArrow;
import org.powernukkitx.entity.projectile.EntityProjectile;
import org.powernukkitx.entity.projectile.EntityThrownTrident;
import org.powernukkitx.event.block.WaterFrostEvent;
import org.powernukkitx.event.entity.EntityDamageByBlockEvent;
import org.powernukkitx.event.entity.EntityDamageByEntityEvent;
import org.powernukkitx.event.entity.EntityDamageEvent;
import org.powernukkitx.event.entity.EntityDamageEvent.DamageCause;
import org.powernukkitx.event.entity.EntityPortalEnterEvent;
import org.powernukkitx.event.entity.EntityPortalEnterEvent.PortalType;
import org.powernukkitx.event.entity.ProjectileLaunchEvent;
import org.powernukkitx.event.inventory.InventoryCloseEvent;
import org.powernukkitx.event.inventory.InventoryPickupArrowEvent;
import org.powernukkitx.event.inventory.InventoryPickupTridentEvent;
import org.powernukkitx.event.player.*;
import org.powernukkitx.event.player.PlayerInteractEvent.Action;
import org.powernukkitx.event.player.PlayerTeleportEvent.TeleportCause;
import org.powernukkitx.event.server.PacketSendEvent;
import org.powernukkitx.form.window.Form;
import org.powernukkitx.inventory.CraftTypeInventory;
import org.powernukkitx.inventory.CrafterInventory;
import org.powernukkitx.inventory.CraftingGridInventory;
import org.powernukkitx.inventory.CreativeOutputInventory;
import org.powernukkitx.inventory.EntityHandItem;
import org.powernukkitx.inventory.HumanInventory;
import org.powernukkitx.inventory.Inventory;
import org.powernukkitx.inventory.PlayerCursorInventory;
import org.powernukkitx.inventory.StructBlockInventory;
import org.powernukkitx.inventory.fake.FakeInventory;
import org.powernukkitx.inventory.fake.FakeInventoryType;
import org.powernukkitx.item.Item;
import org.powernukkitx.item.ItemArmor;
import org.powernukkitx.item.ItemArrow;
import org.powernukkitx.item.ItemBundle;
import org.powernukkitx.item.ItemID;
import org.powernukkitx.item.ItemTool;
import org.powernukkitx.item.enchantment.Enchantment;
import org.powernukkitx.lang.CommandOutputContainer;
import org.powernukkitx.lang.LangCode;
import org.powernukkitx.lang.TextContainer;
import org.powernukkitx.lang.TranslationContainer;
import org.powernukkitx.level.ChunkLoader;
import org.powernukkitx.level.GameRule;
import org.powernukkitx.level.Level;
import org.powernukkitx.level.Location;
import org.powernukkitx.level.MusicRepeatMode;
import org.powernukkitx.level.PlayerChunkManager;
import org.powernukkitx.level.Position;
import org.powernukkitx.level.Sound;
import org.powernukkitx.level.format.Chunk;
import org.powernukkitx.level.format.IChunk;
import org.powernukkitx.level.particle.BreakBlockParticle;
import org.powernukkitx.level.vibration.VibrationEvent;
import org.powernukkitx.level.vibration.VibrationType;
import org.powernukkitx.math.AxisAlignedBB;
import org.powernukkitx.math.BlockFace;
import org.powernukkitx.math.BlockVector3;
import org.powernukkitx.math.NukkitMath;
import org.powernukkitx.math.SimpleAxisAlignedBB;
import org.powernukkitx.math.Vector2;
import org.powernukkitx.math.Vector3;
import org.powernukkitx.metadata.MetadataValue;
import org.powernukkitx.nbt.tag.ByteTag;
import org.powernukkitx.nbt.tag.CompoundTag;
import org.powernukkitx.nbt.tag.FloatTag;
import org.powernukkitx.nbt.tag.ListTag;
import org.powernukkitx.nbt.tag.StringTag;
import org.powernukkitx.nbt.tag.Tag;
import org.powernukkitx.network.FlushablePeer;
import org.powernukkitx.network.primitiveshape.PrimitiveShapes;
import org.powernukkitx.network.process.PacketHandler;
import org.powernukkitx.network.process.PlayerSessionHolder;
import org.powernukkitx.network.process.auth.ClientChainData;
import org.powernukkitx.permission.PermissibleBase;
import org.powernukkitx.permission.Permission;
import org.powernukkitx.permission.PermissionAttachment;
import org.powernukkitx.permission.PermissionAttachmentInfo;
import org.powernukkitx.plugin.InternalPlugin;
import org.powernukkitx.plugin.Plugin;
import org.powernukkitx.network.positiontracking.PositionTrackingService;
import org.powernukkitx.recipe.unlock.PlayerRecipeBook;
import org.powernukkitx.registry.Registries;
import org.powernukkitx.scheduler.AsyncTask;
import org.powernukkitx.scheduler.ServerScheduler;
import org.powernukkitx.scheduler.Task;
import org.powernukkitx.scheduler.TaskHandler;
import org.powernukkitx.scoreboard.IScoreboard;
import org.powernukkitx.scoreboard.IScoreboardLine;
import org.powernukkitx.scoreboard.data.DisplaySlot;
import org.powernukkitx.scoreboard.displayer.IScoreboardViewer;
import org.powernukkitx.scoreboard.scorer.PlayerScorer;
import org.powernukkitx.utils.BlockIterator;
import org.powernukkitx.utils.BossBarColor;
import org.powernukkitx.utils.DummyBossBar;
import org.powernukkitx.utils.Identifier;
import org.powernukkitx.utils.ItemHelper;
import org.powernukkitx.utils.PortalHelper;
import org.powernukkitx.utils.TextFormat;
import org.powernukkitx.utils.Utils;

import java.awt.*;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.util.*;
import java.util.List;
import java.util.Map.Entry;
import java.util.Queue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Consumer;

/**
 * Game player object, representing the controlled character
 *
 * @author MagicDroidX &amp; Box (Nukkit Project)
 */
@Slf4j
public class Player extends EntityHuman implements CommandSender, ChunkLoader, IPlayer, IScoreboardViewer {
    /// static fields
    /**
     * An empty array of static constants that host the player
     */
    public static final Player[] EMPTY_ARRAY = new Player[0];
    public static final int SURVIVAL = 0;
    public static final int CREATIVE = 1;
    public static final int ADVENTURE = 2;
    public static final int SPECTATOR = 3;
    public static final int VIEW = SPECTATOR;
    public static final float DEFAULT_SPEED = 0.1f;
    public static final float DEFAULT_FLY_SPEED = 0.05f;
    public static final float MAXIMUM_SPEED = 0.5f;
    public static final int PERMISSION_CUSTOM = 3;
    public static final int PERMISSION_OPERATOR = 2;
    public static final int PERMISSION_MEMBER = 1;
    public static final int PERMISSION_VISITOR = 0;
    private static final byte PLAYER_FLAG_SLEEP = 0x2;
    private static final double CREATIVE_BLOCK_REACH = 13;
    private static final double SURVIVAL_BLOCK_REACH = 7;
    private static final long POST_TELEPORT_GRACE_MS = 1000L;
    private static final int INITIAL_CHUNK_RADIUS = 4;
    private static final int MIN_CLIENT_REQUESTED_CHUNK_RADIUS = 5;
    private static final int INITIAL_SPAWN_CHUNK_LIMIT = 94;
    /// static fields
    public boolean playedBefore;
    public boolean spawned = false;
    public boolean motionSent;
    public volatile boolean locallyInitialized = false;
    public volatile boolean loggedIn = false;
    public final HashSet<String> achievements = new HashSet<>();
    public int gamemode;
    public long lastBreak;
    public Vector3 speed = null;
    public long creationTime = 0;
    /**
     * Block player breaking
     */
    public Block breakingBlock = null;
    /**
     * Block direction of player breaking
     */
    public BlockFace breakingBlockFace = null;
    public EntityFishingHook fishing = null;
    public long lastSkinChange;
    protected long breakingBlockTime = 0;
    protected double blockBreakProgress = 0;
    protected int lastSentBreakTick = 0;
    private static final double MAX_BLOCK_BREAK_SECONDS = 300.0;
    protected final BedrockServerSession session;
    protected final InetSocketAddress rawSocketAddress;
    protected final Map<UUID, Player> hiddenPlayers = new HashMap<>();
    protected final Set<UUID> hiddenFromPlayerList = new HashSet<>();
    protected final int spawnThreshold;
    protected int messageLimitCounter = 2;
    protected AtomicBoolean connected = new AtomicBoolean(true);
    protected InetSocketAddress socketAddress;
    /**
     * Whether to remove the color character in the chat of the changed player as §c §1
     */
    protected String displayName;
    protected static final int RESOURCE_PACK_CHUNK_SIZE = 8 * 1024; // 8KB
    protected Vector3 sleeping = null;
    protected int chunkLoadCount = 0;
    protected int nextChunkOrderRun = 1;
    /** Wall-clock gate for the chunk-order run in {@link #checkNetwork()}. */
    private long lastChunkOrderRunMillis;
    protected Vector3 newPosition = null;
    protected int chunkRadius;
    protected int clientRequestedChunkRadius;
    protected boolean initialRespawnSearchSent;
    protected boolean initialRespawnReady;
    private static final RideableComponent PARROT_SHOULDERS =
            new RideableComponent(0, true,
                    RideableComponent.DismountMode.DEFAULT,
                    Set.of("parrot_tame"), "", 0, true, true, 2,
                    List.of(
                            new RideableComponent.Seat(0, 0,
                                    new org.powernukkitx.math.Vector3f(0.4f, -0.2f, -0.1f), 0f, null, null, null),
                            new RideableComponent.Seat(1, 2,
                                    new org.powernukkitx.math.Vector3f(-0.4f, -0.2f, -0.1f), 0f, null, null, null)));

    protected Position initialRespawnPosition;
    protected int viewDistance;
    protected Position spawnPoint;
    protected SpawnPointType spawnPointType;
    /**
     * Respawn position resolved after CLIENT_READY_TO_SPAWN.
     * It must be reused by Player#respawn so spawn-radius is only resolved once.
     */
    @Getter
    @Setter
    protected Position pendingRespawnPosition;
    protected Level pendingEndPortalDestination;
    protected boolean suppressHealthAttributePacket;
    /**
     * Represents the number of ticks the player has passed through the air.
     */
    protected int inAirTicks = 0;
    protected int startAirTicks = 5;
    protected float horizontalFlySpeed = DEFAULT_FLY_SPEED;
    protected float verticalFlySpeed = 1F;
    protected AdventureSettings adventureSettings;
    protected CompoundTag pnxExtraNbt = new CompoundTag();
    protected CompoundTag customNbt = new CompoundTag();
    protected boolean pnxExtraDirty;
    protected boolean customDirty;
    private boolean pnxExtraNbtExposed;
    private boolean customNbtExposed;
    protected final PlayerCamera camera = new PlayerCamera(this);
    protected boolean checkMovement = true;
    protected PlayerFood foodData = null;
    protected boolean enableClientCommand = true;
    protected int formWindowCount = 0;
    protected Map<Integer, Form<?>> formWindows = new Int2ObjectOpenHashMap<>();
    protected Map<Integer, Form<?>> serverSettings = new Int2ObjectOpenHashMap<>();
    /**
     * We use Google's cache to store NPC dialogs to send messages
     * The reason is that there is a chance that the client will not respond to the dialogs sent, and in certain cases we cannot clear these dialogs, which can lead to memory leaks
     * Unresponsive dialogs will be cleared after 5 minutes
     */
    protected Cache<String, FormWindowDialog> dialogWindows = Caffeine.newBuilder().expireAfterAccess(5, TimeUnit.MINUTES).build();
    protected Map<Long, DummyBossBar> dummyBossBars = new Long2ObjectLinkedOpenHashMap<>();
    protected int lastInAirTick = 0;
    protected int previousInteractTick = 0;
    private final float rotationUpdateThreshold;
    private final float movementDistanceThreshold;
    protected final Queue<Location> clientMovements = PlatformDependent.newMpscQueue(4);
    /**
     * Inbound packets handed off from the netty thread to be dispatched on the main tick thread,
     * drained in arrival order at the start of {@link #onUpdate}. See {@link #handlePacket}.
     */
    protected final Queue<BedrockPacket> inboundPackets = PlatformDependent.newMpscQueue();
    private final AtomicBoolean inboundSignalled = new AtomicBoolean();
    private @Nullable Server.PreloadedPlayerData preloadedPlayerData;
    private Consumer<BedrockPacket> inboundProcessor;
    protected volatile String pendingClose;
    private final AtomicReference<Locale> locale = new AtomicReference<>(null);
    protected int timeSinceRest;
    private String buttonText = "Button";
    private PermissibleBase perm = null;
    private int hash;
    private int exp = 0;
    private int expLevel = 0;
    private int enchSeed;
    private final int loaderId;
    private BlockVector3 lastBreakPosition = new BlockVector3();
    private boolean hasSeenCredits;
    private boolean wasInSoulSandCompatible;
    private float soulSpeedMultiplier = 1;
    private float walkSpeed = 1;
    private Entity killer = null;
    private TaskHandler delayedPosTrackingUpdate;
    protected boolean showingCredits;
    @Getter
    @Setter
    @ApiStatus.Internal
    protected volatile Level.WeatherDisplay shownWeather = Level.WeatherDisplay.NONE;
    protected static final int NO_SHIELD_DELAY = 10;
    @Getter
    @Setter
    protected PlayerBlockActionData lastBlockAction;
    protected AsyncTask preLoginEventTask = null;
    protected ClientChainData clientChainData;
    /**
     * Time to play sound when player upgrades
     */
    protected int lastPlayedLevelUpSoundTime = 0;
    /**
     * The entity that the player attacked last.
     */
    protected Entity lastAttackEntity = null;

    /**
     * Fog settings of player.
     */
    protected List<String> fogStack = new ObjectArrayList<>();
    /**
     * Recipes this player has discovered.
     */
    protected final PlayerRecipeBook recipeBook = new PlayerRecipeBook(this);
    /**
     * The entity that the player is attacked last.
     */
    protected Entity lastBeAttackEntity = null;
    @Setter
    @ApiStatus.Internal
    protected @NotNull PlayerHandle playerHandle;
    @Getter
    protected final PlayerChunkManager playerChunkManager;
    private boolean needDimensionChangeACK = false;
    /**
     * The level whose tick last updated this player. See {@link #isPreviousLevelStillTicking()}.
     */
    private volatile Level lastTickLevel;
    private Boolean openSignFront = null;
    protected Boolean flySneaking = false;
    // lastUseItem System and item cooldown
    protected final HashMap<String, Integer> cooldownTickMap = new HashMap<>();
    protected final HashMap<String, Integer> lastUseItemMap = new HashMap<>(1);
    private static final int FERTILIZER_USE_COOLDOWN = 4;
    private int lastFertilizerUseTick = Integer.MIN_VALUE;
    @Getter
    protected Item lastUsedItem = null;

    // inventory system
    protected int windowsCnt = 1;
    @Setter
    protected int closingWindowId = Integer.MIN_VALUE;
    protected final BiMap<Inventory, Byte> windows = HashBiMap.create();
    @Getter
    protected final BiMap<Byte, Inventory> windowIndex = windows.inverse();
    protected final Set<Byte> permanentWindows = new ByteOpenHashSet();
    protected CraftingGridInventory craftingGridInventory;
    protected PlayerCursorInventory playerCursorInventory;
    protected CreativeOutputInventory creativeOutputInventory;
    /**
     * Player opens its own inventory
     */
    @Getter
    @Setter
    protected boolean inventoryOpen;
    /**
     * Transient window ID used while the player has its own inventory UI open.
     * The backing inventory itself remains permanently registered as ContainerId.INVENTORY (0).
     */
    @Getter
    @Setter
    protected int inventoryWindowId = Integer.MIN_VALUE;
    /**
     * Player open its own ender chest inventory
     */
    protected boolean enderChestOpen;
    /**
     * Player open a fake inventory
     */
    protected boolean fakeInventoryOpen;

    // TODO: hack for receive a error position after teleport
    private Pair<Location, Long> lastTeleportMessage;

    private Color locatorBarColor;
    private final @NotNull PlayerInfo info;
    private final WardenWarningData wardenWarningData = new WardenWarningData();
    protected AtomicInteger shapeIds = new AtomicInteger(0);
    /**
     * Stores the current client input lock flags applied to this player.
     *
     * <p>
     * This state is server-side only. The client does NOT send
     * its input lock state back to the server, therefore, it must be cached
     * and managed manually.
     * </p>
     */
    protected EnumSet<ClientInputLockComponent> clientInputLocks = EnumSet.noneOf(ClientInputLockComponent.class);

    private final Map<Long, Runnable> ackRunnables = new HashMap<>();

    private final Set<String> declaredSoftEnums = ConcurrentHashMap.newKeySet();

    @UsedByReflection
    public Player(@NotNull BedrockServerSession session, @NotNull PlayerInfo info) {
        super(null, new CompoundTag());
        this.info = info;
        this.session = session;
        this.perm = new PermissibleBase(this);
        this.server = Server.getInstance();
        this.lastBreak = -1;
        this.socketAddress = (InetSocketAddress) this.getSession().getSocketAddress();
        this.rawSocketAddress = socketAddress;
        this.loaderId = Level.generateChunkLoaderId(this);
        this.spawnThreshold = this.server.getSettings().chunkSettings().spawnThreshold();
        this.spawnPoint = null;
        this.gamemode = this.server.getGamemode();
        this.setLevel(this.server.getDefaultLevel());
        this.viewDistance = this.server.getViewDistance();
        this.chunkRadius = INITIAL_CHUNK_RADIUS;
        this.clientRequestedChunkRadius = 0;
        this.boundingBox = new SimpleAxisAlignedBB(0, 0, 0, 0, 0, 0);
        this.lastSkinChange = -1;
        this.playerChunkManager = new PlayerChunkManager(this);
        this.creationTime = System.currentTimeMillis();
        this.displayName = info.getIdentityClaims().extraData.displayName;
        this.clientChainData = info.getClientChainData();
        this.uuid = Server.uuidFromXUID(this.getXUID());
        final ByteBuffer buffer = ByteBuffer.allocate(16);
        buffer.putLong(this.uuid.getMostSignificantBits());
        buffer.putLong(this.uuid.getLeastSignificantBits());
        this.rawUUID = buffer.array();
        this.setSkin(new Skin(info.getSkin(), info.clientChainData.isTrustedSkin()));
        this.locatorBarColor = new Color(Utils.rand(0, 255), Utils.rand(0, 255), Utils.rand(0, 255));
        this.rotationUpdateThreshold = this.server.getSettings().playerSettings().rotationUpdateThreshold();
        this.movementDistanceThreshold = this.server.getSettings().playerSettings().movementDistanceThreshold();
    }

    /**
     * Get the network Session for the player
     *
     * @return The network session of player
     */
    @NotNull
    public BedrockServerSession getSession() {
        return this.session;
    }

    /**
     * Writes the packets queued for this player right away instead of on the session's own timer,
     * see {@link FlushablePeer}. Safe to call from any thread.
     */
    @ApiStatus.Internal
    public void flushOutbound() {
        if (this.session.getPeer() instanceof FlushablePeer peer) {
            peer.flushQueued();
        }
    }

    /**
     * Converts the server-side game mode to a network packet-compatible game mode ID
     * This method addresses the discrepancy where NK Observer Mode has an ID of 3, while the original ID is 6
     *
     * @param gamemode Server-side game mode
     * @return Network layer game mode ID
     */
    public static int toNetworkGamemode(int gamemode) {
        return gamemode != SPECTATOR ? gamemode : GameType.SPECTATOR.ordinal();
    }

    /**
     * Converts a server-side game mode to its persisted Bedrock game mode ID.
     *
     * @param gamemode server-side game mode
     * @return persisted game mode ID
     */
    public static int toStorageGamemode(int gamemode) {
        return toNetworkGamemode(gamemode);
    }

    /**
     * Converts a persisted Bedrock game mode ID to the server-side representation.
     *
     * @param gamemode persisted game mode ID
     * @return server-side game mode
     */
    public static int fromStorageGamemode(int gamemode) {
        if (gamemode == GameType.SPECTATOR.ordinal()) return SPECTATOR;
        return gamemode >= SURVIVAL && gamemode <= ADVENTURE ? gamemode : SURVIVAL;
    }

    protected void onBlockBreakContinue(Vector3 pos, BlockFace face) {
        if (this.isBreakingBlock()) {
            var time = System.currentTimeMillis();
            double miningTimeRequired;

            if (this.breakingBlock instanceof CustomBlock customBlock) {
                miningTimeRequired = customBlock.breakTime(this.inventory.getItemInMainHand(), this);
            } else miningTimeRequired = this.breakingBlock.calculateBreakTime(this.inventory.getItemInMainHand(), this);

            if (!(miningTimeRequired > 0)) {
                this.resetBlockBreak();
                return;
            }
            if (!this.isBreakStillValid(pos, miningTimeRequired)) {
                this.onBlockBreakAbort(pos);
                return;
            }

            if (miningTimeRequired > 0) {
                int breakTick = Math.max(1, (int) Math.ceil(miningTimeRequired * 20));

                if (breakTick != this.lastSentBreakTick) {
                    final LevelEventPacket pk = new LevelEventPacket();
                    pk.setType(LevelEvent.BLOCK_UPDATE_BREAK);
                    pk.setPosition(Vector3f.from(this.breakingBlock.x, this.breakingBlock.y, this.breakingBlock.z));
                    pk.setData(65535 / breakTick);
                    this.getLevel().addChunkPacket(this.breakingBlock.getFloorX() >> 4, this.breakingBlock.getFloorZ() >> 4, pk);
                    this.lastSentBreakTick = breakTick;
                }

                if (face != null && !this.server.getSettings().miscSettings().overrideServerAuthBlockBreaking()) {
                    this.level.addParticle(new BreakBlockParticle(pos.add(0.5, 0.5, 0.5), this.breakingBlock, face));
                }

                long timeDiff = time - breakingBlockTime;
                blockBreakProgress += timeDiff / (breakTick * 50.0);

                if (blockBreakProgress >= 1.0) {
                    final LevelEventPacket stopPk = new LevelEventPacket();
                    stopPk.setType(LevelEvent.BLOCK_STOP_BREAK);
                    stopPk.setPosition(pos.toNetwork());
                    this.getLevel().addChunkPacket(pos.getFloorX() >> 4, pos.getFloorZ() >> 4, stopPk);

                    this.blockBreakProgress = 0;
                    this.breakingBlock = null;
                    this.breakingBlockFace = null;
                    this.lastSentBreakTick = 0;

                    this.onBlockBreakComplete(pos.asBlockVector3(), face);
                    return;
                }

                breakingBlockTime = time;
            }
        }
    }

    public void onBlockBreakStart(Vector3 pos, BlockFace face) {
        BlockVector3 blockPos = pos.asBlockVector3();
        long currentBreak = System.currentTimeMillis();

        if (this.breakingBlock != null
            && this.breakingBlock.getFloorX() == blockPos.x
            && this.breakingBlock.getFloorY() == blockPos.y
            && this.breakingBlock.getFloorZ() == blockPos.z
            && this.breakingBlockFace == face) {
            return;
        }

        if (!this.canInteract(pos.add(0.5, 0.5, 0.5), this.isCreative() ? 13 : 7)) {
            return;
        }

        Block target = this.level.getBlock(pos);
        PlayerInteractEvent playerInteractEvent = new PlayerInteractEvent(this, this.inventory.getItemInMainHand(), target, face,
            target.isAir() ? Action.LEFT_CLICK_AIR : Action.LEFT_CLICK_BLOCK);
        this.getServer().getPluginManager().callEvent(playerInteractEvent);
        playerHandle.setInteract();
        if (playerInteractEvent.isCancelled()) {
            this.inventory.sendHeldItem(this);
            this.getLevel().sendBlocks(new Player[]{this}, new Block[]{target}, UpdateBlockPacket.FLAG_ALL_PRIORITY, 0);
            if (target.getLevelBlockAtLayer(1) instanceof BlockLiquid) {
                this.getLevel().sendBlocks(new Player[]{this}, new Block[]{target.getLevelBlockAtLayer(1)}, UpdateBlockPacket.FLAG_ALL_PRIORITY, 1);
            }
            return;
        }

        target.onTouch(pos, this.getInventory().getItemInMainHand(), face, 0, 0, 0, this, playerInteractEvent.getAction());

        Block block = target.getSide(face);
        Block fire = getFireAt(target, face);
        if (fire != null) {
            if (this.canInteract(fire.add(0.5, 0.5, 0.5), this.isCreative() ? 13 : 7) && fire.isBlockChangeAllowed(this)) {
                extinguishFire(fire);
            } else {
                this.getLevel().sendBlocks(new Player[]{this}, new Block[]{fire}, UpdateBlockPacket.FLAG_ALL_PRIORITY, 0);
            }
            resetBlockBreak();
            return;
        }

        if (block.getId().equals(BlockID.SWEET_BERRY_BUSH) && block.isDefaultState()) {
            Item oldItem = playerInteractEvent.getItem();
            Item i = this.level.useBreakOn(block, oldItem, this, true);
            if (this.isSurvival() || this.isAdventure()) {
                this.getFoodData().exhaust(0.005);
                if (!i.equals(oldItem) || i.getCount() != oldItem.getCount()) {
                    inventory.setItemInMainHand(i);
                    inventory.sendHeldItem(this.getViewers().values());
                }
            }
            return;
        }

        boolean canChangeBlock = target.isBlockChangeAllowed(this);
        if (!canChangeBlock) {
            return;
        }

        if (this.isSurvival() || this.isAdventure()) {
            this.breakingBlockTime = currentBreak;
            this.blockBreakProgress = 0;

            Item hand = this.inventory.getItemInMainHand();
            double miningTimeRequired = target instanceof CustomBlock customBlock ? customBlock.breakTime(hand, this) : target.calculateBreakTime(hand, this);
            int breakTime = (int) Math.ceil(miningTimeRequired * 20);

            if (breakTime > 0) {
                final LevelEventPacket pk = new LevelEventPacket();
                pk.setType(LevelEvent.BLOCK_START_BREAK);
                pk.setPosition(pos.toNetwork());
                pk.setData(65535 / breakTime);
                this.getLevel().addChunkPacket(pos.getFloorX() >> 4, pos.getFloorZ() >> 4, pk);
                this.lastSentBreakTick = breakTime;

                if (this.getLevel().isAntiXrayEnabled() && this.getLevel().getAntiXraySystem().isPreDeObfuscate()) {
                    this.getLevel().getAntiXraySystem().deObfuscateBlock(this, face, target);
                }
            }
        }

        this.breakingBlock = target;
        this.breakingBlockFace = face;
        this.lastBreak = currentBreak;
        this.lastBreakPosition = blockPos;
    }

    private boolean isBreakStillValid(Vector3 pos, double miningTimeRequired) {
        if (!this.spawned || !this.isAlive()) {
            return false;
        }
        if (!Double.isFinite(miningTimeRequired) || miningTimeRequired > MAX_BLOCK_BREAK_SECONDS) {
            return false;
        }
        if (this.breakingBlock.getLevel() != this.level) {
            return false;
        }
        if (!this.canInteract(pos.add(0.5, 0.5, 0.5), this.isCreative() ? 13 : 7)) {
            return false;
        }
        Block current = this.level.getBlock(this.breakingBlock, false);
        return current.getId().equals(this.breakingBlock.getId());
    }

    protected void resetBlockBreak() {
        this.blockBreakProgress = 0;
        this.breakingBlock = null;
        this.breakingBlockFace = null;
        this.lastSentBreakTick = 0;
    }

    public void onBlockBreakAbort(Vector3 pos) {
        if (pos.distanceSquared(this) < 1000) { // same as with ACTION_START_BREAK
            final LevelEventPacket pk = new LevelEventPacket();
            pk.setType(LevelEvent.BLOCK_STOP_BREAK);
            pk.setPosition(pos.toNetwork());
            this.getLevel().addChunkPacket(pos.getFloorX() >> 4, pos.getFloorZ() >> 4, pk);
        }
        resetBlockBreak();
    }

    public void onBlockBreakComplete(BlockVector3 blockPos, BlockFace face) {
        if (!this.spawned || !this.isAlive()) {
            return;
        }

        Item handItem = this.getInventory().getItemInMainHand();
        Item clone = handItem.clone();

        boolean canInteract = this.canInteract(blockPos.add(0.5, 0.5, 0.5));
        if (canInteract) {
            handItem = this.level.useBreakOn(blockPos.asVector3(), face, handItem, this, true);
            if (handItem != null && this.isSurvival()) {
                this.getFoodData().exhaust(0.005);
                if (handItem.equals(clone) && handItem.getCount() == clone.getCount()) {
                    resetBlockBreak();
                    return;
                }

                if (Objects.equals(clone.getId(), handItem.getId()) || handItem.isNull()) {
                    inventory.setItemInMainHand(handItem, false);
                } else {
                    log.debug("Tried to set item {} but {} had item {} in their hand slot", handItem.getId(), this.getName(), clone.getId());
                }
                inventory.sendHeldItem(this.getViewers().values());
            } else if (handItem == null)
                this.level.sendBlocks(new Player[]{this}, new Block[]{this.level.getBlock(blockPos.asVector3())}, UpdateBlockPacket.FLAG_ALL_PRIORITY, 0);
            resetBlockBreak();
            return;
        }

        inventory.sendContents(this);
        inventory.sendHeldItem(this);

        if (blockPos.distanceSquared(this) < 100) {
            Block target = this.level.getBlock(blockPos.asVector3());
            this.level.sendBlocks(new Player[]{this}, new Block[]{target}, UpdateBlockPacket.FLAG_ALL_PRIORITY);

            BlockEntity blockEntity = this.level.getBlockEntity(blockPos.asVector3());
            if (blockEntity instanceof BlockEntitySpawnable) {
                ((BlockEntitySpawnable) blockEntity).spawnTo(this);
            }
        }
        resetBlockBreak();
    }

    private void setTitle(String text) {
        final SetTitlePacket packet = new SetTitlePacket();
        packet.setTitleType(SetTitlePacket.TitleType.TITLE);
        packet.setTitleText(Strings.nullToEmpty(text));
        packet.setFadeInTime(-1);
        packet.setStayTime(-1);
        packet.setFadeOutTime(-1);
        packet.setXuid("");
        packet.setPlatformOnlineId("");
        packet.setFilteredTitleMessage("");
        this.sendPacket(packet);
    }

    //TODO: Needs a lot on dimension
    private void setDimension(int dimension) {
        final ChangeDimensionPacket packet = new ChangeDimensionPacket();
        packet.setDimension(DimensionType.from(dimension));
        packet.setPosition(Vector3f.from(this.x, this.y, this.z));
        this.sendPacket(packet);
        this.needDimensionChangeACK = true;
    }

    @Override
    public NameableComponent getComponentNameable() {
        return new NameableComponent(false, true);
    }

    @Override
    protected void initEntity() {
        super.initEntity();
        final CompoundTag nbtMap = this.getNbt();
        this.wardenWarningData.load(nbtMap);
        Level level = this.pnxExtraNbt.containsString("SpawnLevel") ? this.server.getLevelByName(this.pnxExtraNbt.getString("SpawnLevel")) : null;

        if (level == null) {
            int spawnDimension = nbtMap.getInt("SpawnDimension", 3);

            for (Level candidate : this.server.getLevels().values()) {
                if (candidate.getDimension() == spawnDimension) {
                    level = candidate;
                    break;
                }
            }
        }

        if (level == null) level = Server.getInstance().getDefaultLevel();

        boolean hasSpawn =
                nbtMap.getInt("SpawnDimension", 3) != 3 &&
                nbtMap.getInt("SpawnX", Integer.MIN_VALUE) != Integer.MIN_VALUE &&
                nbtMap.getInt("SpawnY", Integer.MIN_VALUE) != Integer.MIN_VALUE &&
                nbtMap.getInt("SpawnZ", Integer.MIN_VALUE) != Integer.MIN_VALUE;

        if (hasSpawn) {
            this.spawnPoint = new Position(
                    nbtMap.getInt("SpawnX"),
                    nbtMap.getInt("SpawnY"),
                    nbtMap.getInt("SpawnZ"),
                    level
            );
        } else {
            this.spawnPoint = level.getSafeSpawn();
        }

        setDataFlag(ActorFlags.HIDDEN_WHEN_INVISIBLE);
        setDataFlag(ActorFlags.PUSH_TOWARDS_CLOSEST_SPACE);
        this.addDefaultWindows();
    }

    /**
     * Execute after completeLoginSequence is completed
     */
    protected void doFirstSpawn() {
        this.spawned = true;

        this.syncAvailableCommands();
        this.sendInitialInventoryOptions();
        this.resetInventory();

        this.noDamageTicks = 60;

        synchronized (playerChunkManager) {
            for (long index : playerChunkManager.getUsedChunks()) {
                int chunkX = Level.getHashX(index);
                int chunkZ = Level.getHashZ(index);
                for (Entity entity : this.level.getChunkEntities(chunkX, chunkZ).values()) {
                    if (this != entity && !entity.closed && entity.isAlive()) {
                        entity.spawnTo(this);
                    }
                }
            }
        }

        int experience = this.getExperience();
        if (experience != 0) {
            this.sendExperience(experience);
        }

        int level = this.getExperienceLevel();
        if (level != 0) {
            this.sendExperienceLevel(this.getExperienceLevel());
        }

        //Weather
        this.getLevel().sendWeather(this);

        //FoodLevel
        PlayerFood food = this.getFoodData();
        if (food.isHungry()) {
            food.sendFood();
        }

        var scoreboardManager = this.getServer().getScoreboardManager();
        if (scoreboardManager != null) { // In test environment sometimes the scoreboard level is null
            scoreboardManager.onPlayerJoin(this);
        }

        if (this.getSpawn().second() == null || this.getSpawn().second() == SpawnPointType.WORLD) {
            final Position worldSpawn = this.level.getSpawnLocation();
            this.spawnPoint = new Position(
                worldSpawn.x,
                worldSpawn.y,
                worldSpawn.z,
                worldSpawn.level
            );
            this.spawnPointType = SpawnPointType.WORLD;
        }

        final SetHealthPacket setHealthPacket = new SetHealthPacket();
        setHealthPacket.setHealth((int) this.getHealthCurrent());
        this.sendPacketImmediately(setHealthPacket);

        this.sendPlayStatus(PlayStatus.PLAYER_SPAWN, true);
        log.debug("Sent PlayStatus.PLAYER_SPAWN to {}, waiting for init packet", getName());

        final Position initialSpawnPosition = this.resolveInitialRespawnPosition();
        final Location pos = initialSpawnPosition.getLocation();

        pos.yaw = this.yaw;
        pos.pitch = this.pitch;

        this.teleport(pos, TeleportCause.PLAYER_SPAWN, false);

        this.initialRespawnPosition = null;
    }

    @Override
    protected void checkGroundState(double movX, double movY, double movZ, double dx, double dy, double dz) {
        if (!this.onGround || movX != 0 || movY != 0 || movZ != 0) {
            boolean onGround = false;

            double shrinkFactor = 0.01d;

            AxisAlignedBB realBB = this.boundingBox.shrink(shrinkFactor, shrinkFactor, shrinkFactor).clone();
            realBB.setMaxY(realBB.getMinY());
            realBB.setMinY(realBB.getMinY() - 0.5);

            Block b1 = level.getTickCachedBlock(getFloorX(), getFloorY() - 1, getFloorZ());
            Block b2 = level.getTickCachedBlock(getFloorX(), getFloorY(), getFloorZ());
            Block[] blocks = {
                level.getTickCachedBlock(getFloorX() - 1, getFloorY() - 1, getFloorZ()),
                level.getTickCachedBlock(getFloorX() + 1, getFloorY() - 1, getFloorZ()),
                level.getTickCachedBlock(getFloorX(), getFloorY() - 1, getFloorZ() + 1),
                level.getTickCachedBlock(getFloorX(), getFloorY() - 1, getFloorZ() - 1),
                level.getTickCachedBlock(getFloorX() - 1, getFloorY() - 1, getFloorZ() - 1),
                level.getTickCachedBlock(getFloorX() + 1, getFloorY() - 1, getFloorZ() - 1),
                level.getTickCachedBlock(getFloorX() + 1, getFloorY() - 1, getFloorZ() + 1),
                level.getTickCachedBlock(getFloorX() - 1, getFloorY() - 1, getFloorZ() + 1)
            };
            if ((!b1.canPassThrough() && b1.collidesWithBB(realBB)) || (!b2.canPassThrough() && b2.collidesWithBB(realBB))) {
                onGround = true;
            }
            for (Block block : blocks) {
                if (!block.canPassThrough() && block.collidesWithBB(realBB)) {
                    onGround = true;
                }
            }
            this.onGround = onGround;
        }

        this.isCollided = this.onGround;
    }

    @Override
    protected void checkBlockCollision() {
        boolean portal = false;
        boolean scaffolding = false;
        boolean endPortal = false;
        for (Block block : this.getCollisionBlocks()) {
            if (this.isSpectator()) {
                continue;
            }

            switch (block.getId()) {
                case BlockID.PORTAL -> portal = true;
                case BlockID.SCAFFOLDING -> scaffolding = true;
                case BlockID.END_PORTAL -> endPortal = true;
            }

            block.onEntityCollide(this);
            block.getLevelBlockAtLayer(1).onEntityCollide(this);
        }
        AxisAlignedBB scanBoundingBox = boundingBox.getOffsetBoundingBox(0, -0.125, 0);
        scanBoundingBox.setMaxY(boundingBox.getMinY());
        Block[] scaffoldingUnder = level.getCollisionBlocks(
            scanBoundingBox,
            true, true,
            b -> b.getId().equals(BlockID.SCAFFOLDING)
        );

        setDataFlag(ActorFlags.IN_SCAFFOLDING, scaffolding);
        setDataFlag(ActorFlags.OVER_SCAFFOLDING, scaffoldingUnder.length > 0);
        setDataFlag(ActorFlags.IN_ASCENDABLE_BLOCK, scaffolding);
        setDataFlag(ActorFlags.OVER_DESCENDABLE_BLOCK, scaffoldingUnder.length > 0);

        if (endPortal) {//handle endPortal teleport
            if (!inEndPortal) {
                inEndPortal = true;
                if (this.getRiding() == null && releaseShoulderParrots() && this.getPassengers().isEmpty()) {
                    EntityPortalEnterEvent ev = new EntityPortalEnterEvent(this, PortalType.END);
                    getServer().getPluginManager().callEvent(ev);

                    if (!ev.isCancelled()) {
                        final Position newPos = PortalHelper.convertPosBetweenEndAndOverworld(this, ev.getDestinationLevel());
                        if (newPos != null) {
                            if (newPos.getLevel().getDimension() == Level.DIMENSION_THE_END) {
                                if (teleport(newPos, TeleportCause.END_PORTAL)) {
                                    newPos.getLevel().getScheduler().scheduleDelayedTask(new Task() {
                                        @Override
                                        public void onRun(int currentTick) {
                                            // dirty hack to make sure chunks are loaded and generated before spawning player
                                            teleport(newPos, TeleportCause.END_PORTAL);
                                            BlockEndPortal.spawnObsidianPlatform(newPos);
                                        }
                                    }, 5);
                                }
                            } else if (this.hasSeenCredits) {
                                teleport(newPos, TeleportCause.END_PORTAL);
                            } else if (!this.showingCredits) {
                                PlayerShowCreditsEvent playerShowCreditsEvent = new PlayerShowCreditsEvent(this);
                                this.getServer().getPluginManager().callEvent(playerShowCreditsEvent);
                                if (!playerShowCreditsEvent.isCancelled()) {
                                    this.pendingEndPortalDestination = ev.getDestinationLevel();
                                    this.showCredits();
                                }
                            }
                        }
                    }
                }
            }
        } else {
            inEndPortal = false;
        }

        if (portal) {
            if ((this.isCreative() || this.isSpectator()) && this.inPortalTicks < 80) {
                this.inPortalTicks = 80;
            } else {
                this.inPortalTicks++;
            }
        } else {
            this.inPortalTicks = 0;
        }
    }

    protected void checkNearEntities() {
        for (Entity entity : this.level.getNearbyEntities(this.boundingBox.grow(1, 0.5, 1), this)) {
            if (entity == null) continue;
            entity.scheduleUpdate();

            if (!entity.isAlive() || !this.isAlive()) {
                continue;
            }

            this.pickupEntity(entity, true);
        }
    }

    @Override
    public Location clone() {
        return getLocation();
    }

    private static boolean isMovementChunkReady(IChunk chunk) {
        return chunk instanceof Chunk concreteChunk && concreteChunk.isGenerationComplete() && concreteChunk.isAvailable();
    }

    protected void handleMovement(Location clientPos) {
        if (!this.firstMove
                && isMovementChunkReady(this.chunk)
                && clientPos.x == this.x && clientPos.y == this.y && clientPos.z == this.z
                && clientPos.yaw == this.yaw && clientPos.pitch == this.pitch && clientPos.headYaw == this.headYaw) {
            return;
        }
        this.positionChanged = true;
        if (this.firstMove) this.firstMove = false;
        boolean invalidMotion = false;
        var revertPos = this.getLocation().clone();
        double distanceSquared = clientPos.distanceSquared(this);
        //before check
        if (isCheckingMovement() && distanceSquared > 128) {
            invalidMotion = true;
        } else if (!isMovementChunkReady(this.chunk)) {
            IChunk chunk = this.level.getChunk(clientPos.getChunkX(), clientPos.getChunkZ(), false);
            this.chunk = chunk;

            if (!isMovementChunkReady(this.chunk)) {
                invalidMotion = true;
                this.nextChunkOrderRun = 0;
                if (this.chunk != null) {
                    this.chunk.removeEntity(this);
                }
            }
        }

        if (invalidMotion) {
            this.revertClientMotion(revertPos);
            this.resetClientMovement();
            return;
        }

        //update server-side position and rotation and aabb
        this.applyClientLocationFromAuthInput(clientPos);

        //update server-side position and rotation and aabb
        Location last = new Location(this.lastX, this.lastY, this.lastZ, this.lastYaw, this.lastPitch, this.lastHeadYaw, this.level);
        Location now = this.getLocation();

        this.lastX = now.x;
        this.lastY = now.y;
        this.lastZ = now.z;
        this.lastYaw = now.yaw;
        this.lastPitch = now.pitch;
        this.lastHeadYaw = now.headYaw;

        List<Block> blocksAround = null;
        List<Block> collidingBlocks = null;
        if (this.blocksAround != null && this.collisionBlocks != null) {
            blocksAround = new ArrayList<>(this.blocksAround);
            collidingBlocks = new ArrayList<>(this.collisionBlocks);
        }

        if (!this.firstMove) {
            if (this.clientMovements.isEmpty()) {
                this.blocksAround = null;
                this.collisionBlocks = null;
            }

            boolean positionChanged = last.x != now.x || last.y != now.y || last.z != now.z;
            boolean rotationChanged = last.yaw != now.yaw || last.pitch != now.pitch || last.headYaw != now.headYaw;

            if (!positionChanged && !rotationChanged) {
                return;
            }

            PlayerMoveEvent ev = null;

            if (!PlayerMoveEvent.getHandlers().isEmpty()) {
                PlayerMoveEvent.Type moveType;

                if (positionChanged && rotationChanged) {
                    moveType = PlayerMoveEvent.Type.ALL;
                } else if (positionChanged) {
                    moveType = PlayerMoveEvent.Type.POSITION_CHANGE;
                } else {
                    moveType = PlayerMoveEvent.Type.ROTATE;
                }

                ev = new PlayerMoveEvent(this, last, now, true, moveType);

                this.server.getPluginManager().callEvent(ev);
            }

            if (!(invalidMotion = ev != null && ev.isCancelled())) { //Yes, this is intended
                if (ev != null && !now.equals(ev.getTo()) && this.riding == null) { //If plugins modify the destination
                    if (this.getGamemode() != Player.SPECTATOR)
                        this.level.getVibrationManager().callVibrationEvent(new VibrationEvent(this, ev.getTo().clone(), VibrationType.TELEPORT));
                    this.teleport(ev.getTo(), null);
                } else {
                    if (this.getGamemode() != Player.SPECTATOR && (last.x != now.x || last.y != now.y || last.z != now.z)) {
                        if (this.isOnGround() && this.isGliding()) {
                            this.level.getVibrationManager().callVibrationEvent(new VibrationEvent(this, this.getVector3(), VibrationType.ELYTRA_GLIDE));
                        } else if (this.isOnGround() && !(this.getSide(BlockFace.DOWN).getLevelBlock() instanceof BlockWool) && !this.isSneaking()) {
                            this.level.getVibrationManager().callVibrationEvent(new VibrationEvent(this, this.getVector3(), VibrationType.STEP));
                        } else if (this.isTouchingWater()) {
                            this.level.getVibrationManager().callVibrationEvent(new VibrationEvent(this, this.getLocation().clone(), VibrationType.SWIM));
                        }
                    }
                    this.broadcastMovement(false);
                }
            } else {
                this.blocksAround = blocksAround;
                this.collisionBlocks = collidingBlocks;
            }
        }

        //update speed
        if (this.speed == null) {
            this.speed = new Vector3(last.x - now.x, last.y - now.y, last.z - now.z);
        } else {
            this.speed.setComponents(last.x - now.x, last.y - now.y, last.z - now.z);
        }

        handleLogicInMove(invalidMotion, now.x - last.x, now.y - last.y, now.z - last.z);

        //if plugin cancels move
        if (invalidMotion) {
            this.setPositionAndRotation(revertPos.asVector3f().asVector3(), revertPos.getYaw(), revertPos.getPitch(), revertPos.getHeadYaw());
            this.revertClientMotion(revertPos);
            this.resetClientMovement();
        } else {
            if (distanceSquared != 0 && this.nextChunkOrderRun > 20) {
                this.nextChunkOrderRun = 20;
            }
        }
    }

    public void applyClientLocationFromAuthInput(Location clientPos) {
        double diffX = clientPos.getX() - this.x;
        double diffY = clientPos.getY() - this.y;
        double diffZ = clientPos.getZ() - this.z;

        this.setRotation(clientPos.getYaw(), clientPos.getPitch(), clientPos.getHeadYaw());
        this.fastMove(diffX, diffY, diffZ);
    }

    /**
     * Broadcasts this player's mounted position and rotation to relevant viewers.
     *
     * <p>Does nothing if the player is not riding an entity.</p>
     */
    public void broadcastMountedMovement() {
        Entity riding = this.riding;
        if (riding == null) return;

        MovePlayerPacket pk = new MovePlayerPacket();
        pk.setPlayerRuntimeID(this.runtimeId());
        pk.setPosition(Vector3f.from(
            (float) this.x,
            (float) this.y,
            (float) this.z
        ));
        pk.setRotation(Vector3f.from(
            (float) this.pitch,
            (float) this.yaw,
            (float) this.headYaw
        ));
        pk.setPositionMode(PositionMode.ONLY_HEAD_ROT);
        pk.setOnGround(this.onGround);
        pk.setRidingRuntimeID(riding.runtimeId());
        pk.setRidingRuntimeID(riding.runtimeId());
        pk.setTick(this.getServer().getTick());

        Set<Player> viewers = new HashSet<>();

        viewers.addAll(this.hasSpawned.values());
        viewers.addAll(riding.getViewers().values());

        for (Entity passenger : riding.getPassengers()) {
            if (passenger instanceof Player player) {
                viewers.add(player);
            }
        }

        viewers.remove(this);

        Server.broadcastPacket(viewers, pk);
    }

    /**
     * Hands over player data read off the level thread before this player was created, so
     * {@link #processLogin()} does not read storage itself. Ignored when it is stale by then.
     *
     * @param preloaded the preloaded data, or {@code null} to read storage during login
     */
    @ApiStatus.Internal
    public void setPreloadedPlayerData(@Nullable Server.PreloadedPlayerData preloaded) {
        this.preloadedPlayerData = preloaded;
    }

    /**
     * Installs the dispatcher used to handle this player's inbound packets. Set once by the network
     * layer; lets {@link #drainInboundPackets} run a packet through the full handle path without the
     * player owning that logic.
     */
    public void setInboundProcessor(Consumer<BedrockPacket> processor) {
        this.inboundProcessor = processor;
    }

    /**
     * Queues an inbound packet to be handled on the main tick thread, drained in arrival order at
     * the start of the next {@link #onUpdate}. Receive-side counterpart of {@link #sendPacket}.
     * <p>
     * Packets are decoded on the netty thread but their handlers mutate world, entity and inventory
     * state that is otherwise only touched by the tick. {@code NetworkPacketHandler} routes every
     * gameplay packet of a spawned player through here so handling is serialized with the tick
     * instead of racing it; only handlers flagged
     * {@link PacketHandler#runsOnNetworkThread()} and the pre-spawn login
     * sequence are dispatched immediately on the netty thread.
     */
    protected void handlePacket(BedrockPacket packet) {
        if (!this.inboundPackets.offer(packet)) {
            log.warn("Failed to enqueue inbound packet {} for player {}", packet.getClass().getSimpleName(), this.getName());
            return;
        }
        this.server.onInboundQueued(this);
    }

    /**
     * Marks this player as waiting for the server's idle inbound handling.
     *
     * @return whether it was not marked yet, so the caller has to queue it
     */
    boolean claimInboundSignal() {
        return this.inboundSignalled.compareAndSet(false, true);
    }

    void releaseInboundSignal() {
        this.inboundSignalled.set(false);
    }

    protected void drainInboundPackets() {
        final Consumer<BedrockPacket> processor = this.inboundProcessor;
        if (processor == null) {
            return;
        }
        // A handler may move this player to another level
        final Level owner = this.level;
        BedrockPacket packet;
        while (this.level == owner && (packet = this.inboundPackets.poll()) != null) {
            try {
                processor.accept(packet);
            } catch (Exception e) {
                log.error("Error handling inbound packet {} for player {}", packet.getClass().getSimpleName(), this.getName(), e);
            }
        }
    }

    /**
     * Requests that this player be closed (disconnected) on its own tick thread, after any already
     * queued inbound packets have been drained. Called from the netty thread on connection loss so
     * that the world teardown in {@link #close()} runs serialized with the level tick instead of
     * racing it. Pre-spawn players are closed directly (see {@code NetworkPacketHandler#onDisconnect}).
     */
    public void requestClose(String reason) {
        this.pendingClose = reason;
    }

    private boolean closeIfRequested() {
        final String closeReason = this.pendingClose;
        if (closeReason == null) {
            return false;
        }
        this.pendingClose = null;
        this.close(closeReason);
        return true;
    }

    /**
     * Offers a new movement task to the player, considering distance and rotation thresholds.
     * Also handles the special case where an erroneous position may be received right after teleportation.
     */
    public void offerMovementTask(Location newPosition) {
        double distance = newPosition.distance(this);
        boolean updatePosition = distance > movementDistanceThreshold;
        boolean updateRotation = Math.abs(this.getPitch() - newPosition.pitch) > rotationUpdateThreshold
            || Math.abs(this.getYaw() - newPosition.yaw) > rotationUpdateThreshold
            || Math.abs(this.getHeadYaw() - newPosition.headYaw) > rotationUpdateThreshold;

        boolean shouldHandle = this.isAlive() && this.spawned && !this.isSleeping() && (updatePosition || updateRotation);

        if (!shouldHandle) {
            return;
        }

        long now = System.currentTimeMillis();

        if (lastTeleportMessage != null && now - lastTeleportMessage.right() < POST_TELEPORT_GRACE_MS) {
            Location teleportDestination = lastTeleportMessage.left();
            double destinationDistance = newPosition.distance(teleportDestination);

            if (destinationDistance > movementDistanceThreshold) {
                return;
            }
        }

        this.newPosition = newPosition;
        if (!this.clientMovements.offer(newPosition)) {
            log.warn("Failed to enqueue movement task for player {} at position {}", this.getName(), newPosition);
        }
    }


    /**
     * @deprecated Use the overload that receives each movement component so liquid movement can use its proper axis.
     */
    @Deprecated
    protected void handleLogicInMove(boolean invalidMotion, double squaredDistance) {
        handleLogicInMove(invalidMotion, Math.sqrt(Math.max(0.0, squaredDistance)), 0.0, 0.0);
    }

    protected void handleLogicInMove(boolean invalidMotion, double deltaX, double deltaY, double deltaZ) {
        if (!invalidMotion) {
            boolean recentlyTeleported = lastTeleportMessage != null
                    && System.currentTimeMillis() - lastTeleportMessage.right() < POST_TELEPORT_GRACE_MS;
            //Handling saturation updates
            if (this.getFoodData().isEnabled() && this.getServer().getDifficulty() > 0 && !recentlyTeleported) {
                boolean underWater = this.isInsideOfWater();
                boolean inWater = this.isTouchingWater();
                double movement = calculateMovementExhaustion(
                        deltaX, deltaY, deltaZ,
                        underWater, inWater, this.isOnGround(), this.isSprinting(), this.riding != null
                );
                double jump = 0.0;
                if (this.inAirTicks == 3 && !underWater) {
                    jump = this.isSprinting() ? 0.2 : 0.05;
                }
                this.getFoodData().exhaust(movement + jump);
            }

            if (this.isOnGround()) {
                Enchantment frostWalker = inventory.getBoots().getEnchantment(Enchantment.ID_FROST_WALKER);
                if (frostWalker != null && frostWalker.getLevel() > 0 && !this.isSpectator() && this.y >= 1 && this.y <= 255) {
                    int radius = 2 + frostWalker.getLevel();
                    for (int coordX = this.getFloorX() - radius; coordX < this.getFloorX() + radius + 1; coordX++) {
                        for (int coordZ = this.getFloorZ() - radius; coordZ < this.getFloorZ() + radius + 1; coordZ++) {
                            Block block = level.getBlock(coordX, this.getFloorY() - 1, coordZ);
                            int layer = 0;
                            if ((block.isWaterLogged() && !block.canBeReplaced()) || !block.up().isAir() || (!block.isWaterLogged() && !block.getId().equals(BlockID.WATER)))
                                continue;
                            WaterFrostEvent ev = new WaterFrostEvent(block, this);
                            server.getPluginManager().callEvent(ev);
                            if (!ev.isCancelled()) {
                                level.setBlock(block, layer, Block.get(Block.FROSTED_ICE), true, false);
                                level.scheduleUpdate(level.getBlock(block, layer), ThreadLocalRandom.current().nextInt(20, 40));
                            }
                        }
                    }
                }
            }

            //Handling Soul Speed Enchantment
            int soulSpeedLevel = this.getInventory().getBoots().getEnchantmentLevel(Enchantment.ID_SOUL_SPEED);
            if (soulSpeedLevel > 0) {
                Block levelBlock = this.getLevelBlock();
                this.soulSpeedMultiplier = (soulSpeedLevel * 0.105f) + 1.3f;

                // levelBlock check is required because of soul sand being 1 pixel shorter than normal blocks
                boolean isSoulSandCompatible = levelBlock.isSoulSpeedCompatible() || levelBlock.down().isSoulSpeedCompatible();

                if (this.wasInSoulSandCompatible && !isSoulSandCompatible) {
                    this.wasInSoulSandCompatible = false;
                    this.recalcMovementSpeedFromEffects();
                } else if (!this.wasInSoulSandCompatible && isSoulSandCompatible) {
                    this.wasInSoulSandCompatible = true;
                    this.setMovementSpeed(this.getMovementSpeed() * this.soulSpeedMultiplier);
                }
            }

        }
    }

    static double calculateMovementExhaustion(double deltaX, double deltaY, double deltaZ,
                                              boolean underWater, boolean inWater, boolean onGround,
                                              boolean sprinting, boolean riding) {
        if (riding) {
            return 0.0;
        }

        float x = (float) deltaX;
        float y = (float) deltaY;
        float z = (float) deltaZ;
        float distance3D = (float) Math.sqrt(x * x + y * y + z * z);
        float distanceXZ = (float) Math.sqrt(x * x + z * z);

        if (underWater) {
            return distance3D * 0.01f;
        }
        if (inWater) {
            return distanceXZ * 0.01f;
        }
        if (onGround && sprinting) {
            return distanceXZ * 0.1f;
        }
        return 0.0;
    }

    protected void resetClientMovement() {
        this.newPosition = null;
        this.positionChanged = false;
    }

    protected void revertClientMotion(Location originalPos) {
        this.lastX = originalPos.getX();
        this.lastY = originalPos.getY();
        this.lastZ = originalPos.getZ();
        this.lastYaw = originalPos.getYaw();
        this.lastPitch = originalPos.getPitch();

        Vector3 syncPos = originalPos.add(0, 0.00001, 0);
        this.sendPosition(syncPos, originalPos.getYaw(), originalPos.getPitch(), PositionMode.RESPAWN);

        if (this.speed == null) {
            this.speed = new Vector3(0, 0, 0);
        } else {
            this.speed.setComponents(0, 0, 0);
        }
    }

    /**
     * @param block the block to test
     * @return true if the block is a fire block
     */
    public static boolean isFire(Block block) {
        return block.getId().equals(BlockID.FIRE) || block.getId().equals(BlockID.SOUL_FIRE);
    }

    /**
     * Resolves the fire block a hit refers to: either the hit block itself, or the one on the
     * given face of it.
     *
     * @param target the block that was hit
     * @param face   the face that was hit
     * @return the fire block, or null if neither is fire
     */
    @Nullable
    public static Block getFireAt(Block target, BlockFace face) {
        if (isFire(target)) {
            return target;
        }
        Block side = target.getSide(face);
        return isFire(side) ? side : null;
    }

    /**
     * Replaces the given fire block with air and plays the extinguish sound.
     *
     * @param fire the fire block to extinguish
     */
    public void extinguishFire(Block fire) {
        Level fireLevel = fire.getLevel();
        fireLevel.setBlock(fire, Block.get(BlockID.AIR), true);
        fireLevel.addLevelSoundEvent(fire, SoundEvent.EXTINGUISH_FIRE);
    }

    /**
     * Processing execution in LoginPacket
     */
    private Attribute requirePersistentAttribute(int attributeId) {
        Attribute attribute = this.attributes.get(attributeId);

        if (attribute == null) {
            throw new IllegalStateException("Canonical player data is missing attribute " + Attribute.getAttribute(attributeId).getName() + " for " + this.uuid);
        }

        return attribute;
    }

    public void processLogin() {
        if (!this.connected.get()) {
            return;
        }

        if (this.hasPermission(Server.BROADCAST_CHANNEL_USERS)) {
            this.server.getPluginManager().subscribeToPermission(Server.BROADCAST_CHANNEL_USERS, this);
        }
        if (this.hasPermission(Server.BROADCAST_CHANNEL_ADMINISTRATIVE)) {
            this.server.getPluginManager().subscribeToPermission(Server.BROADCAST_CHANNEL_ADMINISTRATIVE, this);
        }

        Player oldPlayer = null;
        for (Player p : new ArrayList<>(this.server.getOnlinePlayers().values())) {
            if (p != this && p.getName().equalsIgnoreCase(this.getName()) || this.getUniqueId().equals(p.getUniqueId())) {
                oldPlayer = p;
                break;
            }
        }
        CompoundTag nbt;
        if (oldPlayer != null) {
            oldPlayer.saveNBT();
            nbt = oldPlayer.getNbt();
            this.pnxExtraNbt = oldPlayer.pnxExtraNbt.copy();
            this.customNbt = oldPlayer.customNbt.copy();
            this.pnxExtraDirty = oldPlayer.pnxExtraDirty;
            this.customDirty = oldPlayer.customDirty;
            oldPlayer.close("disconnectionScreen.loggedinOtherLocation");
        } else {
            final Server.PreloadedPlayerData preloaded = this.preloadedPlayerData;
            this.preloadedPlayerData = null;

            Server.PlayerDataRecord playerData;
            if (preloaded != null && preloaded.uuid().equals(this.uuid)) {
                final Server.PlayerDataRecord resolved = this.server.resolvePreloadedPlayerData(preloaded);
                playerData = resolved != null ? resolved : this.server.createPlayerData(this.uuid);
            } else {
                // A save of an earlier session may still be queued, and reading before it lands would
                // bring back the state from before it
                this.server.awaitPlayerDataWrites(this.uuid);
                playerData = this.server.getOfflinePlayerDataRecord(this.uuid, true);
            }

            if (playerData == null) {
                nbt = null;
                this.pnxExtraNbt = new CompoundTag();
                this.customNbt = new CompoundTag();
            } else {
                nbt = playerData.nbt();
                this.pnxExtraNbt = playerData.pnxExtra();
                this.customNbt = playerData.custom();
            }
            this.pnxExtraDirty = false;
            this.customDirty = false;
        }

        if (nbt == null) {
            this.close(this.getLeaveMessage(), "Invalid data");
            return;
        }

        server.updateName(this.info);

        if (!this.getName().equals(this.pnxExtraNbt.getString("NameTag"))) {
            this.pnxExtraNbt.putString("NameTag", this.getName());
            this.pnxExtraDirty = true;
        }

        this.playedBefore = (this.pnxExtraNbt.getLong("lastPlayed") - this.pnxExtraNbt.getLong("firstPlayed")) > 1;

        int expLevel = Math.max(0, nbt.getInt("PlayerLevel"));
        int exp = calculateExperienceFromProgress(nbt.getFloat("PlayerLevelProgress"), expLevel);
        this.setExperience(exp, expLevel);

        this.gamemode = fromStorageGamemode(nbt.getInt("PlayerGameMode"));
        if (this.server.getForceGamemode()) {
            this.gamemode = this.server.getGamemode();
            nbt.putInt("PlayerGameMode", toStorageGamemode(this.gamemode));
        }

        this.adventureSettings = new AdventureSettings(this);
        this.adventureSettings.init(nbt);

        Level level = this.pnxExtraNbt.containsString("Level") ? this.server.getLevelByName(this.pnxExtraNbt.getString("Level")) : null;

        if (level == null) {
            level = this.server.getDefaultLevel();
            Position spawnLocation = level.getSafeSpawn();
            nbt.putList("Pos", new ListTag<FloatTag>()
                .add(new FloatTag((float) spawnLocation.x))
                .add(new FloatTag((float) spawnLocation.y))
                .add(new FloatTag((float) spawnLocation.z)));
        }

        this.setLevel(level);
        nbt.putInt("DimensionId", level.getDimension());

        if (!level.getName().equals(this.pnxExtraNbt.getString("Level"))) {
            this.pnxExtraNbt.putString("Level", level.getName());
            this.pnxExtraDirty = true;
        }

        for (var e : this.pnxExtraNbt.getCompound("Achievements").getEntrySet()) {
            if (!(e.getValue() instanceof ByteTag)) {
                continue;
            }

            if (((ByteTag) e.getValue()).getData() > 0) {
                this.achievements.add(e.getKey());
            }
        }

        this.pnxExtraNbt.putLong("lastPlayed", System.currentTimeMillis() / 1000);
        this.pnxExtraDirty = true;

        if (this.server.getAutoSave()) {
            this.server.saveOfflinePlayerData(this.uuid, nbt, this.takePnxExtraSaveSnapshot(), this.takeCustomSaveSnapshot(), true);
        }

        ListTag<FloatTag> posList = nbt.getList("Pos", FloatTag.class);

        if (!this.connected.get()) return;

        super.init(this.level.getChunk((int) posList.get(0).data >> 4, (int) posList.get(2).data >> 4, true), nbt);

        if (!this.connected.get()) {
            if (this.chunk != null) {
                this.chunk.removeEntity(this);
            }
            this.level.removeEntity(this);
            return;
        }

        Attribute healthAttribute = this.requirePersistentAttribute(Attribute.HEALTH);
        Attribute absorptionAttribute = this.requirePersistentAttribute(Attribute.ABSORPTION);
        Attribute hungerAttribute = this.requirePersistentAttribute(Attribute.FOOD);
        Attribute saturationAttribute = this.requirePersistentAttribute(Attribute.SATURATION);
        Attribute exhaustionAttribute = this.requirePersistentAttribute(Attribute.EXHAUSTION);

        super.setHealthMax(Math.max(1, Math.round(healthAttribute.getMaxValue())));
        this.health = Math.max(0f, Math.min(healthAttribute.getValue(), this.getHealthMax()));
        this.absorption = absorptionAttribute.getValue();
        this.setDataProperty(ActorDataTypes.STRUCTURAL_INTEGRITY, (int) this.health);

        this.foodData = new PlayerFood(
            this,
            Math.round(hungerAttribute.getValue()),
            saturationAttribute.getValue(),
            exhaustionAttribute.getValue()
        );

        if (this.isSpectator()) {
            this.onGround = false;
        }

        if (!this.nbt.contains("EnchantmentSeed")) {
            throw new IllegalStateException("Canonical player data is missing EnchantmentSeed for " + this.uuid);
        }

        this.enchSeed = this.nbt.getInt("EnchantmentSeed");

        if (!this.nbt.contains("TimeSinceRest")) {
            this.nbt.putInt("TimeSinceRest", 0);
        }
        this.timeSinceRest = this.nbt.getInt("TimeSinceRest");

        if (!this.nbt.contains("HasSeenCredits")) {
            this.nbt.putBoolean("HasSeenCredits", false);
        }
        this.hasSeenCredits = this.nbt.getBoolean("HasSeenCredits");

        var fogIdentifiers = this.pnxExtraNbt.getList("fogIdentifiers", StringTag.class);
        for (int i = 0; i < fogIdentifiers.size(); i++) {
            this.fogStack.add(i, fogIdentifiers.get(i).parseValue());
        }

        this.recipeBook.load(this.nbt);

        if (!this.server.getSettings().playerSettings().checkMovement()) {
            this.checkMovement = false;
        }

        log.info(server.getLanguage().tr("nukkit.player.logIn",
            TextFormat.AQUA + this.getName() + TextFormat.WHITE,
            this.getAddress(),
            String.valueOf(this.getPort()),
            this.uniqueId(),
            this.level.getName(),
            String.valueOf(NukkitMath.round(this.x, 4)),
            String.valueOf(NukkitMath.round(this.y, 4)),
            String.valueOf(NukkitMath.round(this.z, 4))));

        this.loggedIn = true;
    }

    public Vector3 getSafeSpawn() {
        Vector3 worldSpawnPoint;
        if (this.spawnPoint == null) {
            worldSpawnPoint = this.server.getDefaultLevel().getSafeSpawn();
        } else {
            worldSpawnPoint = spawnPoint;
        }
        return worldSpawnPoint;
    }

    /**
     * After the player client initialization is complete, call
     */
    public void onPlayerLocallyInitialized() {
        if (locallyInitialized) return;
        locallyInitialized = true;

        this.recipeBook.onSpawn();

        //init entity data property
        this.setDataProperty(ActorDataTypes.NAME, this.getName(), false);
        this.setDataProperty(ActorDataTypes.NAMETAG_ALWAYS_SHOW, (byte) 1, false);

        PlayerJoinEvent playerJoinEvent = new PlayerJoinEvent(this,
            new TranslationContainer(TextFormat.YELLOW + "%multiplayer.player.joined", new String[]{
                this.getDisplayName()
            })
        );

        this.server.getPluginManager().callEvent(playerJoinEvent);

        if (!playerJoinEvent.getJoinMessage().toString().trim().isEmpty()) {
            this.server.broadcastMessage(playerJoinEvent.getJoinMessage());
        }

        /*
          After initializing the player client, we send the game mode to address the issue of incorrect
          sprint speed in spectator mode. Only after the player client enters the game display is spectator mode set,
          and the sprint speed behaves normally. We force an update of the game mode to ensure that the client receives the
          mode update packet.
         */
        this.setGamemode(this.gamemode, false, null, true);
        this.sendData(this.hasSpawned.values().toArray(Player.EMPTY_ARRAY), actorDataMap);
        this.sendAttributes();
        this.spawnToAll();
        Arrays.stream(this.level.getEntities()).filter(entity -> entity.getViewers().containsKey(this.getLoaderId()) && entity instanceof EntityBoss).forEach(entity -> ((EntityBoss) entity).addBossbar(this));
    }

    /**
     * Determine if the respawn anchor is valid if the respawn anchor is valid then the anchor is respawned at the respawn anchor or reborn in bed
     * If the player has none of the above 2 then respawn at the server respawn point
     *
     * @param block The block
     * @return Is it valid respawn block
     */
    protected boolean isValidRespawnBlock(Block block) {
        if (block.getId().equals(BlockID.RESPAWN_ANCHOR) && block.getLevel().getDimension() == Level.DIMENSION_NETHER) {
            BlockRespawnAnchor anchor = (BlockRespawnAnchor) block;
            return anchor.getCharge() > 0;
        }
        if (block.getId().equals(BlockID.BED) && block.getLevel().getDimension() == Level.DIMENSION_OVERWORLD) {
            BlockBed bed = (BlockBed) block;
            return bed.isBedValid();
        }

        return false;
    }

    @Override
    public boolean isBanned() {
        return this.server.getNameBans().isBanned(this.getName());
    }

    /**
     * Resolves where this player would come back to life if they respawned right now, applying the same fallbacks
     * as {@link #respawn()} but none of its side effects - no respawn anchor charge is consumed, no
     * {@link PlayerRespawnEvent} is fired, no spawn point is rewritten and no message is sent.
     * <p>
     * The spawn point falls back to the default level spawn when its level has been unloaded, and when a
     * {@link SpawnPointType#BLOCK} spawn point no longer points at a valid respawn block - a broken bed or a depleted
     * respawn anchor. {@code respawn()} remains the authority: a plugin listening to {@link PlayerRespawnEvent} can
     * still move the player elsewhere, so the value returned here is a prediction, not a guarantee.
     * <p>
     * Reads block state and may load the spawn point's chunk, so call it from the thread that ticks that level.
     *
     * @return the predicted respawn position, never null
     */
    @NotNull
    public Position getRespawnPosition() {
        Pair<Position, SpawnPointType> spawnPair = this.getSpawn();
        Position spawnPos = spawnPair.left();

        if (spawnPos == null || spawnPos.level == null || spawnPos.level.getProvider() == null) {
            return this.getServer().getDefaultLevel().getSafeSpawn();
        }

        if (spawnPair.right() == SpawnPointType.BLOCK) {
            Block spawnBlock = spawnPos.getLevelBlock();

            if (spawnBlock == null || !isValidRespawnBlock(spawnBlock)) {
                return this.getServer().getDefaultLevel().getSafeSpawn();
            }

            return spawnPos;
        }

        if (spawnPair.right() == null || spawnPair.right() == SpawnPointType.WORLD) {
            return spawnPos.level.getSafeSpawn();
        }

        return spawnPos;
    }

    /**
     * Returns the logical position used while searching for the respawn location.
     */
    @NotNull
    public Position getRespawnSearchPosition() {
        Pair<Position, SpawnPointType> spawnPair = this.getSpawn();
        Position spawnPos = spawnPair.left();

        if (spawnPos == null || spawnPos.level == null || spawnPos.level.getProvider() == null) {
            return this.getServer().getDefaultLevel().getSpawnLocation();
        }

        if (spawnPair.right() == SpawnPointType.BLOCK) {
            Block spawnBlock = spawnPos.getLevelBlock();

            if (spawnBlock == null || !isValidRespawnBlock(spawnBlock)) {
                return this.getServer().getDefaultLevel().getSpawnLocation();
            }

            return spawnPos;
        }

        if (spawnPair.right() == null || spawnPair.right() == SpawnPointType.WORLD) {
            return spawnPos.level.getSpawnLocation();
        }

        return spawnPos;
    }

    protected void respawn() {
        //the player can't respawn if the server is hardcore
        if (this.server.isHardcore()) {
            this.setBanned(true);
            return;
        }

        Position pendingRespawn = this.pendingRespawnPosition;
        this.pendingRespawnPosition = null;

        this.resetInventory();

        //level spawn point < block spawn = self spawn
        Pair<Position, SpawnPointType> spawnPair = this.getSpawn();
        //spawn level may have been unloaded/closed (e.g. dynamic worlds), fall back to default
        Position spawnPos = spawnPair.left();
        if (spawnPos == null || spawnPos.level == null || spawnPos.level.getProvider() == null) {
            Level defaultLevel = this.getServer().getDefaultLevel();
            Position worldSpawn = defaultLevel.getSpawnLocation();
            Position resolvedSpawn = pendingRespawn != null
                    ? pendingRespawn
                    : defaultLevel.getSafeSpawn();

            this.setSpawn(worldSpawn, SpawnPointType.WORLD);
            spawnPair = Pair.of(resolvedSpawn, SpawnPointType.WORLD);
        } else if (spawnPair.right() == null || spawnPair.right() == SpawnPointType.WORLD) {
            Position resolvedSpawn = pendingRespawn != null
                    ? pendingRespawn
                    : spawnPos.level.getSafeSpawn();

            spawnPair = Pair.of(resolvedSpawn, SpawnPointType.WORLD);
        }

        PlayerRespawnEvent playerRespawnEvent = new PlayerRespawnEvent(this, spawnPair);
        if (spawnPair.right() == SpawnPointType.BLOCK) {//block spawn
            Block spawnBlock = playerRespawnEvent.getRespawnPosition().first().getLevelBlock();
            if (spawnBlock != null && isValidRespawnBlock(spawnBlock)) {
                // handle RESPAWN_ANCHOR state change when consume charge is true
                if (spawnBlock.getId().equals(BlockID.RESPAWN_ANCHOR)) {
                    BlockRespawnAnchor respawnAnchor = (BlockRespawnAnchor) spawnBlock;
                    int charge = respawnAnchor.getCharge();
                    if (charge > 0) {
                        respawnAnchor.setCharge(charge - 1);
                        respawnAnchor.getLevel().setBlock(respawnAnchor, spawnBlock);
                        respawnAnchor.getLevel().scheduleUpdate(respawnAnchor, 10);
                        respawnAnchor.getLevel().addSound(this, Sound.RESPAWN_ANCHOR_DEPLETE, 1, 1, this);
                    }
                }
            } else {//block is not available
                Level defaultLevel = this.getServer().getDefaultLevel();
                Position worldSpawn = defaultLevel.getSpawnLocation();
                Position resolvedSpawn = pendingRespawn != null
                        ? pendingRespawn
                        : defaultLevel.getSafeSpawn();

                this.setSpawn(worldSpawn, SpawnPointType.WORLD);
                playerRespawnEvent.setRespawnPosition(Pair.of(resolvedSpawn, SpawnPointType.WORLD));
                // handle spawn point change when block spawns not available
                sendMessage(new TranslationContainer(TextFormat.GRAY + "%tile." + (this.getLevel().getDimension() == Level.DIMENSION_OVERWORLD ? "bed" : "respawn_anchor") + ".notValid"));
            }
        }

        this.server.getPluginManager().callEvent(playerRespawnEvent);
        Position respawnPos = playerRespawnEvent.getRespawnPosition().first();

        this.setSprinting(false);
        this.setSneaking(false);

        this.setDataProperty(ActorDataTypes.AIR_SUPPLY, (short) 400, false);
        this.fireTicks = 0;
        this.collisionBlocks = null;
        this.noDamageTicks = 60;

        this.removeAllEffects();

        this.suppressHealthAttributePacket = true;
        try {
            this.setHealthCurrent(this.getHealthMax());
        } finally {
            this.suppressHealthAttributePacket = false;
        }

        this.getFoodData().setFood(20, 5, false);
        this.getFoodData().setExhaustion(0);

        final SetHealthPacket setHealthPacket = new SetHealthPacket();
        setHealthPacket.setHealth(this.getHealthMax());
        this.sendPacket(setHealthPacket);

        this.sendRespawnAttributes();

        this.sendData(this);

        this.setMovementSpeed(DEFAULT_SPEED);

        this.getAdventureSettings().update();
        this.inventory.sendContents(this);
        this.inventory.sendArmorContents(this);
        this.offhandInventory.sendContents(this);

        boolean sendRespawnTeleport = !respawnPos.level.equals(this.level);
        this.teleport(respawnPos, TeleportCause.PLAYER_SPAWN, sendRespawnTeleport);

        this.despawnFromAll();
        this.spawnToAll();
    }

    protected void sendRespawnAttributes() {
        final PlayerFood food = this.getFoodData();

        @SuppressWarnings("null")
        Attribute health = this.attributes.computeIfAbsent(Attribute.HEALTH, Attribute::getAttribute);
        health
                .setMaxValue(this.getHealthMax())
                .setValue(this.getHealthCurrent());

        @SuppressWarnings("null")
        Attribute hunger = this.attributes.computeIfAbsent(Attribute.FOOD, Attribute::getAttribute);
        hunger.setValue(food.getFood());

        @SuppressWarnings("null")
        Attribute exhaustion = this.attributes.computeIfAbsent(Attribute.EXHAUSTION, Attribute::getAttribute);
        exhaustion.setValue((float) food.getExhaustion());

        @SuppressWarnings("null")
        Attribute saturation = this.attributes.computeIfAbsent(Attribute.SATURATION, Attribute::getAttribute);
        saturation.setValue(food.getSaturation());

        @SuppressWarnings("null")
        Attribute level = this.attributes.computeIfAbsent(Attribute.EXPERIENCE_LEVEL, Attribute::getAttribute);
        level.setValue(this.getExperienceLevel());

        float experienceProgress = ((float) this.getExperience())
                / calculateRequireExperience(this.getExperienceLevel());

        @SuppressWarnings("null")
        Attribute experience = this.attributes.computeIfAbsent(Attribute.EXPERIENCE, Attribute::getAttribute);
        experience.setValue(Math.max(0f, Math.min(1f, experienceProgress)));

        final UpdateAttributesPacket packet = new UpdateAttributesPacket();
        packet.setRuntimeID(this.runtimeId());
        packet.getAttributeList().add(health.toNetwork());
        packet.getAttributeList().add(hunger.toNetwork());
        packet.getAttributeList().add(exhaustion.toNetwork());
        packet.getAttributeList().add(saturation.toNetwork());
        packet.getAttributeList().add(level.toNetwork());
        packet.getAttributeList().add(experience.toNetwork());

        this.sendPacket(packet);
    }

    @Override
    protected void checkChunks() {
        if (this.chunk == null || (this.chunk.getX() != ((int) this.x >> 4) || this.chunk.getZ() != ((int) this.z >> 4))) {
            if (this.chunk != null) {
                this.chunk.removeEntity(this);
            }
            this.chunk = this.level.getChunk((int) this.x >> 4, (int) this.z >> 4, true);

            if (!this.justCreated) {
                Map<Integer, Player> newChunk = this.level.getChunkPlayers((int) this.x >> 4, (int) this.z >> 4);
                newChunk.remove(this.getLoaderId());

                for (Player player : new ArrayList<>(this.hasSpawned.values())) {
                    if (!newChunk.containsKey(player.getLoaderId())) {
                        this.despawnFrom(player);
                    } else {
                        newChunk.remove(player.getLoaderId());
                    }
                }

                for (Player player : newChunk.values()) {
                    this.spawnTo(player);
                }
            }

            if (this.chunk == null) {
                return;
            }

            this.chunk.addEntity(this);
            return;
        }

        updateChunkSection();
    }

    protected void sendPlayStatus(PlayStatus status) {
        sendPlayStatus(status, false);
    }

    protected void sendPlayStatus(PlayStatus status, boolean immediate) {
        final PlayStatusPacket pk = new PlayStatusPacket();
        pk.setStatus(status);

        if (immediate) {
            this.sendPacketImmediately(pk);
        } else {
            this.sendPacket(pk);
        }
    }

    protected void forceSendEmptyChunks() {
        int chunkPositionX = this.getFloorX() >> 4;
        int chunkPositionZ = this.getFloorZ() >> 4;
        for (int x = -chunkRadius; x < chunkRadius; x++) {
            for (int z = -chunkRadius; z < chunkRadius; z++) {
                final LevelChunkPacket packet = new LevelChunkPacket();
                packet.setChunkX(chunkPositionX + x);
                packet.setChunkZ(chunkPositionZ + z);
                packet.setDimension(DimensionType.from(this.level.getDimension()));
                packet.setSerializedChunkData(Unpooled.buffer());
                this.sendPacket(packet);
            }
        }
    }

    protected void addDefaultWindows() {
        this.craftingGridInventory = new CraftingGridInventory(this);
        this.playerCursorInventory = new PlayerCursorInventory(this);
        this.creativeOutputInventory = new CreativeOutputInventory(this);

        if (this.pnxExtraNbt.containsCompound("CursorItem")) {
            this.playerCursorInventory.setItem(0, ItemHelper.read(this.pnxExtraNbt.getCompound("CursorItem")));
        }

        this.addWindow(this.getInventory(), (byte) ContainerId.INVENTORY);
        //addDefaultWindows when the player doesn't have a spawn yet,
        // so we need to manually open it to add the player to the viewer
        this.getInventory().open(this);
        this.permanentWindows.add((byte) ContainerId.INVENTORY);

        this.addWindow(this.getCreativeOutputInventory(), (byte) ContainerId.CRAFTING_ADD_INGREDIENT);
        this.getCreativeOutputInventory().open(this);
        this.permanentWindows.add((byte) ContainerId.CRAFTING_ADD_INGREDIENT);

        this.addWindow(this.getOffhandInventory(), (byte) ContainerId.OFFHAND);
        this.getOffhandInventory().open(this);
        this.permanentWindows.add((byte) ContainerId.OFFHAND);

        this.addWindow(this.getCraftingGrid(), (byte) ContainerId.NONE);
        this.getCraftingGrid().open(this);
        this.permanentWindows.add((byte) ContainerId.NONE);

        this.addWindow(this.getCursorInventory(), (byte) ContainerId.UI);
        this.getCursorInventory().open(this);
        this.permanentWindows.add((byte) ContainerId.UI);
    }

    @Override
    public float getBaseOffset() {
        return super.getBaseOffset();
    }

    @Override
    protected void onBlock(Entity entity, EntityDamageEvent e, boolean animate) {
        super.onBlock(entity, e, animate);
        if (e.isBreakShield()) {
            this.setItemCoolDown(e.getShieldBreakCoolDown(), "shield");
        }
        if (animate) {
            this.setDataFlag(ActorFlags.BLOCKED_USING_DAMAGED_SHIELD, true);
            getLevel().getScheduler().scheduleTask(InternalPlugin.INSTANCE, () -> {
                if (this.isOnline()) {
                    this.setDataFlag(ActorFlags.BLOCKED_USING_DAMAGED_SHIELD, false);
                }
            });
        }
    }

    /**
     * @return {@link #lastAttackEntity}
     */
    public Entity getLastAttackEntity() {
        return lastAttackEntity;
    }

    /**
     * @return {@link #lastBeAttackEntity}
     */
    public Entity getLastBeAttackEntity() {
        return lastBeAttackEntity;
    }

    /**
     * Return to the speed increase multiplier brought by SOUL_SPEED Enchantment
     */
    public float getSoulSpeedMultiplier() {
        return this.soulSpeedMultiplier;
    }

    /**
     * Returns the value of {@link Player#lastInAirTick},represent the last server tick the player was in the air
     *
     * @return int
     */
    public int getLastInAirTick() {
        return this.lastInAirTick;
    }

    public int getPreviousInteractTick() {
        return this.previousInteractTick;
    }

    public int getPreviousInteractTickDifference() {
        return getServer().getTick() - getPreviousInteractTick();
    }

    /**
     * Retrieves message when players leave
     *
     * @return {@link TranslationContainer}
     */
    public TranslationContainer getLeaveMessage() {
        return new TranslationContainer(TextFormat.YELLOW + "%multiplayer.player.left", this.getDisplayName());
    }

    public void setBanned(boolean value) {
        if (value) {
            this.server.getNameBans().addBan(this.getName(), null, null, null);
            this.kick(PlayerKickEvent.Reason.NAME_BANNED, "Banned by admin");
        } else {
            this.server.getNameBans().remove(this.getName());
        }
    }

    @Override
    public boolean isWhitelisted() {
        return this.server.isWhitelisted(this.getName().toLowerCase(Locale.ENGLISH));
    }

    @Override
    public void setWhitelisted(boolean value) {
        if (value) {
            this.server.addWhitelist(this.getName().toLowerCase(Locale.ENGLISH));
        } else {
            this.server.removeWhitelist(this.getName().toLowerCase(Locale.ENGLISH));
        }
    }

    @Override
    public Player getPlayer() {
        return this;
    }

    @Override
    public Long getFirstPlayed() {
        return this.pnxExtraNbt != null ? this.pnxExtraNbt.getLong("firstPlayed") : null;
    }

    @Override
    public Long getLastPlayed() {
        return this.pnxExtraNbt != null ? this.pnxExtraNbt.getLong("lastPlayed") : null;
    }

    @Override
    public boolean hasPlayedBefore() {
        return this.playedBefore;
    }

    /**
     * Gets the camera controller for this player.
     *
     * @return player camera controller
     */
    @NotNull
    public PlayerCamera getCamera() {
        return this.camera;
    }

    /**
     * Get player adventure settings.
     */
    public AdventureSettings getAdventureSettings() {
        return adventureSettings;
    }

    /**
     * Used to set player abilities, corresponding to the game's player adventure settings.
     *
     * @param adventureSettings Player adventure settings
     */
    public void setAdventureSettings(AdventureSettings adventureSettings) {
        this.adventureSettings = adventureSettings.clone();
        this.adventureSettings.update();
    }


    /**
     * Set {@link #inAirTicks} to 0
     */
    public void resetInAirTicks() {
        this.inAirTicks = 0;
    }

    public void setAllowFlight(boolean value) {
        this.getAdventureSettings().set(Type.ALLOW_FLIGHT, value);
        this.getAdventureSettings().update();
    }

    public boolean getAllowFlight() {
        return this.getAdventureSettings().get(Type.ALLOW_FLIGHT);
    }

    public void setHorizontalFlySpeed(float speed) {
        this.horizontalFlySpeed = speed;
        this.getAdventureSettings().update();
    }

    public float getHorizontalFlySpeed() {
        return horizontalFlySpeed;
    }

    public void setVerticalFlySpeed(float speed) {
        this.verticalFlySpeed = speed;
        this.getAdventureSettings().update();
    }

    public float getVerticalFlySpeed() {
        return verticalFlySpeed;
    }

    /**
     * Set allow modifying the world (after the unknown reason setting is completed, the player is not allowed to dig the blocks, but can place them)
     *
     * @param value Whether to allow modification of the world
     */
    public void setAllowModifyWorld(boolean value) {
        this.getAdventureSettings().set(Type.WORLD_IMMUTABLE, !value);
        this.getAdventureSettings().set(Type.BUILD, value);
        this.getAdventureSettings().set(Type.WORLD_BUILDER, value);
        this.getAdventureSettings().update();
    }

    public void setAllowInteract(boolean value) {
        setAllowInteract(value, value);
    }

    /**
     * Enable interactive world/container
     *
     * @param value      Is interaction with the world permitted
     * @param containers Is interaction with the container permitted
     */
    public void setAllowInteract(boolean value, boolean containers) {
        this.getAdventureSettings().set(Type.WORLD_IMMUTABLE, !value);
        this.getAdventureSettings().set(Type.DOORS_AND_SWITCHED, value);
        this.getAdventureSettings().set(Type.OPEN_CONTAINERS, containers);
        this.getAdventureSettings().update();
    }

    public void setAutoJump(boolean value) {
        this.getAdventureSettings().set(Type.AUTO_JUMP, value);
        this.getAdventureSettings().update();
    }

    public boolean hasAutoJump() {
        return this.getAdventureSettings().get(Type.AUTO_JUMP);
    }

    public void broadcastClientSyncedProperties(Player... viewers) {
        PropertySyncData data = this.getClientSyncProperties();
        if (data == null) return;

        final SetActorDataPacket packet = new SetActorDataPacket();
        packet.setActorData(this.snapshotActorDataMap());
        packet.setTargetRuntimeID(this.runtimeId());
        packet.setSyncedProperties(data);

        Player[] targets = (viewers == null || viewers.length == 0)
            ? this.getViewers().values().toArray(Player.EMPTY_ARRAY)
            : viewers;

        for (Player v : targets) {
            if (v != null) v.sendPacket(packet);
        }
    }

    @Override
    public void spawnTo(Player player) {
        if (player.spawned && this.isAlive() && player.getLevel() == this.level && player.canSee(this)/* && !this.isSpectator()*/) {
            super.spawnTo(player);
            this.broadcastClientSyncedProperties(player);

            if (this.isSpectator()) {
                // Send the spectator game mode to the other player, enabling their client to correctly render the player entity.
                var pk = new UpdatePlayerGameTypePacket();
                pk.setPlayerGameType(GameType.SPECTATOR);
                pk.setTargetPlayer(this.uniqueIdLong());
                player.sendPacket(pk);
            }
        }
    }

    @Override
    public Server getServer() {
        return this.server;
    }

    /**
     * Checks if the player has permission to use text colors in chat and signs.
     *
     * @return True if the player has the "nukkit.textcolor" permission, false otherwise.
     */
    public boolean canUseTextColor() {
        return this.hasPermission("nukkit.textcolor");
    }

    /**
     * @param player The player
     * @return Whether the player can be seen
     */
    public boolean canSee(Player player) {
        return !this.hiddenPlayers.containsKey(player.getUniqueId());
    }

    /**
     * Hide the specified player from the view of the current player instance
     *
     * @param player Players who want to hide
     */
    public void hidePlayer(Player player) {
        this.hidePlayer(player, false);
    }

    /**
     * Hide the specified player from the view of the current player instance
     *
     * @param player               Players who want to hide
     * @param hideFromPlayerList   Whether the player should also be removed from the player list
     */
    public void hidePlayer(Player player, boolean hideFromPlayerList) {
        if (this == player) {
            return;
        }
        this.hiddenPlayers.put(player.getUniqueId(), player);
        player.despawnFrom(this);

        if (hideFromPlayerList && this.hiddenFromPlayerList.add(player.getUniqueId())) {
            this.server.removePlayerListData(player.getUniqueId(), this);
        }
    }

    /**
     * Show the specified player from the view of the current player instance
     *
     * @param player Players who want to show
     */
    public void showPlayer(Player player) {
        if (this == player) {
            return;
        }
        this.hiddenPlayers.remove(player.getUniqueId());
        if (player.isOnline()) {
            if (this.hiddenFromPlayerList.remove(player.getUniqueId())) {
                this.server.updatePlayerListData(
                    player.getUniqueId(),
                    player.getId(),
                    player.getDisplayName(),
                    player.getSkin(),
                    player.getXUID(),
                    player.getLocatorBarColor(),
                    new Player[]{this}
                );
            }
            player.spawnTo(this);
        } else {
            this.hiddenFromPlayerList.remove(player.getUniqueId());
        }
    }

    @Override
    public boolean canCollideWith(Entity entity) {
        return false;
    }

    @Override
    public boolean canCollide() {
        return super.canCollide() && gamemode != SPECTATOR;
    }

    @Override
    public boolean isCollisionEnabled() {
        return super.isCollisionEnabled() && !this.isSpectator();
    }

    @Override
    public void resetFallDistance() {
        super.resetFallDistance();
        if (this.inAirTicks != 0) {
            this.startAirTicks = 5;
        }
        this.inAirTicks = 0;
        this.highestPosition = this.y;
    }

    @Override
    public boolean isOnline() {
        return this.connected.get() && this.loggedIn;
    }

    @Override
    public boolean isOp() {
        return this.server.isOp(this.getName());
    }

    @Override
    public void setOp(boolean value) {
        if (value == this.isOp()) {
            return;
        }

        if (value) {
            this.server.addOp(this.getName());
        } else {
            this.server.removeOp(this.getName());
        }
    }

    @Override
    public boolean isPermissionSet(String name) {
        return this.perm.isPermissionSet(name);
    }

    @Override
    public boolean isPermissionSet(Permission permission) {
        return this.perm.isPermissionSet(permission);
    }

    @Override
    public boolean hasPermission(String name) {
        return this.perm != null && this.perm.hasPermission(name);
    }

    @Override
    public boolean hasPermission(Permission permission) {
        return this.perm.hasPermission(permission);
    }

    @Override
    public PermissionAttachment addAttachment(Plugin plugin) {
        return this.addAttachment(plugin, null);
    }

    @Override
    public PermissionAttachment addAttachment(Plugin plugin, String name) {
        return this.addAttachment(plugin, name, null);
    }

    @Override
    public PermissionAttachment addAttachment(Plugin plugin, String name, Boolean value) {
        return this.perm.addAttachment(plugin, name, value);
    }

    @Override
    public void removeAttachment(PermissionAttachment attachment) {
        this.perm.removeAttachment(attachment);
    }

    @Override
    public void recalculatePermissions() {
        this.server.getPluginManager().unsubscribeFromPermission(Server.BROADCAST_CHANNEL_USERS, this);
        this.server.getPluginManager().unsubscribeFromPermission(Server.BROADCAST_CHANNEL_ADMINISTRATIVE, this);

        if (this.perm == null) {
            return;
        }

        this.perm.recalculatePermissions();

        if (this.hasPermission(Server.BROADCAST_CHANNEL_USERS)) {
            this.server.getPluginManager().subscribeToPermission(Server.BROADCAST_CHANNEL_USERS, this);
        }

        if (this.hasPermission(Server.BROADCAST_CHANNEL_ADMINISTRATIVE)) {
            this.server.getPluginManager().subscribeToPermission(Server.BROADCAST_CHANNEL_ADMINISTRATIVE, this);
        }

        if (this.isEnableClientCommand() && spawned) {
            this.syncAvailableCommands();
        }
    }

    public boolean isEnableClientCommand() {
        return this.enableClientCommand;
    }

    public void setEnableClientCommand(boolean enable) {
        this.enableClientCommand = enable;
        var pk = new SetCommandsEnabledPacket();
        pk.setCommandsEnabled(enable);
        this.sendPacket(pk);
        if (enable) {
            this.syncAvailableCommands();
        }
    }

    @Override
    public Map<String, PermissionAttachmentInfo> getEffectivePermissions() {
        return this.perm.getEffectivePermissions();
    }

    @Override
    public boolean isPlayer() {
        return true;
    }

    @Override
    public Player asPlayer() {
        return this;
    }

    @Override
    public boolean isEntity() {
        return true;
    }

    @Override
    public Entity asEntity() {
        return this;
    }

    public void removeAchievement(String achievementId) {
        achievements.remove(achievementId);
    }

    public boolean hasAchievement(String achievementId) {
        return achievements.contains(achievementId);
    }

    public boolean isConnected() {
        return connected.get() && this.session.isConnected();
    }

    /**
     * Get the display name of the player
     *
     * @return {@link #displayName}
     */
    public String getDisplayName() {
        return this.displayName;
    }

    /**
     * Permission that lets a command sender see players' real login names in command output
     * instead of their (possibly nicked) display names.
     *
     * @see #getViewableName(CommandSender)
     */
    public static final String VIEW_REAL_NAME_PERMISSION = "nukkit.command.viewrealname";

    /**
     * Returns this player's name as it should be shown to {@code viewer} in command output.
     * <p>
     * By default, the display name (nick) is returned to preserve nick systems. A viewer holding
     * {@link #VIEW_REAL_NAME_PERMISSION} sees the real login name instead.
     * <p>
     * Note: this resolves against a single viewer. Messages broadcast to multiple recipients are
     * rendered once using the command issuer's permission, not per recipient.
     *
     * @param viewer the sender the name is being shown to (may be null)
     * @return the real login name if {@code viewer} has {@link #VIEW_REAL_NAME_PERMISSION}, else the display name
     */
    @Override
    public String getViewableName(CommandSender viewer) {
        return viewer != null && viewer.hasPermission(VIEW_REAL_NAME_PERMISSION)
            ? this.getName() : this.getDisplayName();
    }

    /**
     * Just change the name displayed during player chat and in the server player list (Does not affect the player parameter name of the command, nor does it affect the player header display name)
     *
     * @param displayName The display name
     */
    public void setDisplayName(String displayName) {
        this.displayName = displayName;
        if (this.spawned) {
            this.server.updatePlayerListData(this.getUniqueId(), this.runtimeId(), this.getDisplayName(), this.getSkin(), this.getXUID(), this.getLocatorBarColor());
        }
    }

    @Override
    public void setSkin(Skin skin) {
        super.setSkin(skin);
        org.cloudburstmc.protocol.bedrock.data.skin.Skin serializedSkin = skin.getSkin();
        if (this.spawned) {
            var skinPacket = new PlayerSkinPacket();
            skinPacket.setUuid(this.getUniqueId());
            skinPacket.setSerializedSkin(skin.toSerializedSkin());
            skinPacket.setLocalizedNewSkinName(serializedSkin.getSkinId());
            skinPacket.setLocalizedOldSkinName("");
            Server.broadcastPacket(Server.getInstance().getOnlinePlayers().values(), skinPacket);
        }
    }

    /**
     * Retrieve the raw address
     *
     * @return {@link String}
     */
    public String getRawAddress() {
        return this.rawSocketAddress.getAddress().getHostAddress();
    }

    /**
     * Retrieve the raw port
     *
     * @return int
     */
    public int getRawPort() {
        return this.rawSocketAddress.getPort();
    }


    /**
     * Close all form windows
     */
    public void closeFormWindows() {
        this.formWindows.clear();
        this.sendPacket(new ClientboundCloseFormPacket());
    }

    /**
     * Retrieve the raw socket address
     *
     * @return {@link InetSocketAddress}
     */
    public InetSocketAddress getRawSocketAddress() {
        return this.rawSocketAddress;
    }

    /**
     * @return {@link String}
     */
    public String getAddress() {
        return this.socketAddress.getAddress().getHostAddress();
    }

    /**
     * @see #getRawPort
     */
    public int getPort() {
        return this.socketAddress.getPort();
    }

    /**
     * @return {@link InetSocketAddress}
     */
    public InetSocketAddress getSocketAddress() {
        return this.socketAddress;
    }

    /**
     * Get the position where the next tick client player will move
     *
     * @return The next position
     */
    public Position getNextPosition() {
        return this.newPosition != null ? new Position(this.newPosition.x, this.newPosition.y, this.newPosition.z, this.level) : this.getPosition();
    }

    /**
     * Whether the player is sleeping
     *
     * @return boolean
     */
    public boolean isSleeping() {
        return this.sleeping != null;
    }


    /**
     * @return {@link #inAirTicks}
     */
    public int getInAirTicks() {
        return this.inAirTicks;
    }

    /**
     * Returns whether the player is currently using an item (right-click and hold).
     */
    public boolean isUsingItem(String itemId) {
        return getLastUseTick(itemId) != -1 && this.getDataFlag(ActorFlags.USING_ITEM);
    }

    /**
     * the cooldown of specified item is ended
     *
     * @param itemId the item identifier
     * @return the boolean
     */
    public boolean isItemCoolDownEnd(Identifier itemId) {
        return isItemCoolDownEnd(itemId.toString());
    }

    /**
     * the cooldown of specified item is ended
     *
     * @param category a string category
     * @return boolean
     */
    public boolean isItemCoolDownEnd(String category) {
        int now = this.getLevel().getTick();
        int end = this.cooldownTickMap.getOrDefault(category, 0);
        boolean done = now - end >= 0;
        if (done) this.cooldownTickMap.remove(category);
        return done;
    }

    /**
     * Sets the cooldown time for the specified item to use
     *
     * @param coolDown the cool down tick
     * @param itemId   the item id
     */
    public void setItemCoolDown(int coolDown, Identifier itemId) {
        setItemCoolDown(coolDown, itemId.toString());
    }

    /**
     * Sets the cooldown time for the specified item to use
     *
     * @param coolDown the cool down tick
     * @param category a string category
     */
    public void setItemCoolDown(int coolDown, String category) {
        var pk = new PlayerStartItemCooldownPacket();
        pk.setItemCategory(category);
        pk.setDurationTicks(coolDown);
        this.cooldownTickMap.put(category, this.getLevel().getTick() + coolDown);
        this.sendPacket(pk);
    }

    public boolean isFertilizerCoolDownEnd() {
        return this.lastFertilizerUseTick == Integer.MIN_VALUE
            || this.getLevel().getTick() - this.lastFertilizerUseTick >= FERTILIZER_USE_COOLDOWN;
    }

    public void resetFertilizerCoolDown() {
        this.lastFertilizerUseTick = this.getLevel().getTick();
    }

    /**
     * Start last use tick for an item (right-click).
     *
     * @param itemId the item id
     */
    public void setLastUseTick(@NotNull String itemId, int tick) {
        lastUseItemMap.put(itemId, tick);
        this.setDataFlag(ActorFlags.USING_ITEM, true);
    }

    public void removeLastUseTick(@NotNull String itemId) {
        lastUseItemMap.remove(itemId);
        this.setDataFlag(ActorFlags.USING_ITEM, false);
    }

    public int getLastUseTick(String itemId) {
        return lastUseItemMap.getOrDefault(itemId, -1);
    }

    public void setLastUsedItem(Item item) {
        if (item == null) {
            log.warn("Tried to set last used item to null for player {}", this.getName());
            return;
        }
        this.lastUsedItem = item;
        this.setLastUseTick(item.getId(), this.getLevel().getTick());
    }

    /**
     * Get the language hardcoded for the interaction buttons that appear when mobile device players face the carrier.
     */
    public String getButtonText() {
        return this.buttonText;
    }

    /**
     * Set the language hardcoded for the interaction buttons that appear when mobile device players face the carrier.
     */
    public void setButtonText(String text) {
        this.buttonText = text;
        this.setDataProperty(ActorDataTypes.INTERACT_TEXT, this.buttonText);
    }

    public void unloadChunk(int x, int z) {
        this.unloadChunk(x, z, null);
    }

    public void unloadChunk(int x, int z, Level level) {
        level = level == null ? this.level : level;
        long index = Level.chunkHash(x, z);
        if (level.unregisterChunkLoader(this, x, z, false)) {
            boolean wasTracked;
            synchronized (playerChunkManager) {
                wasTracked = playerChunkManager.getUsedChunks().remove(index);
            }
            if (wasTracked) {
                for (Entity entity : level.getChunkEntities(x, z).values()) {
                    if (entity != this) {
                        entity.despawnFrom(this);
                    }
                }
            }
        }
    }

    /**
     * @return Is the player in the world (Dimension equal 0)
     */
    public boolean isInOverWorld() {
        return this.getLevel().getDimension() == 0;
    }

    /**
     * Get the player's spawn point
     *
     * @return {@link Position}
     */
    public Pair<Position, SpawnPointType> getSpawn() {
        return Pair.of(spawnPoint, spawnPointType);
    }

    /**
     * Gets the temporary client position used while the initial spawn is being prepared.
     *
     * @return the initial spawn staging position
     */
    public Vector3f getInitialSpawnStagingPosition() {
        return Vector3f.from(
            this.x,
            32768 + this.getEyeHeight(),
            this.z
        );
    }

    /**
     * Gets the initial client position used by StartGame and the first SEARCHING_FOR_SPAWN packet.
     */
    public Vector3f getInitialSpawnPosition() {
        if (!this.hasPlayedBefore()) {
            return this.getInitialSpawnStagingPosition();
        }

        return Vector3f.from(
            this.x,
            this.y + this.getEyeHeight(),
            this.z
        );
    }

    /**
     * Gets the base position used by the second SEARCHING_FOR_SPAWN packet.
     */
    public Vector3f getInitialSpawnBasePosition() {
        if (!this.hasPlayedBefore()) {
            return Vector3f.from(
                this.x,
                32768,
                this.z
            );
        }

        return Vector3f.from(
            this.x,
            this.y,
            this.z
        );
    }

    /**
     * Sends the initial spawn-position state used during the client login sequence.
     * <p>
     * This packet is sent before chunk loading and the actual first-spawn process.
     * It intentionally uses the unset position sentinel instead of changing the
     * player's server-side spawn point.
     * </p>
     */
    public void sendInitialSpawnPosition() {
        final SetSpawnPositionPacket packet = new SetSpawnPositionPacket();
        final Vector3i unsetPosition = Vector3i.from(
            Integer.MIN_VALUE,
            Integer.MIN_VALUE,
            Integer.MIN_VALUE
        );

        packet.setSpawnPositionType(SpawnPositionType.PLAYER_RESPAWN);
        packet.setBlockPosition(unsetPosition);
        packet.setDimensionType(DimensionType.from(3));
        packet.setSpawnBlockPos(unsetPosition);

        this.sendPacketImmediately(packet);
        this.level.sendWorldClock(this);
    }

    /**
     * Sends the initial inventory UI state before the respawn handshake.
     */
    protected void sendInitialInventoryOptions() {
        final SetPlayerInventoryOptionsPacket packet = new SetPlayerInventoryOptionsPacket();
        packet.setLeftInventoryTab(InventoryLeftTabIndex.RECIPE_SEARCH);
        packet.setRightInventoryTab(InventoryRightTabIndex.CRAFTING);
        packet.setFiltering(true);
        packet.setLayoutInv(InventoryLayout.DEFAULT);
        packet.setLayoutCraft(InventoryLayout.NONE);

        this.sendPacketImmediately(packet);
    }

    private void sendInitialRespawnSearching() {
        if (this.initialRespawnSearchSent) return;

        final RespawnPacket searchingWithEyeHeight = new RespawnPacket();
        searchingWithEyeHeight.setPosition(this.getInitialSpawnPosition());
        searchingWithEyeHeight.setState(PlayerRespawnState.SEARCHING_FOR_SPAWN);
        searchingWithEyeHeight.setPlayerRuntimeId(0);

        this.sendPacketImmediately(searchingWithEyeHeight);

        final RespawnPacket searching = new RespawnPacket();
        searching.setPosition(this.getInitialSpawnBasePosition());
        searching.setState(PlayerRespawnState.SEARCHING_FOR_SPAWN);
        searching.setPlayerRuntimeId(0);

        this.sendPacketImmediately(searching);
        this.sendInitialSpawnAttributes();

        this.initialRespawnSearchSent = true;
    }

    private void sendInitialRespawnReady() {
        if (this.initialRespawnReady) return;

        final Position resolvedPosition = this.resolveInitialRespawnPosition();
        final RespawnPacket ready = new RespawnPacket();
        ready.setPosition(Vector3f.from(resolvedPosition.x, resolvedPosition.y + this.getEyeHeight(), resolvedPosition.z));
        ready.setState(PlayerRespawnState.READY_TO_SPAWN);
        ready.setPlayerRuntimeId(0);

        if (this.sendPacketImmediately(ready)) {
            this.initialRespawnReady = true;
        }
    }

    public void sendInitialRespawnSequence() {
        this.sendInitialRespawnSearching();
        this.sendInitialRespawnReady();
    }

    protected AxisAlignedBB getInitialRespawnCandidateBoundingBox() {
        final double halfWidth = this.getWidth() / 2.0;

        return new SimpleAxisAlignedBB(
                this.x - halfWidth,
                this.y,
                this.z - halfWidth,
                this.x + halfWidth,
                this.y + this.getHeight(),
                this.z + halfWidth
        );
    }

    protected boolean isInitialRespawnAreaReady() {
        return this.level.isAreaLoaded(this.getInitialRespawnCandidateBoundingBox());
    }

    protected Position resolveInitialRespawnPosition() {
        if (this.initialRespawnPosition != null) {
            return this.initialRespawnPosition;
        }

        final Position resolvedPosition;

        if (this.server.getSettings().baseSettings().safeSpawn() && (this.gamemode & 0x01) == 0) {
            resolvedPosition = this.level.getSafeSpawn(this);
        } else {
            resolvedPosition = new Position(this.x, this.y, this.z, this.level);
        }

        this.initialRespawnPosition = new Position(resolvedPosition.x, resolvedPosition.y, resolvedPosition.z, resolvedPosition.level);
        return this.initialRespawnPosition;
    }

    protected boolean isInitialSpawnReady() {
        if (!this.loggedIn || this.spawned || !this.initialRespawnReady) return false;
        if (this.playerChunkManager.getInitialLoadedChunksScore() <= INITIAL_SPAWN_CHUNK_LIMIT) return false;
        return this.playerChunkManager.getLevelChunksSentSinceStart() > INITIAL_SPAWN_CHUNK_LIMIT;
    }

    /**
     * Sends the complete player attribute snapshot used during the initial login sequence.
     */
    public void sendInitialLoginAttributes() {
        this.sendInitialAttributes(true);
    }

    /**
     * Sends the complete player attribute snapshot used during the initial spawn handshake.
     */
    public void sendInitialSpawnAttributes() {
        this.sendInitialAttributes(false);
    }

    /**
     * Sends the player attribute snapshot used during initial login/spawn.
     *
     * @param includeLoginOnlyAttributes whether to include the additional attributes present in the initial pre-spawn snapshot
     */
    protected void sendInitialAttributes(boolean includeLoginOnlyAttributes) {
        final UpdateAttributesPacket packet = new UpdateAttributesPacket();
        packet.setRuntimeID(this.runtimeId());

        final float health = Math.max(
            0.0f,
            Math.min(this.getHealthCurrent(), this.getHealthMax())
        );

        final int requiredExperience = calculateRequireExperience(this.getExperienceLevel());
        final float experience = Math.max(
            0.0f,
            Math.min(
                1.0f,
                ((float) this.getExperience()) / requiredExperience
            )
        );

        packet.getAttributeList().add(
            Attribute.getAttribute(Attribute.HEALTH)
                .setMaxValue(this.getHealthMax())
                .setDefaultMaximum(this.getHealthMax())
                .setValue(health)
                .toNetwork()
        );

        if (includeLoginOnlyAttributes) {
            packet.getAttributeList().add(
                Attribute.getAttribute(Attribute.FOLLOW_RANGE)
                    .toNetwork()
            );

            packet.getAttributeList().add(
                Attribute.getAttribute(Attribute.KNOCKBACK_RESISTANCE)
                    .setMinValue(-2.0f)
                    .setDefaultMinimum(-2.0f)
                    .setValue(0.0f)
                    .toNetwork()
            );
        }

        packet.getAttributeList().add(
            Attribute.getAttribute(Attribute.MOVEMENT_SPEED)
                .setValue(this.getMovementSpeed())
                .toNetwork()
        );

        packet.getAttributeList().add(
            Attribute.getAttribute(Attribute.UNDER_WATER_MOVEMENT_SPEED)
                .toNetwork()
        );

        packet.getAttributeList().add(
            Attribute.getAttribute(Attribute.LAVA_MOVEMENT_SPEED)
                .toNetwork()
        );

        if (includeLoginOnlyAttributes) {
            packet.getAttributeList().add(
                Attribute.getAttribute(Attribute.ATTACK_DAMAGE)
                    .setMinValue(1.0f)
                    .setMaxValue(1.0f)
                    .setDefaultMinimum(1.0f)
                    .setDefaultMaximum(1.0f)
                    .setDefaultValue(1.0f)
                    .setValue(1.0f)
                    .toNetwork()
            );
        }

        packet.getAttributeList().add(
            Attribute.getAttribute(Attribute.ABSORPTION)
                .setValue(this.getAbsorption())
                .toNetwork()
        );

        packet.getAttributeList().add(
            Attribute.getAttribute(Attribute.LUCK)
                .toNetwork()
        );

        packet.getAttributeList().add(
            Attribute.getAttribute(Attribute.FRICTION_MODIFIER)
                .toNetwork()
        );

        packet.getAttributeList().add(
            Attribute.getAttribute(Attribute.BOUNCINESS)
                .toNetwork()
        );

        packet.getAttributeList().add(
            Attribute.getAttribute(Attribute.AIR_DRAG_MODIFIER)
                .toNetwork()
        );

        packet.getAttributeList().add(
            Attribute.getAttribute(Attribute.MAX_HUNGER)
                .setValue(this.getFoodData().getFood())
                .toNetwork()
        );

        packet.getAttributeList().add(
            Attribute.getAttribute(Attribute.SATURATION)
                .setValue(this.getFoodData().getSaturation())
                .toNetwork()
        );

        packet.getAttributeList().add(
            Attribute.getAttribute(Attribute.EXHAUSTION)
                .setValue((float) this.getFoodData().getExhaustion())
                .toNetwork()
        );

        packet.getAttributeList().add(
            Attribute.getAttribute(Attribute.EXPERIENCE_LEVEL)
                .setValue(this.getExperienceLevel())
                .toNetwork()
        );

        packet.getAttributeList().add(
            Attribute.getAttribute(Attribute.EXPERIENCE)
                .setValue(experience)
                .toNetwork()
        );

        this.sendPacketImmediately(packet);
    }

    /**
     * Set the player's spawn point.
     *
     * @param pos Spawn point
     */
    public void setSpawn(Position pos, SpawnPointType spawnPointType) {
        Preconditions.checkNotNull(pos);
        Preconditions.checkNotNull(pos.level);
        this.spawnPoint = new Position(pos.x, pos.y, pos.z, pos.level);
        this.spawnPointType = spawnPointType;
        final SetSpawnPositionPacket pk = new SetSpawnPositionPacket();
        pk.setSpawnPositionType(SpawnPositionType.PLAYER_RESPAWN);
        pk.setBlockPosition(this.spawnPoint.toNetwork().toInt());
        pk.setDimensionType(DimensionType.from(this.spawnPoint.getLevel().getDimension()));
        this.sendPacket(pk);
    }

    public void sendChunk(int x, int z, BedrockPacket packet) {
        if (!this.isConnected()) {
            return;
        }

        final long chunkHash = Level.chunkHash(x, z);

        if (!this.sendPacketAccepted(packet)) {
            synchronized (playerChunkManager) {
                this.playerChunkManager.getUsedChunks().remove(chunkHash);
            }
            return;
        }

        this.chunkLoadCount++;

        synchronized (playerChunkManager) {
            this.playerChunkManager.getUsedChunks().add(chunkHash);
        }

        final LevelChunkPacket levelChunkPacket = packet instanceof LevelChunkPacket levelChunk ? levelChunk : null;
        final boolean subChunkRequestMode =
                levelChunkPacket != null && levelChunkPacket.isClientNeedsToRequestSubChunks();

        if (levelChunkPacket != null) {
            final var serializedChunkData = levelChunkPacket.getSerializedChunkData();
            if (serializedChunkData != null) {
                this.server.getChunkPublisherBudgetController()
                        .recordChunkPayloadBytes(serializedChunkData.readableBytes());
            }
            this.playerChunkManager.onLevelChunkSent(chunkHash);
        }

        if (this.spawned && this.level.getProvider() != null) {
            for (Entity entity : this.level.getChunkEntities(x, z).values()) {
                if (this != entity && !entity.closed && entity.isAlive()) {
                    entity.spawnTo(this);
                }
            }
        }

        if (!subChunkRequestMode && this.level.getProvider() != null) {
            for (BlockEntity entity : this.level.getChunkBlockEntities(x, z).values()) {
                if (entity instanceof BlockEntitySpawnable spawnable) {
                    spawnable.spawnTo(this);
                }
            }
        }

        if (!subChunkRequestMode) {
            this.server.getScheduler().scheduleDelayedTask(() -> {
                if (!this.isConnected() || this.level == null) return;
                for (BlockEntity entity : this.level.getChunkBlockEntities(x, z).values()) {
                    if ((entity instanceof BlockEntityItemFrame || entity instanceof BlockEntitySign) && !entity.closed) {
                        ((BlockEntitySpawnable) entity).spawnTo(this);
                    }
                }
            }, 2);
        }

        if (this.needDimensionChangeACK) {
            this.needDimensionChangeACK = false;
            final PlayerActionPacket playerActionPacket = new PlayerActionPacket();
            playerActionPacket.setPlayerRuntimeID(this.runtimeId());
            playerActionPacket.setAction(PlayerActionType.CHANGE_DIMENSION_ACK);
            playerActionPacket.setBlockPosition(this.toNetwork().toInt());
            playerActionPacket.setResultPos(this.toNetwork().toInt());
            this.sendPacket(playerActionPacket);
        }
    }

    public void updateTrackingPositions() {
        updateTrackingPositions(false);
    }

    public void updateTrackingPositions(boolean delayed) {
        Server server = getServer();
        if (delayed) {
            if (delayedPosTrackingUpdate != null) {
                delayedPosTrackingUpdate.cancel();
            }
            ServerScheduler scheduler = level == null ? server.getScheduler() : level.getScheduler();
            delayedPosTrackingUpdate = scheduler.scheduleDelayedTask(null, this::updateTrackingPositions, 10);
            return;
        }
        PositionTrackingService positionTrackingService = server.getPositionTrackingService();
        positionTrackingService.forceRecheck(this);
    }

    private boolean callPacketSendEvent(BedrockPacket packet) {
        if (PacketSendEvent.getHandlers().isEmpty()) {
            return true;
        }
        final PacketSendEvent event = new PacketSendEvent(this, packet);
        this.server.getPluginManager().callEvent(event);
        return !event.isCancelled();
    }

    protected boolean sendPacketAccepted(BedrockPacket packet) {
        // Deliberately the session's flag and not isConnected(): close() clears the player's own
        // flag on entry and still sends packets while it tears the player down.
        if (!this.session.isConnected()) {
            return false;
        }
        if (!this.callPacketSendEvent(packet)) {
            return false;
        }
        this.getSession().sendPacket(packet);
        return true;
    }

    /**
     * Sends a packet to network session
     *
     * @param packet packet to send
     */
    public void sendPacket(BedrockPacket packet) {
        this.sendPacketAccepted(packet);
    }

    /**
     * Sends a bunch of packets to network session
     *
     * @param packets packets to send
     */
    public void sendPackets(BedrockPacket... packets) {
        for (BedrockPacket packet : packets) {
            this.sendPacket(packet);
        }
    }

    public void sendSleepingPlayersStatus(int ableToSleep, int overworldPlayerCount, int sleepingPlayerCount) {
        this.sendSleepingPlayersStatus(ableToSleep, overworldPlayerCount, sleepingPlayerCount, false);
    }

    @ApiStatus.Internal
    public void sendSleepingPlayersStatusImmediately(int ableToSleep, int overworldPlayerCount, int sleepingPlayerCount) {
        this.sendSleepingPlayersStatus(ableToSleep, overworldPlayerCount, sleepingPlayerCount, true);
    }

    private void sendSleepingPlayersStatus(int ableToSleep, int overworldPlayerCount, int sleepingPlayerCount, boolean immediately) {
        final LevelEventGenericPacket packet = new LevelEventGenericPacket();
        packet.setType(LevelEvent.SLEEPING_PLAYERS);
        packet.setTag(new CompoundTag()
                .putInt("ableToSleep", ableToSleep)
                .putInt("overworldPlayerCount", overworldPlayerCount)
                .putInt("sleepingPlayerCount", sleepingPlayerCount)
                .toNetwork()
        );

        if (immediately) {
            this.sendPacketImmediately(packet);
        } else {
            this.sendPacket(packet);
        }
    }

    /**
     * Get the network latency of the player.
     *
     * @return the latency in milliseconds, or -1 if the connection can no longer be measured
     */
    public long getPing() {
        final Channel channel = this.session.getPeer().getChannel();
        return channel instanceof NetherNetChannel netherNet ? netherNet.getPing() : -1;
    }

    public boolean sleepOn(Vector3 pos) {
        if (!this.isOnline()) {
            return false;
        }

        for (Entity p : this.level.getNearbyEntities(this.boundingBox.grow(2, 1, 2), this)) {
            if (p instanceof Player player && player.sleeping != null && pos.distance(player.sleeping) <= 0.1) {
                return false;
            }
        }

        PlayerBedEnterEvent ev = new PlayerBedEnterEvent(this, this.level.getBlock(pos));
        this.server.getPluginManager().callEvent(ev);

        if (ev.isCancelled()) {
            return false;
        }

        this.sleeping = pos.clone();
        this.teleport(new Location(pos.x + 0.5, pos.y + 0.5, pos.z + 0.5, this.yaw, this.pitch, this.level), null);

        this.setDataProperty(ActorDataTypes.BED_POSITION, Vector3i.from((int) pos.x, (int) pos.y, (int) pos.z));
        this.setPlayerSleepFlag(true);

        Block sleepingBlock = this.level.getBlock(pos);
        if (!(sleepingBlock instanceof BlockBed bed) || bed.setsRespawnPoint()) {
            this.setSpawn(Position.fromObject(pos, getLevel()), SpawnPointType.BLOCK);
        }
        this.level.sleepTicks = 75;
        this.timeSinceRest = 0;

        this.server.broadcastSleepingPlayersStatus();

        return true;
    }

    public void stopSleep() {
        this.stopSleep(true);
    }

    @ApiStatus.Internal
    public void stopSleep(boolean updateSleepingPlayers) {
        if (this.sleeping == null) {
            return;
        }

        Block sleepingBlock = this.level.getBlock(this.sleeping);
        this.server.getPluginManager().callEvent(new PlayerBedLeaveEvent(this, sleepingBlock));

        this.sleeping = null;
        this.setDataProperty(ActorDataTypes.BED_POSITION, Vector3i.ZERO);
        this.setPlayerSleepFlag(false);

        if (sleepingBlock instanceof BlockBed bed) {
            bed.onSleepEnd(this);
        }

        this.level.sleepTicks = 0;

        if (updateSleepingPlayers) {
            this.server.broadcastSleepingPlayersStatus();
        }

        final AnimatePacket pk = new AnimatePacket();
        pk.setTargetRuntimeID(this.runtimeId());
        pk.setAction(AnimatePacket.Action.WAKE_UP);
        this.sendPacket(pk);
    }

    protected void setPlayerSleepFlag(boolean sleeping) {
        byte flags = this.getDataProperty(ActorDataTypes.PLAYER_FLAGS, (byte) 0);

        this.setDataProperty(
            ActorDataTypes.PLAYER_FLAGS,
            sleeping ? (byte) (flags | PLAYER_FLAG_SLEEP) : (byte) (flags & ~PLAYER_FLAG_SLEEP)
        );

        this.setDataFlag(ActorFlags.SLEEPING, sleeping, true);
    }

    public boolean awardAchievement(String achievementId) {
        if (!Server.getInstance().getSettings().gameplaySettings().achievements()) {
            return false;
        }

        Achievement achievement = Achievement.achievements.get(achievementId);

        if (achievement == null || hasAchievement(achievementId)) {
            return false;
        }

        for (String id : achievement.requires) {
            if (!this.hasAchievement(id)) {
                return false;
            }
        }
        PlayerAchievementAwardedEvent event = new PlayerAchievementAwardedEvent(this, achievementId);
        this.server.getPluginManager().callEvent(event);

        if (event.isCancelled()) {
            return false;
        }

        this.achievements.add(achievementId);
        achievement.broadcast(this);
        return true;
    }

    /**
     * Get player gamemode.
     *
     * @return int
     */
    public int getGamemode() {
        return gamemode;
    }

    public boolean setGamemode(int gamemode) {
        return this.setGamemode(gamemode, false, null);
    }

    /**
     * AdventureSettings=null
     *
     * @see #setGamemode(int, boolean, AdventureSettings)
     */
    public boolean setGamemode(int gamemode, boolean serverSide) {
        return this.setGamemode(gamemode, serverSide, null);
    }

    public boolean setGamemode(int gamemode, boolean serverSide, AdventureSettings newSettings) {
        return this.setGamemode(gamemode, serverSide, newSettings, false);
    }

    /**
     * Set player gamemode
     *
     * @param gamemode    The player game mode to set
     * @param serverSide  Whether to update only the game mode of players on the server side. If true, the game mode update package will not be sent to the client
     * @param newSettings New Adventure Settings
     * @param forceUpdate Whether to force an update. If true, the check for the parameter 'gamemode' will be canceled
     * @return boolean
     */
    public boolean setGamemode(int gamemode, boolean serverSide, AdventureSettings newSettings, boolean forceUpdate) {
        if (!forceUpdate && (gamemode < 0 || gamemode > 3 || this.gamemode == gamemode)) {
            return false;
        }

        if (newSettings == null) {
            newSettings = this.getAdventureSettings().clone();
            newSettings.set(Type.WORLD_IMMUTABLE, (gamemode & 0x02) > 0);
            newSettings.set(Type.BUILD, (gamemode & 0x02) <= 0);
            newSettings.set(Type.WORLD_BUILDER, (gamemode & 0x02) <= 0);
            newSettings.set(Type.ALLOW_FLIGHT, (gamemode & 0x01) > 0);
            newSettings.set(Type.NO_CLIP, gamemode == SPECTATOR);
            newSettings.set(Type.FLYING, switch (gamemode) {
                case SURVIVAL -> false;
                case CREATIVE -> newSettings.get(Type.FLYING);
                case ADVENTURE -> false;
                case SPECTATOR -> true;
                default -> throw new IllegalStateException("Unexpected game mode: " + gamemode);
            });
        }

        PlayerGameModeChangeEvent ev;
        this.server.getPluginManager().callEvent(ev = new PlayerGameModeChangeEvent(this, gamemode, newSettings));

        if (ev.isCancelled()) {
            return false;
        }

        this.gamemode = gamemode;

        if (this.isSpectator()) {
            this.onGround = false;
        }
        this.setDataFlag(ActorFlags.HAS_COLLISION, this.canCollide());

        this.nbt.putInt("PlayerGameMode", toStorageGamemode(this.gamemode));

        this.setAdventureSettings(ev.getNewAdventureSettings());

        if (!serverSide) {
            var pk = new UpdatePlayerGameTypePacket();
            var networkGamemode = toNetworkGamemode(gamemode);
            final GameType gameType = GameType.from(networkGamemode);
            pk.setPlayerGameType(gameType);
            pk.setTargetPlayer(this.uniqueIdLong());
            var players = Sets.newHashSet(Server.getInstance().getOnlinePlayers().values());
            // Do not send UpdatePlayerGameTypePacket to itself; we will use SetPlayerGameTypePacket instead.
            players.remove(this);
            // We need to send this packet to all players so that player clients can correctly render player entities.
            Server.broadcastPacket(players, pk);
            // Observer Mode players are invisible to players with GM levels 0, 1, and 2.
            var pk2 = new SetPlayerGameTypePacket();
            pk2.setPlayerGameType(gameType);
            this.sendPacket(pk2);
        }

        this.resetFallDistance();

        return true;
    }

    public void sendSettings() {
        this.getAdventureSettings().update();
    }

    /**
     * Whether the player is in survival mode
     *
     * @return boolean
     */
    public boolean isSurvival() {
        return this.gamemode == SURVIVAL;
    }

    /**
     * Whether the player is in creative mode
     *
     * @return boolean
     */
    public boolean isCreative() {
        return this.gamemode == CREATIVE;
    }

    /**
     * Whether the player is in spectator mode
     *
     * @return boolean
     */
    public boolean isSpectator() {
        return this.gamemode == SPECTATOR;
    }

    /**
     * Whether the player is in adventure mode
     *
     * @return boolean
     */
    public boolean isAdventure() {
        return this.gamemode == ADVENTURE;
    }

    public boolean isIgnoredByEntities() {
        return this.isCreative() || this.isSpectator() || !this.isOnline() || adventureSettings.get(AbilitiesIndex.INVULNERABLE);
    }

    @Override
    public void setInvulnerable(boolean value) {
        invulnerable = value;
        this.getAdventureSettings().set(AbilitiesIndex.INVULNERABLE, value).update();
    }

    @Override
    public Item[] getDrops(@NotNull Item weapon) {
        if (this.isCreative() || this.isSpectator()) {
            return Item.EMPTY_ARRAY;
        }

        List<Item> drops = new ArrayList<>(Arrays.asList(super.getDrops(weapon)));
        for (Inventory inventory : this.getInventoriesDroppedOnDeath()) {
            for (Item item : inventory.getContents().values()) {
                if (!item.isNull() && !item.keepOnDeath()) {
                    drops.add(item);
                }
            }
        }

        return drops.toArray(Item.EMPTY_ARRAY);
    }

    @ApiStatus.Internal
    public boolean fastMove(double dx, double dy, double dz) {
        this.x += dx;
        this.y += dy;
        this.z += dz;
        this.recalculateBoundingBox(true);

        this.checkChunks();

        if (!this.isSpectator()) {
            this.checkGroundState(dx, dy, dz, dx, dy, dz);
            this.updateFallState(this.onGround);
        }
        return true;
    }


    @ApiStatus.Internal
    public AxisAlignedBB reCalcOffsetBoundingBox() {
        float dx = this.getWidth() / 2;
        float dz = this.getWidth() / 2;
        return this.offsetBoundingBox.setBounds(
            this.x - dx, this.y, this.z - dz,
            this.x + dx, this.y + this.getHeight(), this.z + dz
        );
    }

    @Override
    public void addMovement(double x, double y, double z, double yaw, double pitch, double headYaw) {
        this.sendPosition(new Vector3(x, y, z), yaw, pitch, PositionMode.NORMAL, this.getViewers().values().toArray(EMPTY_ARRAY));
    }

    /**
     * @param motion The motion vector
     * @return boolean
     */
    @Override
    public boolean setMotion(Vector3 motion) {
        if (super.setMotion(motion)) {
            if (this.chunk != null) {
                this.addMotion(this.motionX, this.motionY, this.motionZ);  // Send it to others
                final SetActorMotionPacket packet = new SetActorMotionPacket();
                packet.setTargetRuntimeID(this.runtimeId());
                packet.setMotion(Vector3f.from(this.motionX, this.motionY, this.motionZ));
                this.sendPacket(packet);  // Send it to self
                this.motionSent = true;
            }
            if (this.motionY > 0) {
                //todo: check this
                this.startAirTicks = (int) ((-(Math.log(this.getGravity() / (this.getGravity() + this.getDrag() * this.motionY))) / this.getDrag()) * 2 + 5);
            }

            return true;
        }

        return false;
    }

    /**
     * Send attributes to the client
     */
    public void sendAttributes() {
        UpdateAttributesPacket pk = new UpdateAttributesPacket();
        pk.setRuntimeID(this.runtimeId());
        pk.getAttributeList().addAll(
            Arrays.asList(
                Attribute.getAttribute(Attribute.HEALTH).setMaxValue(this.getHealthMax()).setValue(health > 0 ? (health < getHealthMax() ? health : getHealthMax()) : 0).toNetwork(),
                Attribute.getAttribute(Attribute.ABSORPTION).setValue(this.getAbsorption()).toNetwork(),
                Attribute.getAttribute(Attribute.MAX_HUNGER).setValue(this.getFoodData().getFood()).toNetwork(),
                Attribute.getAttribute(Attribute.SATURATION).setValue(this.getFoodData().getSaturation()).toNetwork(),
                Attribute.getAttribute(Attribute.EXHAUSTION).setValue((float) this.getFoodData().getExhaustion()).toNetwork(),
                Attribute.getAttribute(Attribute.MOVEMENT_SPEED).setValue(this.getMovementSpeed()).toNetwork(),
                Attribute.getAttribute(Attribute.EXPERIENCE_LEVEL).setValue(this.getExperienceLevel()).toNetwork(),
                Attribute.getAttribute(Attribute.EXPERIENCE).setValue(((float) this.getExperience()) / calculateRequireExperience(this.getExperienceLevel())).toNetwork()
            )
        );
        this.sendPacket(pk);
    }

    @Override
    public Set<String> typeFamily() {
        return Set.of("player");
    }

    @Override
    public boolean isPersistent() {
        return true;
    }

    @Override
    public void setSwimming(boolean value) {
        // Stopping a swim at a height of 1 block will still send a STOPSWIMMING ACTION from the client, but the player will still be swimming height,so skip the action
        if (!value && level.getBlock(up()).isSolid() && level.getBlock(down()).isSolid()) {
            return;
        }
        super.setSwimming(value);
    }

    @Override
    public boolean onUpdate(int currentTick) {
        if (!this.loggedIn) {
            return this.connected.get();
        }

        if (this.isPreviousLevelStillTicking()) {
            return true;
        }
        this.lastTickLevel = this.level;

        int tickDiff = currentTick - this.lastUpdate;

        if (tickDiff == 0) {
            return true;
        }

        this.wardenWarningData.tick(tickDiff);

        if (tickDiff < 0) {
            // Every level thread keeps its own tick counter, so after a cross-level teleport a
            // stale tick from the previous level can leave lastUpdate ahead of this level's
            // counter. Without resyncing, this player would never be ticked again (no inbound
            // packet draining, no movement, no chat/commands).
            tickDiff = 1;
        }

        this.messageLimitCounter = 2;

        this.lastUpdate = currentTick;

        if (this.fishing != null && this.level.getTick() % 20 == 0) {
            if (this.distance(fishing) > 33) {
                this.stopFishing(false);
            }
        }

        if (!this.isAlive() && this.spawned) {
            final Level owner = this.level;
            this.drainInboundPackets();
            if (this.level != owner) {
                return true;
            }
            if (this.closeIfRequested()) {
                return true;
            }
            if (this.isAlive()) {
                return true;
            }
            if (this.getLevel().getGameRules().getBoolean(GameRule.DO_IMMEDIATE_RESPAWN)) {
                this.despawnFromAll();
                return true;
            }
            getLevel().getScheduler().scheduleDelayedTask(InternalPlugin.INSTANCE, () -> {
                if (!this.isAlive()) {
                    this.despawnFromAll();
                }
            }, 10);
            return true;
        }

        if (this.spawned) {
            final Level owner = this.level;
            this.drainInboundPackets();

            // Draining may close the player synchronously (e.g. self-kick), nulling the
            // inventory; bail out before the getInventory() access below throws an NPE.
            if (!this.loggedIn) {
                return true;
            }

            // A handler moved this player to another level
            if (this.level != owner) {
                return true;
            }

            if (this.closeIfRequested()) {
                return true;
            }

            if (this.motionX != 0 || this.motionY != 0 || this.motionZ != 0) {
                if (!this.motionSent) this.setMotion(new Vector3(motionX, motionY, motionZ));
                motionX = motionY = motionZ = 0;
            }

            this.motionSent = false;

            while (!this.clientMovements.isEmpty()) {
                this.handleMovement(this.clientMovements.poll());
            }

            if (!this.isSpectator()) {
                this.checkNearEntities();
            }

            Item itemInHand = this.getInventory().getItemInMainHand();
            if (!itemInHand.isNull() && this.isUsingItem(itemInHand.getId())) {
                itemInHand.whileUsing(this);
            }

            this.entityBaseTick(tickDiff);

            this.recipeBook.updateWaterState();

            if (this.isOnFire() && this.lastUpdate % 10 == 0) {
                if (this.isCreative() && !this.isInsideOfFire()) {
                    this.extinguish();
                } else if (this.getLevel().isRaining()) {
                    if (this.getLevel().canBlockSeeSky(this)) {
                        this.extinguish();
                    }
                }
            }

            if (!this.isSpectator() && this.speed != null) {
                if (this.onGround) {
                    if (this.inAirTicks != 0) {
                        this.startAirTicks = 5;
                    }
                    this.inAirTicks = 0;
                    this.highestPosition = this.y;
                    if (this.isGliding()) {
                        this.setGliding(false);
                    }
                } else {
                    this.lastInAirTick = level.getTick();
                    if (this.y > highestPosition) {
                        this.highestPosition = this.y;
                    }

                    // Wiki: When gliding with elytra, the fall height resets to 1 block if the vertical descent rate falls below 0.5 blocks per tick.
                    // Wiki: Players landing at a sufficiently low angle and speed will not take fall damage. The critical damage angle for landing is 50°, with damage equivalent to falling directly from the highest point of the glide to the landing spot.
                    if (this.isGliding() && Math.abs(this.speed.y) < 0.5 && this.getPitch() <= 40) {
                        this.resetFallDistance();
                    }

                    ++this.inAirTicks;
                }

                if (this.getFoodData() != null) {
                    this.getFoodData().tick(tickDiff);
                }

                // Durability calculation
                if (this.isGliding()) {
                    HumanInventory playerInventory = this.getInventory();
                    if (playerInventory != null) {
                        Item chestplate = playerInventory.getChestplate();
                        if ((chestplate == null || !chestplate.getId().equals(ItemID.ELYTRA))) {
                            this.setGliding(false);
                        } else if (this.age % (20 * (chestplate.getEnchantmentLevel(Enchantment.ID_DURABILITY) + 1)) == 0 && !isCreative()) {
                            int newDamage = chestplate.getDamage() + 1;
                            if (newDamage < chestplate.getMaxDurability()) {
                                chestplate.setDamage(newDamage);
                                playerInventory.setChestplate(chestplate);
                            } else {
                                this.setGliding(false);
                            }
                        }
                    }
                }
            }

            if (!this.isSleeping()) {
                this.timeSinceRest++;
            }
            if (!this.server.getSettings().miscSettings().overrideServerAuthBlockBreaking()) {
                onBlockBreakContinue(breakingBlock, breakingBlockFace);
            }

            // Reset move status
            this.newPosition = null;
            this.positionChanged = false;
            if (this.speed == null) {
                this.speed = new Vector3(0, 0, 0);
            } else {
                this.speed.setComponents(0, 0, 0);
            }
        }

        if (currentTick % 10 == 0) {
            this.checkInteractNearby();
        }

        if (this.spawned && !this.dummyBossBars.isEmpty() && currentTick % 100 == 0) {
            this.dummyBossBars.values().forEach(DummyBossBar::updateBossEntityPosition);
        }

        PlayerFood foodData = getFoodData();
        if (this.ticksLived % 40 == 0 && foodData != null) {
            foodData.sendFood();
        }

        return true;
    }

    /**
     * Check for nearby interactable entities (not generally used by plugins)
     */
    public void checkInteractNearby() {
        int interactDistance = isCreative() ? 5 : 3;
        if (canInteract(this, interactDistance)) {
            if (getEntityPlayerLookingAt(interactDistance) != null) {
                EntityInteractable onInteract = getEntityPlayerLookingAt(interactDistance);
                setButtonText(onInteract.getInteractButtonText(this));
            } else {
                setButtonText("");
            }
        } else {
            setButtonText("");
        }
    }

    private EntityInteractable getEntityAtPosition(Entity[] nearbyEntities, int x, int y, int z) {
        for (Entity nearestEntity : nearbyEntities) {
            if (nearestEntity.getFloorX() == x && nearestEntity.getFloorY() == y && nearestEntity.getFloorZ() == z
                && nearestEntity instanceof EntityInteractable
                && ((EntityInteractable) nearestEntity).canDoInteraction()) {
                return (EntityInteractable) nearestEntity;
            }
        }
        return null;
    }

    /**
     * Returns the Entity the player is looking at currently
     *
     * @param maxDistance The maximum distance to check for entities
     * @return Entity|null Either NULL if no entity is found or an instance of the entity
     */
    public EntityInteractable getEntityPlayerLookingAt(int maxDistance) {
        EntityInteractable entity = null;

        // just a fix because player MAY not be fully initialized
        if (temporalVector != null) {
            Entity[] nearbyEntities = level.getNearbyEntities(boundingBox.grow(maxDistance, maxDistance, maxDistance), this);

            // get all blocks in looking direction until the max interact distance is reached (it's possible that startblock isn't found!)
            try {
                BlockIterator itr = new BlockIterator(level, getPosition(), getDirectionVector(), getEyeHeight(), maxDistance);
                if (itr.hasNext()) {
                    Block block;
                    while (itr.hasNext()) {
                        block = itr.next();
                        entity = getEntityAtPosition(nearbyEntities, block.getFloorX(), block.getFloorY(), block.getFloorZ());
                        if (entity != null) {
                            break;
                        }
                    }
                }
            } catch (Exception ex) {
                // nothing to log here!
            }
        }
        return entity;
    }

    public int getEnchantmentSeed() {
        return this.enchSeed;
    }

    public void setEnchantmentSeed(int seed) {
        this.enchSeed = seed;
    }

    /**
     * Generates a new enchantment seed.
     *
     * @return generated enchantment seed
     */
    public static int generateEnchantmentSeed() {
        return ThreadLocalRandom.current().nextInt(Integer.MAX_VALUE);
    }

    public void regenerateEnchantmentSeed() {
        this.enchSeed = generateEnchantmentSeed();
    }

    /**
     * Whether this player was moved here out of a level whose tick is still running on another thread.
     * Every level switch makes the player visible to the new level while the old level's thread may
     * still be finishing the move (e.g. the rest of {@link #teleport}), so the new level holds off until
     * that tick is over. Always false in shared tick mode, where every level ticks on the main loop.
     */
    private boolean isPreviousLevelStillTicking() {
        Level previous = this.lastTickLevel;
        return previous != null && previous != this.level && previous.isTickedByAnotherThread();
    }

    public void checkNetwork() {
        if (!this.isOnline() || this.isPreviousLevelStillTicking()) {
            return;
        }

        if (this.loggedIn && !this.spawned && !this.initialRespawnSearchSent) {
            this.sendInitialRespawnSearching();
        }

        if (this.nextChunkOrderRun-- <= 0 || this.chunk == null) {
            this.nextChunkOrderRun = 0;
            // Vanilla cadence is one run per 20 Hz tick;
            // gate by wall clock to keep that cadence at any tick rate.
            long now = System.currentTimeMillis();
            if (now - this.lastChunkOrderRunMillis >= 50) {
                this.lastChunkOrderRunMillis = now;
                playerChunkManager.tick();
            }
        }

        if (this.loggedIn && !this.spawned && !this.initialRespawnReady && this.isInitialRespawnAreaReady()) {
            this.sendInitialRespawnReady();
        }

        if (this.isInitialSpawnReady()) {
            this.doFirstSpawn();
        }
    }

    /**
     * Same as {@link #canInteract(Vector3, double)} with the reach a player is allowed for block
     * interactions, which is longer in creative mode.
     *
     * @param pos the position the client claims to be acting on
     * @return whether this player is close enough to it, and facing it
     */
    public boolean canInteract(Vector3 pos) {
        return this.canInteract(pos, this.isCreative() ? CREATIVE_BLOCK_REACH : SURVIVAL_BLOCK_REACH);
    }

    public boolean canInteract(Vector3 pos, double maxDistance) {
        return this.canInteract(pos, maxDistance, 6.0);
    }

    public boolean canInteract(Vector3 pos, double maxDistance, double maxDiff) {
        if (this.distanceSquared(pos) > maxDistance * maxDistance) {
            return false;
        }

        Vector2 dV = this.getDirectionPlane();
        double dot = dV.dot(new Vector2(this.x, this.z));
        double dot1 = dV.dot(new Vector2(pos.x, pos.z));
        return (dot1 - dot) >= -maxDiff;
    }

    /**
     * Sends a chat message as this player. If the message begins with a / (forward-slash) it will be treated
     * as a command.
     *
     * @param message Message to send
     * @return boolean
     */
    public boolean chat(String message) {
        if (!this.spawned || !this.isAlive()) {
            return false;
        }

        this.resetInventory();

        if (!this.canUseTextColor()) {
            message = TextFormat.clean(message, true);
        }

        if (message.startsWith("/")) {
            Server.getInstance().executeCommand(this, message);
            return true;
        }

        for (String msg : message.split("\n")) {
            if (!msg.trim().isEmpty() && msg.length() <= 512 && this.messageLimitCounter-- > 0) {
                PlayerChatEvent chatEvent = new PlayerChatEvent(this, msg);
                this.server.getPluginManager().callEvent(chatEvent);
                if (!chatEvent.isCancelled()) {
                    this.server.broadcastMessage(this.getServer().getLanguage().tr(chatEvent.getFormat(), new String[]{chatEvent.getPlayer().getDisplayName(), chatEvent.getMessage()}), chatEvent.getRecipients());
                }
            }
        }

        return true;
    }

    /**
     * reason=empty string
     *
     * @see #kick(PlayerKickEvent.Reason, String, String, boolean)
     */
    public boolean kick() {
        return this.kick("");
    }

    /**
     * {@link PlayerKickEvent.Reason} = {@link PlayerKickEvent.Reason#UNKNOWN}
     *
     * @see #kick(PlayerKickEvent.Reason, String, String, boolean)
     */
    public boolean kick(String reason, boolean isAdmin) {
        return this.kick(PlayerKickEvent.Reason.UNKNOWN, reason, isAdmin);
    }

    /**
     * {@link PlayerKickEvent.Reason} = {@link PlayerKickEvent.Reason#UNKNOWN}
     *
     * @see #kick(PlayerKickEvent.Reason, String, String, boolean)
     */
    public boolean kick(String reason) {
        return kick(PlayerKickEvent.Reason.UNKNOWN, reason);
    }

    /**
     * {@link PlayerKickEvent.Reason} = {@link PlayerKickEvent.Reason#UNKNOWN}
     *
     * @see #kick(PlayerKickEvent.Reason, String, String, boolean)
     */
    public boolean kick(String reason, String disconnectScreenMessage) {
        return kick(PlayerKickEvent.Reason.UNKNOWN, reason, disconnectScreenMessage);
    }

    /**
     * {@link PlayerKickEvent.Reason} = {@link PlayerKickEvent.Reason#UNKNOWN}
     *
     * @see #kick(PlayerKickEvent.Reason, String, String, boolean)
     */
    public boolean kick(String reason, String disconnectScreenMessage, boolean isAdmin) {
        return kick(PlayerKickEvent.Reason.UNKNOWN, reason, disconnectScreenMessage, isAdmin);
    }

    /**
     * @see #kick(PlayerKickEvent.Reason, String, String, boolean)
     */
    public boolean kick(PlayerKickEvent.Reason reason) {
        return this.kick(reason, true);
    }

    /**
     * @see #kick(PlayerKickEvent.Reason, String, String, boolean)
     */
    public boolean kick(PlayerKickEvent.Reason reason, String reasonString) {
        return this.kick(reason, reasonString, true);
    }

    /**
     * @see #kick(PlayerKickEvent.Reason, String, String, boolean)
     */
    public boolean kick(PlayerKickEvent.Reason reason, String reasonString, String disconnectScreenMessage) {
        return this.kick(reason, reasonString, disconnectScreenMessage, true);
    }

    /**
     * @see #kick(PlayerKickEvent.Reason, String, String, boolean)
     */
    public boolean kick(PlayerKickEvent.Reason reason, boolean isAdmin) {
        return this.kick(reason, reason.toString(), isAdmin);
    }

    /**
     * @see #kick(PlayerKickEvent.Reason, String, String, boolean)
     */
    public boolean kick(PlayerKickEvent.Reason reason, String reasonString, boolean isAdmin) {
        return this.kick(reason, reasonString, reasonString, isAdmin);
    }

    /**
     * Kicks the player.
     *
     * @param reason                  Reason enum
     * @param reasonString            Reason String shown inside the console
     * @param disconnectScreenMessage Reason String shown on the player's screen
     * @param isAdmin                 Whether from the administrator kicked out
     * @return boolean
     */
    public boolean kick(PlayerKickEvent.Reason reason, String reasonString, String disconnectScreenMessage, boolean isAdmin) {
        PlayerKickEvent ev;
        this.server.getPluginManager().callEvent(ev = new PlayerKickEvent(this, reason, reasonString, disconnectScreenMessage, this.getLeaveMessage()));
        if (!ev.isCancelled()) {
            String finalReason;
            String message;
            if (isAdmin) {
                if (!Server.getInstance().getNameBans().isBanned(getName())) {
                    finalReason = "Kicked by admin." + (!reasonString.isEmpty() ? " Reason: " + reasonString : "");
                    message = "Kicked by admin." + (!disconnectScreenMessage.isEmpty() ? " Reason: " + disconnectScreenMessage : (!reasonString.isEmpty() ? " Reason: " + reasonString : ""));
                } else {
                    finalReason = reasonString;
                    message = disconnectScreenMessage;
                }
            } else {
                finalReason = reasonString.isEmpty() ? "disconnectionScreen.noReason" : reasonString;
                if (disconnectScreenMessage.isEmpty()) {
                    message = "disconnectionScreen.noReason";
                } else {
                    message = disconnectScreenMessage;
                }
            }

            this.close(ev.getQuitMessage(), finalReason, message);

            return true;
        }

        return false;
    }

    /**
     * Set the player's viewing distance (range 2--{@link Server#getViewDistance})
     *
     * @param distance view distance
     */
    public void setViewDistance(int distance) {
        int clampedDistance = NukkitMath.clamp(distance, 2, this.server.getViewDistance());
        this.applyViewDistance(clampedDistance);
    }

    /**
     * Stores the chunk radius requested by the client and applies its server-clamped value.
     * <p>
     * Client requests normally use a minimum radius of
     * {@link #MIN_CLIENT_REQUESTED_CHUNK_RADIUS}, but the configured server view
     * distance remains the absolute upper limit.
     *
     * @param distance client-requested chunk radius
     */
    public void setClientRequestedChunkRadius(int distance) {
        this.clientRequestedChunkRadius = distance;
        int clampedDistance = Math.min(this.server.getViewDistance(), Math.max(MIN_CLIENT_REQUESTED_CHUNK_RADIUS, distance));
        this.applyViewDistance(clampedDistance);
    }

    protected void applyViewDistance(int clampedDistance) {
        int previousDistance = this.chunkRadius;
        this.chunkRadius = clampedDistance;

        ChunkRadiusUpdatedPacket pk = new ChunkRadiusUpdatedPacket();
        pk.setChunkRadius(clampedDistance);

        this.sendPacket(pk);

        if (previousDistance != clampedDistance) {
            this.playerChunkManager.handleViewDistanceChange();
        }
    }

    /**
     * Returns the raw chunk radius requested by the client.
     *
     * @return client-requested chunk radius
     */
    public int getClientRequestedChunkRadius() {
        return this.clientRequestedChunkRadius;
    }

    /**
     * Get the player's viewing distance
     *
     * @return int
     */
    public int getViewDistance() {
        return this.chunkRadius;
    }

    @Override
    public void sendMessage(String message) {
        if (message.isEmpty()) {
            log.warn("{} attempted to send an empty message", name);
            return;
        }

        final MessageOnly messageOnly = new MessageOnly();
        messageOnly.setMessage(this.server.getLanguage().tr(message));

        final TextPacket pk = new TextPacket();
        pk.setMessageType(TextPacketType.RAW);
        pk.setSendersXUID("");
        pk.setBody(messageOnly);

        this.sendPacket(pk);
    }

    @Override
    public void sendMessage(TextContainer message) {
        if (message instanceof TranslationContainer) {
            this.sendTranslation(message.getText(), ((TranslationContainer) message).getParameters());
            return;
        }
        this.sendMessage(message.getText());
    }


    public void sendCommandOutput(CommandOutputContainer container) {
        if (this.level.getGameRules().getBoolean(GameRule.SEND_COMMAND_FEEDBACK)) {
            var pk = new CommandOutputPacket();
            pk.getOutputMessages().addAll(container.getMessages());
            pk.setOriginData(
                new CommandOriginData(
                    CommandOriginType.PLAYER,
                    this.getUniqueId(),
                    "",
                    -1L
                )
            );
            pk.setOutputType(CommandOutputType.ALL_OUTPUT);
            pk.setSuccessCount(container.getSuccessCount());
            this.sendPacket(pk);
        }
    }

    /**
     * Send a JSON text in the player chat bar
     *
     * @param text JSON text
     */

    public void sendRawTextMessage(RawText text) {
        final MessageOnly messageOnly = new MessageOnly();
        messageOnly.setMessage(text.toRawText());

        final TextPacket pk = new TextPacket();
        pk.setMessageType(TextPacketType.TEXT_OBJECT);
        pk.setSendersXUID("");
        pk.setBody(messageOnly);
        this.sendPacket(pk);
    }

    /**
     * @see #sendTranslation(String, String[])
     */
    public void sendTranslation(String message) {
        this.sendTranslation(message, EmptyArrays.EMPTY_STRINGS);
    }

    /**
     * Send a multilingual translated text in the player chat bar, example:<br> {@code message="Test Message {%0} {%1}" parameters=["Hello", "World"]}<br>
     * actual message content {@code "Test Message Hello World"}
     *
     * @param message    Translation message
     * @param parameters Translation parameters
     */
    public void sendTranslation(String message, String[] parameters) {
        boolean forceTranslate = this.server.getSettings().baseSettings().forceServerTranslate()
            || parameters.length > 4;

        final TextPacketType type;
        final TextPacketBody body;
        if (forceTranslate) {
            type = TextPacketType.RAW;
            body = new MessageOnly();
            body.setMessage(this.server.getLanguage().tr(message, parameters));
        } else {
            type = TextPacketType.TRANSLATE;
            body = new MessageAndParams();
            body.setMessage(this.server.getLanguage().tr(message, parameters, "nukkit.", true));
            for (final String parameter : parameters) {
                ((MessageAndParams) body).getParameterList().add(
                    this.server.getLanguage().tr(parameter, parameters, "nukkit.", true)
                );
            }
        }

        final TextPacket packet = new TextPacket();
        packet.setMessageType(type);
        packet.setLocalize(true);
        packet.setSendersXUID("");
        packet.setBody(body);

        this.sendPacket(packet);
    }

    /**
     * @see #sendChat(String, String)
     */
    public void sendChat(String message) {
        this.sendChat("", message);
    }

    /**
     * Send a text in the player chat bar
     *
     * @param message The chat message
     */
    public void sendChat(String source, String message) {
        final AuthorAndMessage body = new AuthorAndMessage();
        body.setPlayerName(source);
        body.setMessage(this.server.getLanguage().tr(message));

        final TextPacket pk = new TextPacket();
        pk.setMessageType(TextPacketType.CHAT);
        pk.setSendersXUID("");
        pk.setBody(body);
        this.sendPacket(pk);
    }

    /**
     * @see #sendPopup(String, String)
     */
    public void sendPopup(String message) {
        this.sendPopup(message, "");
    }

    /**
     * Send a pop-up text above the player's item bar
     *
     * @param message The popup message
     */
    // TODO: Support Translation Parameters
    public void sendPopup(String message, String subtitle) {
        final MessageAndParams body = new MessageAndParams();
        body.setMessage(this.server.getLanguage().tr(message));

        final TextPacket pk = new TextPacket();
        pk.setMessageType(TextPacketType.POPUP);
        pk.setSendersXUID("");
        pk.setBody(body);
        this.sendPacket(pk);
    }

    /**
     * Send a tip text above the player's item bar
     *
     * @param message The tip message
     */
    public void sendTip(String message) {
        final MessageOnly messageOnly = new MessageOnly();
        messageOnly.setMessage(this.server.getLanguage().tr(message));

        final TextPacket pk = new TextPacket();
        pk.setMessageType(TextPacketType.TIP);
        pk.setSendersXUID("");
        pk.setBody(messageOnly);
        this.sendPacket(pk);
    }

    /**
     * Clears away the title info being displayed on the player.
     */
    public void clearTitle() {
        SetTitlePacket pk = new SetTitlePacket();
        pk.setTitleType(SetTitlePacket.TitleType.CLEAR);
        pk.setTitleText("");
        pk.setXuid("");
        pk.setPlatformOnlineId("");
        pk.setFilteredTitleMessage("");
        this.sendPacket(pk);
    }

    /**
     * Resets both title animation times and subtitle for the next shown title.
     */
    public void resetTitleSettings() {
        SetTitlePacket pk = new SetTitlePacket();
        pk.setTitleType(SetTitlePacket.TitleType.RESET);
        pk.setTitleText("");
        pk.setXuid("");
        pk.setPlatformOnlineId("");
        pk.setFilteredTitleMessage("");
        this.sendPacket(pk);
    }

    /**
     * Set subtitle to be displayed below the main title.
     *
     * @param subtitle The subtitle message
     */
    public void setSubtitle(String subtitle) {
        SetTitlePacket pk = new SetTitlePacket();
        pk.setTitleType(SetTitlePacket.TitleType.SUBTITLE);
        pk.setTitleText(Strings.nullToEmpty(subtitle));
        pk.setXuid("");
        pk.setPlatformOnlineId("");
        pk.setFilteredTitleMessage("");
        this.sendPacket(pk);
    }

    /**
     * Set a JSON text subtitle.
     *
     * @param text JSON text
     */

    public void setRawTextSubTitle(RawText text) {
        SetTitlePacket pk = new SetTitlePacket();
        pk.setTitleType(SetTitlePacket.TitleType.SUBTITLE_TEXT_OBJECT);
        pk.setTitleText(text == null ? "" : text.toRawText());
        pk.setXuid("");
        pk.setPlatformOnlineId("");
        pk.setFilteredTitleMessage("");
        this.sendPacket(pk);
    }

    /**
     * Set title animation time
     *
     * @param fadein   Fade-in time
     * @param duration Duration time
     * @param fadeout  Fade-out time
     */
    public void setTitleAnimationTimes(int fadein, int duration, int fadeout) {
        SetTitlePacket pk = new SetTitlePacket();
        pk.setTitleType(SetTitlePacket.TitleType.TIMES);
        pk.setTitleText("");
        pk.setFadeInTime(fadein);
        pk.setStayTime(duration);
        pk.setFadeOutTime(fadeout);
        pk.setXuid("");
        pk.setPlatformOnlineId("");
        pk.setFilteredTitleMessage("");
        this.sendPacket(pk);
    }

    /**
     * Set a JSON text title.
     *
     * @param text JSON text
     */

    public void setRawTextTitle(RawText text) {
        SetTitlePacket pk = new SetTitlePacket();
        pk.setTitleType(SetTitlePacket.TitleType.TITLE_TEXT_OBJECT);
        pk.setTitleText(text == null ? "" : text.toRawText());
        pk.setXuid("");
        pk.setPlatformOnlineId("");
        pk.setFilteredTitleMessage("");
        this.sendPacket(pk);
    }


    /**
     * {@code subtitle=null,fadeIn=20,stay=20,fadeOut=5}
     *
     * @see #sendTitle(String, String, int, int, int)
     */
    public void sendTitle(String title) {
        this.sendTitle(title, null, 20, 20, 5);
    }

    /**
     * {@code fadeIn=20,stay=20,fadeOut=5}
     *
     * @see #sendTitle(String, String, int, int, int)
     */
    public void sendTitle(String title, String subtitle) {
        this.sendTitle(title, subtitle, 20, 20, 5);
    }

    /**
     * Send a title text in the center of the player's view.
     *
     * @param title    Title
     * @param subtitle Subtitle
     * @param fadeIn   Fade-in duration
     * @param stay     Stay duration
     * @param fadeOut  Fade-out duration
     */
    public void sendTitle(String title, String subtitle, int fadeIn, int stay, int fadeOut) {
        this.setTitleAnimationTimes(fadeIn, stay, fadeOut);
        if (!Strings.isNullOrEmpty(subtitle)) {
            this.setSubtitle(subtitle);
        }
        // title won't send it if an empty string is used.
        this.setTitle(Strings.isNullOrEmpty(title) ? " " : title);
    }


    /**
     * fadein=1,duration=0,fadeout=1
     *
     * @see #sendActionBar(String, int, int, int)
     */
    public void sendActionBar(String title) {
        this.sendActionBar(title, 1, 0, 1);
    }

    /**
     * Send an actionbar text above the player's item bar.
     *
     * @param title    the message
     * @param fadein   the fade-in time
     * @param duration the display duration
     * @param fadeout  the fade-out time
     */
    public void sendActionBar(String title, int fadein, int duration, int fadeout) {
        this.setTitleAnimationTimes(fadein, duration, fadeout);
        SetTitlePacket pk = new SetTitlePacket();
        pk.setTitleType(SetTitlePacket.TitleType.ACTIONBAR);
        pk.setTitleText(Strings.nullToEmpty(title));
        pk.setFadeInTime(fadein);
        pk.setStayTime(duration);
        pk.setFadeOutTime(fadeout);
        pk.setXuid("");
        pk.setPlatformOnlineId("");
        pk.setFilteredTitleMessage("");
        this.sendPacket(pk);
    }

    public void playMusic(String trackName) {
        this.playMusic(trackName, 1, 0, MusicRepeatMode.PLAY_ONCE);
    }

    /**
     * Immediately starts a music track for this player, replacing the currently playing one.
     *
     * @param trackName   the name of the music track, for example {@code record.pigstep}
     * @param volume      the volume of the track, between 0 and 1
     * @param fadeSeconds the duration of the fade between the previous track and this one, between 0 and 10
     * @param repeatMode  how the track should be repeated
     */
    public void playMusic(String trackName, float volume, float fadeSeconds, MusicRepeatMode repeatMode) {
        this.level.playMusic(trackName, volume, fadeSeconds, repeatMode, this);
    }

    public void queueMusic(String trackName) {
        this.queueMusic(trackName, 1, 0, MusicRepeatMode.PLAY_ONCE);
    }

    /**
     * Queues a music track for this player, it starts once the currently playing track has finished.
     *
     * @see #playMusic(String, float, float, MusicRepeatMode)
     */
    public void queueMusic(String trackName, float volume, float fadeSeconds, MusicRepeatMode repeatMode) {
        this.level.queueMusic(trackName, volume, fadeSeconds, repeatMode, this);
    }

    public void stopMusic() {
        this.stopMusic(0);
    }

    /**
     * Stops the currently playing music track and clears the queue of this player.
     *
     * @param fadeSeconds the duration of the fade out, between 0 and 10
     */
    public void stopMusic(float fadeSeconds) {
        this.level.stopMusic(fadeSeconds, this);
    }

    /**
     * Changes the volume of the music track currently playing for this player.
     *
     * @param volume the volume of the track, between 0 and 1
     */
    public void setMusicVolume(float volume) {
        this.level.setMusicVolume(volume, this);
    }

    /**
     * fadein=1,duration=0,fadeout=1
     *
     * @see #setRawTextActionBar(RawText, int, int, int)
     */

    public void setRawTextActionBar(RawText text) {
        this.setRawTextActionBar(text, 1, 0, 1);
    }

    /**
     * Set a JSON ActionBar text.
     *
     * @param text     JSON text
     * @param fadein   Fade-in duration
     * @param duration Duration
     * @param fadeout  Fade-out duration
     */

    public void setRawTextActionBar(RawText text, int fadein, int duration, int fadeout) {
        this.setTitleAnimationTimes(fadein, duration, fadeout);
        SetTitlePacket pk = new SetTitlePacket();
        pk.setTitleType(SetTitlePacket.TitleType.ACTIONBAR_TEXT_OBJECT);
        pk.setTitleText(text == null ? "" : text.toRawText());
        pk.setFadeInTime(fadein);
        pk.setStayTime(duration);
        pk.setFadeOutTime(fadeout);
        pk.setXuid("");
        pk.setPlatformOnlineId("");
        pk.setFilteredTitleMessage("");
        this.sendPacket(pk);
    }

    @Override
    public void close() {
        this.close("");
    }

    /**
     * {@code notify=true}
     *
     * @see #close(TextContainer, String, String)
     */
    public void close(String reason) {
        this.close(this.getLeaveMessage(), reason, reason);
    }

    public void close(String reason, String disconnectScreenMessage) {
        this.close(this.getLeaveMessage(), reason, disconnectScreenMessage);
    }

    public void close(String message, String reason, String disconnectScreenMessage) {
        this.close(new TextContainer(message), reason, disconnectScreenMessage);
    }

    /**
     * {@code reason="generic",notify=true}
     *
     * @see #close(TextContainer, String, String)
     */
    public void close(TextContainer message) {
        this.close(message, "generic");
    }

    /**
     * @see #close(TextContainer, String, String)
     */
    public void close(TextContainer message, String reason) {
        this.close(message, reason, reason);
    }

    public void close(TextContainer message, String reason, String disconnectScreenMessage) {
        if (this.closed || !this.connected.compareAndSet(true, false)) {
            return;
        }
        //output logout information
        log.info(this.getServer().getLanguage().tr("nukkit.player.logOut",
            TextFormat.AQUA + this.getName() + TextFormat.WHITE,
            this.getAddress(),
            String.valueOf(this.getPort()),
            this.getServer().getLanguage().tr(reason)));

        if (disconnectScreenMessage == null) disconnectScreenMessage = reason;

        resetInventory();
        for (var inv : this.windows.keySet()) {
            if (this.permanentWindows.contains(windows.get(inv))) {
                playerHandle.setClosingWindowId(Integer.MIN_VALUE);
                inv.close(this);
                updateTrackingPositions(true);
            }
        }

        //handle scoreboardManager#beforePlayerQuit
        var scoreboardManager = this.getServer().getScoreboardManager();
        if (scoreboardManager != null) {
            scoreboardManager.beforePlayerQuit(this);
        }

        releaseShoulderParrots();

        //dismount horse
        if (this.riding != null && this.riding.isRideable()) {
            riding.dismountEntity(this);
        }

        unloadAllUsedChunk();

        //call quit event
        PlayerQuitEvent ev = null;
        if (this.getName() != null && !this.getName().isEmpty()) {
            this.server.getPluginManager().callEvent(ev = new PlayerQuitEvent(this, message, true, reason));
            if (this.fishing != null) {
                this.stopFishing(false);
            }
        }

        // Close temporary windows through the normal window-removal path before saving/teardown.
        // Otherwise, shared inventories keep stale viewers after reconnects or UI transitions.
        this.removeAllWindows(false);

        if (ev != null && ev.getAutoSave() && this.nbt != null) {
            // Written on the player data thread, which orders it before a rejoin's read
            this.save(true);
        }
        super.close();

        this.windows.clear();
        this.hiddenPlayers.clear();
        this.hiddenFromPlayerList.clear();
        //remove player from player list
        this.server.removeOnlinePlayer(this);
        //remove player from player map
        this.server.removePlayer(this);

        this.server.getPluginManager().unsubscribeFromPermission(Server.BROADCAST_CHANNEL_USERS, this);
        this.server.getPluginManager().unsubscribeFromPermission(Server.BROADCAST_CHANNEL_ADMINISTRATIVE, this);
        // broadcast disconnection message
        if (ev != null && !Objects.equals(this.getName(), "") && this.spawned && !Objects.equals(ev.getQuitMessage().toString(), "")) {
            this.server.broadcastMessage(ev.getQuitMessage());
        }

        this.hasSpawned.clear();
        this.loggedIn = false;
        this.spawned = false;
        this.spawnPoint = null;
        this.riding = null;
        this.chunk = null;

        if (this.perm != null) {
            this.perm.clearPermissions();
            this.perm = null;
        }
        if (this.inventory != null) {
            this.inventory = null;
        }
        if (this.offhandInventory != null) {
            this.offhandInventory = null;
        }
        if (this.enderChestInventory != null) {
            this.enderChestInventory = null;
        }
        if (this.creativeOutputInventory != null) {
            this.creativeOutputInventory = null;
        }
        if (this.playerCursorInventory != null) {
            this.playerCursorInventory = null;
        }

        //close player network session
        log.debug("Closing player network session");
        log.debug(reason);
        // true when the server closes the client connection
        if (this.session.isConnected()) {
            this.session.disconnect(disconnectScreenMessage, false);
        }
    }

    public void unloadAllUsedChunk() {
        synchronized (playerChunkManager) {
            this.playerChunkManager.releasePendingChunkLoaders();

            //save player data
            //unload chunk for the player
            LongIterator iterator = this.playerChunkManager.getUsedChunks().iterator();
            try {
                while (iterator.hasNext()) {
                    long l = iterator.nextLong();
                    int chunkX = Level.getHashX(l);
                    int chunkZ = Level.getHashZ(l);
                    if (level.unregisterChunkLoader(this, chunkX, chunkZ, false)) {
                        for (Entity entity : level.getChunkEntities(chunkX, chunkZ).values()) {
                            if (entity != this) {
                                entity.despawnFrom(this);
                            }
                        }
                        iterator.remove();
                    }
                }
            } catch (Exception e) {
                getServer().getLogger().error("Failed to unload all used chunks.", e);
            } finally {
                this.playerChunkManager.getUsedChunks().clear();
            }
        }
    }

    public void save() {
        this.save(false);
    }

    protected void updatePersistentPlayerAttributes() {
        this.attributes.computeIfAbsent(Attribute.HEALTH, Attribute::getAttribute).setMaxValue(this.getHealthMax()).setValue(this.getHealthCurrent());
        this.attributes.computeIfAbsent(Attribute.ABSORPTION, Attribute::getAttribute).setValue(this.getAbsorption());

        if (this.foodData != null) {
            this.attributes.computeIfAbsent(Attribute.FOOD, Attribute::getAttribute).setValue(this.foodData.getFood());
            this.attributes.computeIfAbsent(Attribute.SATURATION, Attribute::getAttribute).setValue(this.foodData.getSaturation());
            this.attributes.computeIfAbsent(Attribute.EXHAUSTION, Attribute::getAttribute).setValue((float) this.foodData.getExhaustion());
        }

        float progress = calculateExperienceProgress(this.getExperience(), this.getExperienceLevel());
        this.attributes.computeIfAbsent(Attribute.EXPERIENCE_LEVEL, Attribute::getAttribute).setDefaultValue(this.getExperienceLevel()).setValue(this.getExperienceLevel());
        this.attributes.computeIfAbsent(Attribute.EXPERIENCE, Attribute::getAttribute).setDefaultValue(progress).setValue(progress);
    }

    @Override
    public void saveNBT() {
        this.updatePersistentPlayerAttributes();
        super.saveNBT();
        this.nbt.putLong("UniqueID", this.uniqueIdLong());
        this.nbt.putBoolean("HasSeenCredits", this.hasSeenCredits);
        this.wardenWarningData.save(this.nbt);

        if (spawnPoint == null) {
            this.nbt.putInt("SpawnX", Integer.MIN_VALUE)
                .putInt("SpawnY", Integer.MIN_VALUE)
                .putInt("SpawnZ", Integer.MIN_VALUE)
                .putInt("SpawnDimension", 3);

            if (this.pnxExtraNbt.contains("SpawnLevel")) {
                this.pnxExtraNbt.remove("SpawnLevel");
                this.pnxExtraDirty = true;
            }
        } else {
            Level spawnLevel = this.spawnPoint.getLevel();

            if (spawnLevel == null || spawnLevel.getProvider() == null) {
                spawnLevel = this.server.getDefaultLevel();
            }

            if (spawnLevel == null || spawnLevel.getProvider() == null) {
                throw new IllegalStateException("Default level or default level provider is null");
            }

            this.nbt.putInt("SpawnX", this.spawnPoint.getFloorX())
                .putInt("SpawnY", this.spawnPoint.getFloorY())
                .putInt("SpawnZ", this.spawnPoint.getFloorZ())
                .putInt("SpawnDimension", spawnLevel.getDimension());

            if (!spawnLevel.getName().equals(this.pnxExtraNbt.getString("SpawnLevel"))) {
                this.pnxExtraNbt.putString("SpawnLevel", spawnLevel.getName());
                this.pnxExtraDirty = true;
            }
        }

        if (this.playerCursorInventory != null) {
            Item item = this.playerCursorInventory.getItem(0);

            if (!item.isNull()) {
                CompoundTag cursorItem = ItemHelper.write(item);

                if (!this.pnxExtraNbt.containsCompound("CursorItem") || !cursorItem.equals(this.pnxExtraNbt.getCompound("CursorItem"))) {
                    this.pnxExtraNbt.putCompound("CursorItem", cursorItem);
                    this.pnxExtraDirty = true;
                }
            } else if (this.pnxExtraNbt.contains("CursorItem")) {
                this.pnxExtraNbt.remove("CursorItem");
                this.pnxExtraDirty = true;
            }
        }

        this.adventureSettings.saveNBT();
    }

    public void save(boolean async) {
        Preconditions.checkState(!this.closed, "Tried to save closed player");

        saveNBT();

        if (this.level != null && this.level.getProvider() != null) {
            this.nbt.putInt("DimensionId", this.level.getDimension());

            if (!this.level.getName().equals(this.pnxExtraNbt.getString("Level"))) {
                this.pnxExtraNbt.putString("Level", this.level.getName());
                this.pnxExtraDirty = true;
            }

            CompoundTag achievements = new CompoundTag();
            for (String achievement : this.achievements) {
                achievements.putByte(achievement, 1);
            }

            if (!achievements.equals(this.pnxExtraNbt.getCompound("Achievements"))) {
                this.pnxExtraNbt.putCompound("Achievements", achievements);
                this.pnxExtraDirty = true;
            }

            this.nbt.putInt("PlayerGameMode", toStorageGamemode(this.gamemode));

            long lastPlayed = System.currentTimeMillis() / 1000;
            if (this.pnxExtraNbt.getLong("lastPlayed") != lastPlayed) {
                this.pnxExtraNbt.putLong("lastPlayed", lastPlayed);
                this.pnxExtraDirty = true;
            }

            if (!this.getAddress().equals(this.pnxExtraNbt.getString("lastIP"))) {
                this.pnxExtraNbt.putString("lastIP", this.getAddress());
                this.pnxExtraDirty = true;
            }

            this.nbt.putInt("PlayerLevel", this.getExperienceLevel());
            this.nbt.putFloat("PlayerLevelProgress", calculateExperienceProgress(this.getExperience(), this.getExperienceLevel()));
            this.nbt.putInt("EnchantmentSeed", this.enchSeed);

            ListTag<StringTag> fogIdentifiers = new ListTag<>(Tag.TAG_String);
            ListTag<StringTag> userProvidedFogIds = new ListTag<>(Tag.TAG_String);
            this.fogStack.forEach(fog -> {
                fogIdentifiers.add(new StringTag(fog));
                userProvidedFogIds.add(new StringTag(fog));
            });

            if ((fogIdentifiers.size() > 0 || this.pnxExtraNbt.contains("fogIdentifiers")) && !fogIdentifiers.equals(this.pnxExtraNbt.getList("fogIdentifiers", StringTag.class))) {
                this.pnxExtraNbt.putList("fogIdentifiers", fogIdentifiers);
                this.pnxExtraDirty = true;
            }

            if ((userProvidedFogIds.size() > 0 || this.pnxExtraNbt.contains("userProvidedFogIds")) && !userProvidedFogIds.equals(this.pnxExtraNbt.getList("userProvidedFogIds", StringTag.class))) {
                this.pnxExtraNbt.putList("userProvidedFogIds", userProvidedFogIds);
                this.pnxExtraDirty = true;
            }

            this.nbt.putInt("TimeSinceRest", this.timeSinceRest);

            this.recipeBook.save(this.nbt);

            if (!this.getName().isBlank() && this.nbt != null) {
                this.server.saveOfflinePlayerData(this.uuid, this.getNbt(), this.takePnxExtraSaveSnapshot(), this.takeCustomSaveSnapshot(), async);
            }
        }
    }

    protected @Nullable CompoundTag takePnxExtraSaveSnapshot() {
        if (!this.pnxExtraDirty && !this.pnxExtraNbtExposed) return null;

        CompoundTag snapshot = this.pnxExtraNbt.copy();
        this.pnxExtraDirty = false;
        return snapshot;
    }

    protected @Nullable CompoundTag takeCustomSaveSnapshot() {
        if (!this.customDirty && !this.customNbtExposed) return null;

        CompoundTag snapshot = this.customNbt.copy();
        this.customDirty = false;
        return snapshot;
    }

    /**
     * Returns the live PNX-specific player NBT sidecar.
     */
    @Override
    public CompoundTag getNbtExtra() {
        this.pnxExtraNbtExposed = true;
        return this.pnxExtraNbt;
    }

    /**
     * Replaces the live PNX-specific player NBT sidecar.
     */
    @Override
    public void setNbtExtra(CompoundTag nbtExtra) {
        this.pnxExtraNbt = Preconditions.checkNotNull(nbtExtra, "nbtExtra");
        this.pnxExtraNbtExposed = true;
        this.pnxExtraDirty = true;
    }

    /**
     * Returns the live custom player NBT sidecar.
     */
    @Override
    public CompoundTag getNbtCustom() {
        this.customNbtExposed = true;
        return this.customNbt;
    }

    /**
     * Replaces the live custom player NBT sidecar.
     */
    @Override
    public void setNbtCustom(CompoundTag nbtCustom) {
        this.customNbt = Preconditions.checkNotNull(nbtCustom, "nbtCustom");
        this.customNbtExposed = true;
        this.customDirty = true;
    }

    /**
     * Returns whether this player has custom data for the specified namespace.
     *
     * @param namespace custom data namespace
     * @return whether data exists
     */
    public boolean hasCustomData(String namespace) {
        validateCustomDataNamespace(namespace);
        return this.customNbt.containsCompound(namespace);
    }

    /**
     * Returns a copy of the custom data stored for the specified namespace.
     *
     * @param namespace custom data namespace
     * @return stored data, or an empty compound when absent
     */
    public CompoundTag getCustomData(String namespace) {
        validateCustomDataNamespace(namespace);

        if (!this.customNbt.containsCompound(namespace)) {
            return new CompoundTag();
        }

        return this.customNbt.getCompound(namespace).copy();
    }

    /**
     * Stores custom player data under the specified namespace.
     *
     * @param namespace custom data namespace
     * @param data data to store, or {@code null} or empty to remove it
     */
    public void setCustomData(String namespace, CompoundTag data) {
        validateCustomDataNamespace(namespace);

        if (data == null || data.isEmpty()) {
            if (this.customNbt.contains(namespace)) {
                this.customNbt.remove(namespace);
                this.customDirty = true;
            }
            return;
        }

        if (data.equals(this.customNbt.get(namespace))) return;

        this.customNbt.putCompound(namespace, data.copy());
        this.customDirty = true;
    }

    /**
     * Removes custom player data for the specified namespace.
     *
     * @param namespace custom data namespace
     */
    public void removeCustomData(String namespace) {
        validateCustomDataNamespace(namespace);

        if (this.customNbt.contains(namespace)) {
            this.customNbt.remove(namespace);
            this.customDirty = true;
        }
    }

    private static void validateCustomDataNamespace(String namespace) {
        if (namespace == null || namespace.isBlank()) {
            throw new IllegalArgumentException("Custom player data namespace cannot be null or blank");
        }
    }

    @Override
    public String getOriginalName() {
        return "Player";
    }

    @NotNull
    @Override
    public String getName() {
        return this.info.getIdentityClaims().extraData.displayName;
    }


    public LangCode getLanguageCode() {
        LangCode code = LangCode.from(this.getClientChainData().getLanguageCode());
        return code == null ? LangCode.en_US : code;
    }

    @Override
    public void kill() {
        if (!this.spawned)
            return;

        if (adventureSettings.get(AbilitiesIndex.INVULNERABLE))
            return;

        boolean showMessages = this.level.getGameRules().getBoolean(GameRule.SHOW_DEATH_MESSAGES);
        String message = "";
        List<String> params = new ArrayList<>();
        EntityDamageEvent cause = this.getLastDamageCause();
        Item weapon = Item.AIR;

        if (showMessages) {
            params.add(this.getDisplayName());

            switch (cause == null ? DamageCause.CUSTOM : cause.getCause()) {
                case ENTITY_ATTACK:
                    if (cause instanceof EntityDamageByEntityEvent) {
                        Entity e = ((EntityDamageByEntityEvent) cause).getDamager();
                        killer = e;
                        if (e instanceof EntityHandItem entityHandItem) {
                            weapon = entityHandItem.getItemInHand();
                        }
                        if (e instanceof Player pl) {
                            message = "death.attack.player";
                            params.add(pl.getDisplayName());
                            break;
                        } else if (e instanceof EntityLiving) {
                            message = "death.attack.mob";
                            params.add(!Objects.equals(e.getNameTag(), "") ? e.getNameTag() : e.getName());
                            break;
                        } else {
                            params.add("Unknown");
                        }
                    }
                    break;
                case PROJECTILE:
                    if (cause instanceof EntityDamageByEntityEvent) {
                        Entity e = ((EntityDamageByEntityEvent) cause).getDamager();
                        killer = e;
                        if (e instanceof Player pl) {
                            message = "death.attack.arrow";
                            params.add(pl.getDisplayName());
                        } else if (e instanceof EntityLiving) {
                            message = "death.attack.arrow";
                            params.add(!Objects.equals(e.getNameTag(), "") ? e.getNameTag() : e.getName());
                            break;
                        } else {
                            params.add("Unknown");
                        }
                    }
                    break;
                case VOID:
                    message = "death.attack.outOfWorld";
                    break;
                case FALL:
                    if (cause.getFinalDamage() > 2) {
                        message = "death.fell.accident.generic";
                        break;
                    }
                    message = "death.attack.fall";
                    break;

                case SUFFOCATION:
                    message = "death.attack.inWall";
                    break;

                case LAVA:
                    message = "death.attack.lava";

                    if (this.killer instanceof EntityProjectile projectile) {
                        Entity shooter = projectile.shootingEntity;
                        if (shooter != null) {
                            this.killer = shooter;
                        }
                        if (this.killer instanceof EntityHuman) {
                            message += ".player";
                            params.add(this.killer.hasCustomName() ? this.killer.getNameTag() : this.killer.getName());
                        }
                    }
                    break;

                case FIRE:
                    message = "death.attack.onFire";
                    break;

                case FIRE_TICK:
                    message = "death.attack.inFire";
                    break;

                case DROWNING:
                    message = "death.attack.drown";
                    break;

                case CONTACT:
                    if (cause instanceof EntityDamageByBlockEvent) {
                        String id = ((EntityDamageByBlockEvent) cause).getDamager().getId();
                        if (id.equals(BlockID.CACTUS)) {
                            message = "death.attack.cactus";
                        } else if (id.equals(BlockID.ANVIL)) {
                            message = "death.attack.anvil";
                        }
                    }
                    break;

                case BLOCK_EXPLOSION:
                case ENTITY_EXPLOSION:
                    if (cause instanceof EntityDamageByEntityEvent) {
                        Entity e = ((EntityDamageByEntityEvent) cause).getDamager();
                        killer = e;
                        if (e instanceof Player) {
                            message = "death.attack.explosion.player";
                            params.add(((Player) e).getDisplayName());
                        } else if (e instanceof EntityLiving) {
                            message = "death.attack.explosion.player";
                            params.add(!Objects.equals(e.getNameTag(), "") ? e.getNameTag() : e.getName());
                            break;
                        } else {
                            message = "death.attack.explosion";
                        }
                    } else {
                        message = "death.attack.explosion";
                    }
                    break;
                case MAGIC:
                    message = "death.attack.magic";
                    break;
                case SONIC_BOOM:
                    message = "death.attack.sonicBoom";
                    break;
                case LIGHTNING:
                    message = "death.attack.lightningBolt";
                    break;
                case HUNGER:
                    message = "death.attack.starve";
                    break;
                case HOT_FLOOR:
                    message = "death.attack.magma";
                    break;
                default:
                    message = "death.attack.generic";
                    break;
            }
        }

        PlayerDeathEvent ev = new PlayerDeathEvent(this, this.getDrops(weapon), new TranslationContainer(message, params.toArray(EmptyArrays.EMPTY_STRINGS)), this.expLevel);
        ev.setKeepExperience(this.level.gameRules.getBoolean(GameRule.KEEP_INVENTORY));
        ev.setKeepInventory(ev.getKeepExperience());

        this.server.getPluginManager().callEvent(ev);

        if (!ev.isCancelled()) {
            if (this.fishing != null) {
                this.stopFishing(false);
            }

            this.health = 0;
            this.extinguish();
            this.scheduleUpdate();
            if (!ev.getKeepInventory() && this.level.getGameRules().getBoolean(GameRule.DO_ENTITY_DROPS)) {
                for (Item item : ev.getDrops()) {
                    if (!item.hasEnchantment(Enchantment.ID_VANISHING_CURSE) && item.applyEnchantments()) {
                        this.level.dropItem(this, item, null, true, 40);
                    }
                }

                if (this.inventory != null) {
                    new HashMap<>(this.inventory.getContents()).forEach((slot, item) -> {
                        if (!item.keepOnDeath()) {
                            this.inventory.clear(slot);
                        }
                    });
                }
                if (this.offhandInventory != null) {
                    new HashMap<>(this.offhandInventory.getContents()).forEach((slot, item) -> {
                        if (!item.keepOnDeath()) {
                            this.offhandInventory.clear(slot);
                        }
                    });
                }
                for (Inventory uiInventory : this.getInventoriesDroppedOnDeath()) {
                    new HashMap<>(uiInventory.getContents()).forEach((slot, item) -> {
                        if (!item.keepOnDeath()) {
                            uiInventory.clear(slot);
                        }
                    });
                }
            }

            if (!ev.getKeepExperience() && this.level.getGameRules().getBoolean(GameRule.DO_ENTITY_DROPS)) {
                if (this.isSurvival() || this.isAdventure()) {
                    int exp = ev.getExperience() * 7;
                    if (exp > 100) exp = 100;
                    this.getLevel().dropExpOrb(this, exp);
                }
                this.setExperience(0, 0, false, false);
            }

            this.timeSinceRest = 0;

            TranslationContainer deathMessage = ev.getTranslationDeathMessage();
            DeathInfoPacket deathInfo = new DeathInfoPacket();
            deathInfo.setDeathCauseAttackName(deathMessage.getText());
            deathInfo.getDeathCauseMessageList().addAll(Arrays.asList(deathMessage.getParameters()));
            this.sendPacket(deathInfo);

            this.server.sendSleepingPlayersStatus(Set.of(this));

            @SuppressWarnings("null")
            Attribute healthAttribute = this.attributes.computeIfAbsent(Attribute.HEALTH, Attribute::getAttribute);
            healthAttribute
                    .setMaxValue(this.getHealthMax())
                    .setValue(0);
            this.syncAttribute(healthAttribute);

            if (showMessages && !ev.getDeathMessage().toString().isEmpty()) {
                this.server.broadcast(ev.getDeathMessage(), Server.BROADCAST_CHANNEL_USERS);
            }
            this.setDataProperty(ActorDataTypes.PLAYER_LAST_DEATH_POS, new BlockVector3(this.getFloorX(), this.getFloorY(), this.getFloorZ()).toNetwork());

            this.pendingRespawnPosition = null;

            RespawnPacket pk = new RespawnPacket();
            pk.setPosition(Vector3f.from(
                    this.x,
                    this.y + this.getEyeHeight(),
                    this.z
            ));
            pk.setState(PlayerRespawnState.SEARCHING_FOR_SPAWN);
            pk.setPlayerRuntimeId(0);
            this.sendPacket(pk);
        }
    }

    @Override
    public void setHealthCurrent(float health) {
        if (health < 1) {
            health = 0;
        }
        super.setHealthCurrent(health);

        float currentHealth = this.getHealthCurrent();

        @SuppressWarnings("null")
        Attribute attribute = this.attributes.computeIfAbsent(Attribute.HEALTH, Attribute::getAttribute);
        attribute.setMaxValue(this.getHealthMax()).setValue(
                currentHealth > 0 ? Math.min(currentHealth, this.getHealthMax()) : 0
        );

        if (this.spawned
                && !this.suppressHealthAttributePacket
                && (currentHealth > 0 || this.isAlive())) {
            this.syncAttribute(attribute);
        }
    }

    @Override
    public void setHealthMax(int maxHealth) {
        super.setHealthMax(maxHealth);

        @SuppressWarnings("null")
        Attribute attribute = this.attributes.computeIfAbsent(Attribute.HEALTH, Attribute::getAttribute);
        attribute.setMaxValue(this.getHealthMax()).setValue(health > 0 ? Math.min(health, getHealthMax()) : 0);

        if (this.spawned && this.isAlive()) {
            UpdateAttributesPacket pk = new UpdateAttributesPacket();
            pk.setRuntimeID(this.runtimeId());
            pk.getAttributeList().add(attribute.toNetwork());
            this.sendPacket(pk);
        }
    }

    /**
     * Get the experience value of the player (it does not show the total experience value of the player from, but only the experience value where the current level is, i.e. the experience bar).
     *
     * @return int
     */
    public int getExperience() {
        return this.exp;
    }

    /**
     * Get the level of the player.
     *
     * @return int
     */
    public int getExperienceLevel() {
        return this.expLevel;
    }


    /**
     * playLevelUpSound=false
     *
     * @see #addExperience(int, boolean)
     */
    public void addExperience(int add) {
        addExperience(add, false);
    }

    /**
     * Increase the experience value of the player
     *
     * @param add              experience to be added
     * @param playLevelUpSound should level up sound played
     */

    public void addExperience(int add, boolean playLevelUpSound) {
        if (add == 0) return;
        int now = this.getExperience();
        int added = now + add;
        int level = this.getExperienceLevel();
        int most = calculateRequireExperience(level);
        while (added >= most) {  //Level Up!
            added = added - most;
            level++;
            most = calculateRequireExperience(level);
        }
        this.setExperience(added, level, playLevelUpSound);
    }

    /**
     * Calculates the amount of experience a player needs to reach a certain level
     *
     * @param level experience level
     * @return int
     */
    public static int calculateRequireExperience(int level) {
        if (level >= 30) {
            return 112 + (level - 30) * 9;
        } else if (level >= 15) {
            return 37 + (level - 15) * 5;
        } else {
            return 7 + level * 2;
        }
    }

    /**
     * Calculates the normalized experience progress for a level.
     *
     * @param exp experience toward the next level
     * @param level current experience level
     * @return progress clamped to {@code [0, 1]}
     */
    public static float calculateExperienceProgress(int exp, int level) {
        int required = calculateRequireExperience(Math.max(0, level));
        return Math.max(0f, Math.min(1f, ((float) exp) / required));
    }

    /**
     * Converts normalized level progress back to experience points.
     *
     * @param progress normalized progress
     * @param level current experience level
     * @return experience toward the next level
     */
    public static int calculateExperienceFromProgress(float progress, int level) {
        int required = calculateRequireExperience(Math.max(0, level));
        float clamped = Math.max(0f, Math.min(1f, progress));
        return Math.max(0, Math.min(required, Math.round(clamped * required)));
    }


    /**
     * {@code level = this.getExperienceLevel(),playLevelUpSound=false}
     *
     * @see #setExperience(int, int, boolean)
     */
    public void setExperience(int exp) {
        setExperience(exp, this.getExperienceLevel());
    }


    /**
     * playLevelUpSound=false
     *
     * @see #setExperience(int, int, boolean)
     */
    public void setExperience(int exp, int level) {
        setExperience(exp, level, false);
    }

    /**
     * set the experience value and level of the player
     *
     * @param playLevelUpSound Whether to play level-up sound
     * @param exp              Experience points
     * @param level            Level
     */
    // TODO: something on performance, lots of exp orbs then lots of packets, could crash client
    public void setExperience(int exp, int level, boolean playLevelUpSound) {
        this.setExperience(exp, level, playLevelUpSound, true);
    }

    protected void setExperience(int exp, int level, boolean playLevelUpSound, boolean send) {
        var expEvent = new PlayerExperienceChangeEvent(this, this.getExperience(), this.getExperienceLevel(), exp, level);
        this.server.getPluginManager().callEvent(expEvent);
        if (expEvent.isCancelled()) {
            return;
        }
        exp = expEvent.getNewExperience();
        level = expEvent.getNewExperienceLevel();

        int levelBefore = this.expLevel;
        this.exp = exp;
        this.expLevel = level;

        if (send) {
            this.sendExperienceLevel(level);
            this.sendExperience(exp);
        }

        if (playLevelUpSound && levelBefore < level && levelBefore / 5 != level / 5 && this.lastPlayedLevelUpSoundTime < this.age - 100) {
            this.lastPlayedLevelUpSoundTime = this.age;
            this.level.addLevelSoundEvent(
                this,
                SoundEvent.LEVEL_UP,
                Math.min(7, level / 5) << 28,
                "",
                false, false
            );
        }
    }

    /**
     * @see #sendExperience(int)
     */
    public void sendExperience() {
        sendExperience(this.getExperience());
    }

    /**
     * The implementation of setExperience is used to set the experience value corresponding to the current level, i.e. the experience bar
     *
     * @param exp experience value
     */
    public void sendExperience(int exp) {
        if (this.spawned) {
            float percent = calculateExperienceProgress(exp, this.getExperienceLevel());
            Attribute attribute = this.attributes.computeIfAbsent(Attribute.EXPERIENCE, Attribute::getAttribute);
            attribute.setValue(percent);
            this.syncAttribute(attribute);
        }
    }


    /**
     * @see #sendExperienceLevel(int)
     */
    public void sendExperienceLevel() {
        sendExperienceLevel(this.getExperienceLevel());
    }

    /**
     * The implementation of setExperience is used to set the level
     *
     * @param level the level
     */
    public void sendExperienceLevel(int level) {
        if (this.spawned) {
            Attribute attribute = this.attributes.computeIfAbsent(Attribute.EXPERIENCE_LEVEL, Attribute::getAttribute);
            attribute.setValue(level);
            this.syncAttribute(attribute);
        }
    }

    /**
     * Send UpdateAttributesPacket packets to this player with the specified {@link Attribute}.
     *
     * @param attribute the attribute
     */
    public void syncAttribute(Attribute attribute) {
        final UpdateAttributesPacket pk = new UpdateAttributesPacket();
        pk.setRuntimeID(this.runtimeId());
        pk.getAttributeList().add(attribute.toNetwork());
        this.sendPacket(pk);
    }

    public void syncAttributes() {
        this.syncAttributes(false);
    }

    /**
     * Sends all syncable player attributes immediately.
     * <p>
     * This is intended for ordered protocol initialization where the
     * attributes packet must be written before subsequent immediately-sent
     * login packets.
     * </p>
     */
    public void syncAttributesImmediately() {
        this.syncAttributes(true);
    }

    protected void syncAttributes(boolean immediately) {
        final UpdateAttributesPacket pk = new UpdateAttributesPacket();
        pk.setRuntimeID(this.runtimeId());

        for (final Attribute attribute : this.attributes.values()) {
            if (attribute != null && attribute.isSyncable()) {
                pk.getAttributeList().add(attribute.toNetwork());
            }
        }

        if (immediately) {
            this.sendPacketImmediately(pk);
        } else {
            this.sendPacket(pk);
        }
    }

    @Override
    public void setAbsorption(float absorption) {
        super.setAbsorption(absorption);

        Attribute attribute = this.attributes.get(Attribute.ABSORPTION);
        if (attribute != null) {
            this.syncAttribute(attribute);
        }
    }

    @Override
    public float getWalkSpeed() {
        return this.walkSpeed;
    }

    /**
     * Sets the walk speed multiplier
     *
     * @param speed
     */
    @Override
    public void setWalkSpeed(float speed) {
        this.walkSpeed = speed;
        recalcMovementSpeedFromEffects();
    }

    /**
     * send=true
     *
     * @see #setMovementSpeed(float, boolean)
     */
    @ApiStatus.Internal
    @Override
    public void setMovementSpeed(float speed) {
        setMovementSpeed(speed, true);
    }

    /**
     * Set the movement speed of this player.
     * Will be overwritten internally.
     *
     * @param speed Speed value, note that the default movement speed is {@link #DEFAULT_SPEED}
     * @param send  Whether to send {@link UpdateAttributesPacket} to the client
     * @see #setWalkSpeed(float)
     */
    @ApiStatus.Internal
    public void setMovementSpeed(float speed, boolean send) {
        float speedCorrected = speed * getWalkSpeed();
        if (speedCorrected != getMovementSpeed()) {
            super.setMovementSpeed(speedCorrected);
            if (this.spawned && send) {
                this.sendMovementSpeed();
            }
        }
    }

    /**
     * Send {@link Attribute#MOVEMENT_SPEED} Attribute to Client.
     */
    @ApiStatus.Internal
    public void sendMovementSpeed() {
        Attribute attribute = this.attributes.computeIfAbsent(Attribute.MOVEMENT_SPEED, Attribute::getAttribute);
        attribute.setValue(getMovementSpeed());
        this.syncAttribute(attribute);
    }

    /**
     * Get the entity that killed this player
     *
     * @return Entity | null
     */
    public Entity getKiller() {
        return killer;
    }

    @Override
    public boolean attack(EntityDamageEvent source) {
        if (!this.isAlive()) {
            return false;
        }

        if (this.isSpectator() || this.isCreative() || this.getAdventureSettings().get(AbilitiesIndex.INVULNERABLE)) {
            return false;
        } else if (this.getAdventureSettings().get(Type.ALLOW_FLIGHT) && source.getCause() == DamageCause.FALL) {
            return false;
        } else if (source.getCause() == DamageCause.FALL) {
            if (this.getLevel().getBlock(this.getPosition().floor().add(0.5, -1, 0.5)).getId().equals(Block.SLIME)) {
                if (!this.isSneaking()) {
                    this.resetFallDistance();
                    return false;
                }
            }
        }

        if (super.attack(source)) {
            releaseShoulderParrots();
            if (this.getLastDamageCause() == source && this.spawned) {
                if (source instanceof EntityDamageByEntityEvent entityDamageByEntityEvent) {
                    // Save the entity that last attacked the player in lastBeAttackEntity
                    this.lastBeAttackEntity = entityDamageByEntityEvent.getDamager();
                }
                final ActorEventPacket pk = new ActorEventPacket();
                pk.setTargetRuntimeID(this.runtimeId());
                pk.setType(ActorEvent.HURT);
                this.sendPacket(pk);
            }
            return true;
        } else {
            return false;
        }
    }

    /**
     * Drops an item on the ground in front of the player. Returns if the item drop was successful.
     *
     * @param item to drop
     * @return bool if the item was dropped or if the item was null
     */
    public boolean dropItem(Item item) {
        if (!this.spawned || !this.isAlive()) {
            return false;
        }

        if (item.isNull()) {
            log.debug("{} attempted to drop a null item ({})", this.getName(), item);
            return true;
        }

        Vector3 motion = this.getDirectionVector().multiply(0.4);
        this.level.dropItemAndGetEntities(this.add(0, 1.3, 0), item, motion, 40, this.uniqueIdLong());
        this.setDataFlag(ActorFlags.USING_ITEM, false);
        return true;
    }

    /**
     * Drops an item on the ground in front of the player. Returns the dropped item.
     *
     * @param item to drop
     * @return EntityItem if the item was dropped or null if the item was null
     */

    public @Nullable EntityItem[] dropItemAndGetEntities(@NotNull Item item) {
        if (!this.spawned || !this.isAlive()) {
            return null;
        }

        if (item.isNull()) {
            log.debug("{} attempted to drop a null item ({})", this.getName(), item);
            return null;
        }

        Vector3 motion = this.getDirectionVector().multiply(0.4);

        this.setDataFlag(ActorFlags.USING_ITEM, false);

        return this.level.dropItemAndGetEntities(
                this.add(0, 1.3, 0),
                item,
                motion,
                40,
                this.uniqueIdLong()
        );
    }

    /**
     * @see #sendPosition(Vector3, double, double, PositionMode, Player[])
     */
    public void sendPosition(Vector3 pos) {
        this.sendPosition(pos, this.yaw);
    }

    /**
     * @see #sendPosition(Vector3, double, double, PositionMode, Player[])
     */
    public void sendPosition(Vector3 pos, double yaw) {
        this.sendPosition(pos, yaw, this.pitch);
    }

    /**
     * @see #sendPosition(Vector3, double, double, PositionMode, Player[])
     */
    public void sendPosition(Vector3 pos, double yaw, double pitch) {
        this.sendPosition(pos, yaw, pitch, PositionMode.NORMAL);
    }

    /**
     * @see #sendPosition(Vector3, double, double, PositionMode, Player[])
     */
    public void sendPosition(Vector3 pos, double yaw, double pitch, PositionMode mode) {
        this.sendPosition(pos, yaw, pitch, mode, null);
    }

    /**
     * The implementation of {@link Player#addMovement} only sends {@link MovePlayerPacket} packets to the client.
     *
     * @param pos     the pos of MovePlayerPacket
     * @param yaw     the yaw of MovePlayerPacket
     * @param pitch   the pitch of MovePlayerPacket
     * @param mode    the mode of MovePlayerPacket
     * @param targets the players of receive the packet
     */
    public void sendPosition(Vector3 pos, double yaw, double pitch, PositionMode mode, Player[] targets) {
        final MovePlayerPacket pk = new MovePlayerPacket();
        pk.setPlayerRuntimeID(this.runtimeId());
        pk.setPosition(Vector3f.from(pos.x, pos.y + this.getEyeHeight(), pos.z));
        pk.setRotation(Vector3f.from(pitch, yaw, yaw));
        pk.setPositionMode(mode);
        pk.setOnGround(this.onGround);
        if (this.riding != null) {
            pk.setRidingRuntimeID(this.riding.runtimeId());
            pk.setPositionMode(PositionMode.ONLY_HEAD_ROT);
        }

        if (pk.getPositionMode() == PositionMode.TELEPORT) {
            final MovePlayerTeleportData teleportData = new MovePlayerTeleportData();
            teleportData.setTeleportationCause(TeleportationCause.UNKNOWN);
            pk.setTeleportData(teleportData);
        }

        if (targets != null) {
            Server.broadcastPacket(targets, pk);
        } else {
            this.sendPacket(pk);
        }
    }

    @Override
    public boolean teleport(Location location, TeleportCause cause) {
        return this.teleport(location, cause, true);
    }

    @ApiStatus.Internal
    public boolean teleport(Position position, TeleportCause cause, boolean sendToSelf) {
        return this.teleport(
                Location.fromObject(position, position.level, this.yaw, this.pitch, this.headYaw),
                cause,
                sendToSelf
        );
    }

    @ApiStatus.Internal
    public boolean teleport(Location location, TeleportCause cause, boolean sendToSelf) {
        if (!this.isOnline()) {
            return false;
        }

        Location from = this.getLocation();
        Location to = location;

        if (cause != null) {
            PlayerTeleportEvent event = new PlayerTeleportEvent(this, from, to, cause);
            this.server.getPluginManager().callEvent(event);
            if (event.isCancelled()) return false;
            to = event.getTo();
        }

        this.lastTeleportMessage = Pair.of(
                to.clone(),
                System.currentTimeMillis()
        );

        //remove inventory, ride,sign editor
        for (Inventory window : new ArrayList<>(this.windows.keySet())) {
            if (window == this.inventory) {
                continue;
            }
            this.removeWindow(window);
        }
        final Entity currentRide = getRiding();
        if (currentRide != null && !currentRide.dismountEntity(this, true, false)) {
            return false;
        }
        setOpenSignFront(null);

        this.setMotion(this.temporalVector.setComponents(0, 0, 0));
        if (this.isCrawling()) {
            this.setCrawling(false);
            this.sendData(this);
        }

        boolean switchLevel = false;
        if (!to.getLevel().equals(from.getLevel())) {
            switchLevel = true;
            unloadAllUsedChunk();
            //unload entities for old level
            Arrays.stream(from.getLevel().getEntities()).forEach(e -> e.despawnFrom(this));
        }

        clientMovements.clear();
        //switch level, update pos and rotation, update aabb
        if (setPositionAndRotation(to, to.getYaw(), to.getPitch(), to.getHeadYaw())) {
            //if switch level or the distance teleported is too far
            if (switchLevel) {
                this.playerChunkManager.handleTeleport();
                //set nextChunkOrderRun is zero means that the next tick immediately executes the playerChunkManager#tick
                this.nextChunkOrderRun = 0;
            } else if ((Math.abs(from.getChunkX() - to.getChunkX()) >= this.getViewDistance())
                || (Math.abs(from.getChunkZ() - to.getChunkZ()) >= this.getViewDistance())) {
                this.playerChunkManager.handleTeleport();
                this.nextChunkOrderRun = 0;
            }
            //send to a client
            if (sendToSelf) {
                this.sendPosition(to, to.yaw, to.pitch, PositionMode.TELEPORT);
            }
            this.newPosition = to;
        } else {
            if (sendToSelf) {
                this.sendPosition(this, to.yaw, to.pitch, PositionMode.TELEPORT);
            }
            this.newPosition = this;
        }
        //state update
        this.positionChanged = true;

        if (switchLevel) {
            refreshChunkRender();
        }
        this.resetFallDistance();
        //DummyBossBar
        this.getDummyBossBars().values().forEach(DummyBossBar::reshow);
        //Weather
        this.getLevel().sendWeather(this);
        updateTrackingPositions(true);
        //Update gamemode
        if (isSpectator()) {
            this.setGamemode(this.gamemode, false, null, true);
        }
        this.scheduleUpdate();
        return true;
    }

    public void refreshChunkRender() {
        final int origin = getViewDistance();
        this.setViewDistance(1);
        this.setViewDistance(32);
        this.setViewDistance(origin);
    }

    /**
     * Sends a form to a player and assigns the next ID to it
     * To open a form safely, please use {@link Form#send(Player)}
     *
     * @param form The form to open
     * @return The id assigned to the form
     */
    public int sendForm(Form<?> form) {
        return this.sendForm(form, this.formWindowCount++);
    }

    /**
     * Sends a form to a player and assigns a given ID to it
     * To open a form safely, please use {@link Form#send(Player)}
     *
     * @param form The form to open
     * @param id   The ID to assign the form to
     * @return The id assigned to the form
     */
    public int sendForm(Form<?> form, int id) {
        if (this.formWindows.size() > 10) {
            this.kick("Server sent to many forms. Please ");
            return id;
        }

        if (!form.isViewer(this)) {
            form.viewers().add(this);
        }

        final ModalFormRequestPacket packet = new ModalFormRequestPacket();
        packet.setFormID(id);
        packet.setFormData(form.toJson());

        this.formWindows.put(packet.getFormID(), form);
        this.sendPacket(packet);
        return id;
    }

    @UnintendedClientBehaviour
    public void updateForm(Form<?> form) {
        if (!form.isViewer(this)) {
            return;
        }

        this.formWindows.entrySet()
            .stream()
            .filter(f -> f.getValue().equals(form))
            .map(Entry::getKey)
            .findFirst()
            .ifPresent(id -> {
                final ServerSettingsResponsePacket packet = new ServerSettingsResponsePacket(); // Exploiting some (probably unintended) protocol features here
                packet.setFormID(id);
                packet.setFormData(form.toJson());
                this.sendPacket(packet);
            });
    }

    public void checkClosedForms() {
        this.formWindows.entrySet().removeIf(entry -> !entry.getValue().isViewer(this));
    }

    public Map<Integer, Form<?>> getFormWindows() {
        return formWindows;
    }

    /**
     * book=true
     *
     * @see #showDialogWindow(FormWindowDialog, boolean)
     */
    public void showDialogWindow(FormWindowDialog dialog) {
        showDialogWindow(dialog, true);
    }

    /**
     * Show a dialog window to the player.
     *
     * @param dialog the dialog
     * @param book   If true, the {@link FormWindowDialog#getSceneName()} will be updated immediately.
     */
    public void showDialogWindow(FormWindowDialog dialog, boolean book) {
        String actionJson = dialog.getButtonJSONData();

        if (book && dialogWindows.getIfPresent(dialog.getSceneName()) != null) dialog.updateSceneName();
        dialog.getBindEntity().setDataProperty(ActorDataTypes.HAS_NPC, true);
        dialog.getBindEntity().setDataProperty(ActorDataTypes.NPC_DATA, dialog.getSkinData());
        dialog.getBindEntity().setDataProperty(ActorDataTypes.ACTIONS, actionJson);
        dialog.getBindEntity().setDataProperty(ActorDataTypes.INTERACT_TEXT, dialog.getContent());

        final NpcDialoguePacket packet = new NpcDialoguePacket();
        packet.setNpcId(dialog.getEntityId());
        packet.setActionType(NpcDialoguePacket.Action.OPEN);
        packet.setDialogue(dialog.getContent());
        packet.setSceneName(book ? dialog.getSceneName() : "");
        packet.setNpcName(dialog.getTitle());
        packet.setActionJson(dialog.getButtonJSONData());
        if (book) {
            this.dialogWindows.put(dialog.getSceneName(), dialog);
        }
        this.sendPacket(packet);
    }

    /**
     * Shows a new setting page in game settings.
     * You can find out settings result by listening to PlayerFormRespondedEvent
     *
     * @param window to show on the settings page
     * @return form id to use in {@link PlayerFormRespondedEvent}
     */
    public int addServerSettings(Form<?> window) {
        int id = this.formWindowCount++;

        this.serverSettings.put(id, window);
        return id;
    }

    /**
     * Creates and sends a BossBar to the player
     *
     * @param text   The BossBar message
     * @param length The BossBar percentage
     * @return bossBarId, you should store it if you want to remove or update the BossBar later
     */
    public long createBossBar(String text, int length) {
        DummyBossBar bossBar = new DummyBossBar.Builder(this).text(text).length(length).build();
        return this.createBossBar(bossBar);
    }

    /**
     * Creates and sends a BossBar to the player
     *
     * @param dummyBossBar DummyBossBar Object (Instantiate it by the Class Builder)
     * @return bossBarId, you should store it if you want to remove or update the BossBar later
     * @see DummyBossBar.Builder
     */
    public long createBossBar(DummyBossBar dummyBossBar) {
        this.dummyBossBars.put(dummyBossBar.getBossBarId(), dummyBossBar);
        dummyBossBar.create();
        return dummyBossBar.getBossBarId();
    }

    /**
     * Get a DummyBossBar object
     *
     * @param bossBarId The BossBar ID
     * @return DummyBossBar object
     * @see DummyBossBar#setText(String) Set BossBar text
     * @see DummyBossBar#setLength(float) Set BossBar length
     * @see DummyBossBar#setColor(BossBarColor) Set BossBar color
     */
    public DummyBossBar getDummyBossBar(long bossBarId) {
        return this.dummyBossBars.getOrDefault(bossBarId, null);
    }

    /**
     * Get all DummyBossBar objects
     *
     * @return DummyBossBars Map
     */
    public Map<Long, DummyBossBar> getDummyBossBars() {
        return dummyBossBars;
    }

    /**
     * Updates a BossBar
     *
     * @param text      The new BossBar message
     * @param length    The new BossBar length
     * @param bossBarId The BossBar ID
     */
    public void updateBossBar(String text, int length, long bossBarId) {
        if (this.dummyBossBars.containsKey(bossBarId)) {
            DummyBossBar bossBar = this.dummyBossBars.get(bossBarId);
            bossBar.setText(text);
            bossBar.setLength(length);
        }
    }

    /**
     * Removes a BossBar
     *
     * @param bossBarId The BossBar ID
     */
    public void removeBossBar(long bossBarId) {
        if (this.dummyBossBars.containsKey(bossBarId)) {
            this.dummyBossBars.get(bossBarId).destroy();
            this.dummyBossBars.remove(bossBarId);
        }
    }

    /**
     * Allocates the next transient window ID for the player's own inventory UI.
     *
     * @return the allocated window ID
     */
    public int allocateInventoryWindowId() {
        this.inventoryWindowId = (byte) allocateTransientWindowId();
        return this.inventoryWindowId;
    }

    /**
     * Allocates a transient container window ID without registering an inventory.
     *
     * @return the allocated window ID
     */
    public int allocateTransientWindowId() {
        this.windowsCnt = (byte) Math.max(1, ++this.windowsCnt % 100);
        return this.windowsCnt;
    }

    /**
     * Get id from the specified {@link Inventory}
     *
     * @param inventory the inventory
     * @return the window id
     */
    public int getWindowId(@NotNull Inventory inventory) {
        Preconditions.checkNotNull(inventory);
        if (this.windows.containsKey(inventory)) {
            return this.windows.get(inventory);
        }

        return -1;
    }

    /**
     * Get {@link Inventory} from the specified id
     *
     * @param id the window id
     */
    public Inventory getWindowById(int id) {
        return this.windowIndex.get((byte) id);
    }

    /**
     * Add inventory to the current player.
     *
     * @param inventory The Inventory object representing the window must not be null.
     * @return The unique identifier assigned to the window if successfully added and opened; -1 if the window fails to be added.
     */
    public int addWindow(@NotNull Inventory inventory) {
        Preconditions.checkNotNull(inventory);
        if (getTopWindow().isPresent() || inventoryOpen) return -1;
        if (this.windows.containsKey(inventory)) {
            return this.windows.get(inventory);
        }
        byte cnt;
        this.windowsCnt = cnt = (byte) Math.max(1, ++this.windowsCnt % 100);
        if (this.windowIndex.containsKey(cnt)) {
            this.windowIndex.get(cnt).close(this);
        }
        this.windows.forcePut(inventory, cnt);

        if (this.spawned && inventory.open(this)) {
            updateTrackingPositions(true);
        } else {
            this.removeWindow(inventory);
            return -1;
        }
        for (int index : inventory.getContents().keySet()) {
            Item item = inventory.getUnclonedItem(index);
            if (item instanceof ItemBundle bundle) {
                if (bundle.hasNbt()) {
                    bundle.onChange(inventory);
                    inventory.sendSlot(index, this);
                }
            }
        }
        return cnt;
    }

    public int addWindow(@NotNull Inventory inventory, Byte forceId) {
        Preconditions.checkNotNull(inventory);
        if (this.windows.containsKey(inventory)) {
            return this.windows.get(inventory);
        }
        byte cnt;
        if (forceId == null) {
            this.windowsCnt = cnt = (byte) Math.max(1, ++this.windowsCnt % 101);//1-100
        } else {
            cnt = forceId;
        }
        if (this.windowIndex.containsKey(cnt)) {
            this.windowIndex.get(cnt).close(this);
        }
        this.windows.forcePut(inventory, cnt);

        if (this.spawned) {
            if (inventory.open(this)) {
                updateTrackingPositions(true);
                return cnt;
            } else {
                this.removeWindow(inventory);
                return -1;
            }
        }
        return cnt;
    }

    public Optional<Inventory> getTopWindow() {
        for (Entry<Inventory, Byte> entry : this.windows.entrySet()) {
            if (!this.permanentWindows.contains(entry.getValue())) {
                return Optional.of(entry.getKey());
            }
        }
        return Optional.empty();
    }

    /**
     * Remove the specified Inventory from the player
     *
     * @param inventory the inventory
     */
    public void removeWindow(Inventory inventory) {
        Preconditions.checkNotNull(inventory);
        if (!this.permanentWindows.contains(windows.get(inventory))) {
            playerHandle.setClosingWindowId(Integer.MIN_VALUE);
            inventory.close(this);
            this.windows.remove(inventory);
            updateTrackingPositions(true);
        }
    }

    /**
     * Completes a Structure Block editor window already closed by the client, without sending another close packet.
     *
     * @param inventory the Structure Block editor associated with the client update packet
     */
    public void finishEditorWindow(@NotNull Inventory inventory) {
        Preconditions.checkArgument(inventory instanceof StructBlockInventory);
        if (!this.windows.containsKey(inventory)) return;

        server.getPluginManager().callEvent(new InventoryCloseEvent(inventory, this));
        inventory.getViewers().remove(this);
        this.windows.remove(inventory);
        updateTrackingPositions(true);
    }

    /**
     * Commonly used for refreshing.
     */
    public void sendAllInventories() {
        for (Inventory inv : this.windows.keySet()) {
            inv.sendContents(this);
            if (inv instanceof HumanInventory humanInventory) {
                humanInventory.sendArmorContents(this);
            }
        }
    }

    /**
     * Check if player has any UI opened.
     */
    public boolean isAnyUiOpen() {
        if (openSignFront != null) return true;
        if (!formWindows.isEmpty()) return true;
        if (dialogWindows.estimatedSize() > 0) return true;
        if (getTopWindow().isPresent()) return true;
        if (inventoryOpen || enderChestOpen || fakeInventoryOpen) return true;
        return !clientInputLocks.isEmpty();
    }

    /**
     * Gets cursor inventory of the player.
     */
    public PlayerCursorInventory getCursorInventory() {
        return playerCursorInventory;
    }

    /**
     * Gets crafting grid of the player.
     */
    public CraftingGridInventory getCraftingGrid() {
        return this.craftingGridInventory;
    }

    public CreativeOutputInventory getCreativeOutputInventory() {
        return this.creativeOutputInventory;
    }

    /**
     * Moves items from open crafting grids and cursor back to player inventory
     * <p>
     * Usually already handled client-side through ItemStackRequestPackets.
     * Items will be dropped when the inventory is full (unless they have ItemLockMode)
     * This method mainly prevents preserving items (without any ItemLockMode) in cursor or crafting grid.
     */
    @ApiStatus.Internal
    public void resetInventory() {
        if (spawned) {
            this.returnItemsFromInventory(this.getCraftingGrid());
            this.returnItemsFromInventory(this.getCursorInventory());

            Optional<Inventory> topWindow = getTopWindow();
            if (topWindow.isPresent()) {
                Inventory value = topWindow.get();
                if (value instanceof CraftTypeInventory || (value instanceof FakeInventory fakeInventory && fakeInventory.getFakeInventoryType().isCraftType())) {
                    this.returnItemsFromInventory(value);
                }
                removeWindow(value);
            }
        }
    }

    private List<Inventory> getInventoriesDroppedOnDeath() {
        List<Inventory> inventories = new ArrayList<>(3);
        if (this.craftingGridInventory != null) {
            inventories.add(this.craftingGridInventory);
        }
        if (this.playerCursorInventory != null) {
            inventories.add(this.playerCursorInventory);
        }
        this.getTopWindow().filter(Player::isDroppedOnDeath).ifPresent(inventories::add);
        return inventories;
    }

    private static boolean isDroppedOnDeath(Inventory inventory) {
        if (inventory instanceof CrafterInventory) {
            return false;
        }
        return inventory instanceof CraftTypeInventory
                || (inventory instanceof FakeInventory fakeInventory
                && fakeInventory.getFakeInventoryType() == FakeInventoryType.WORKBENCH);
    }

    private void returnItemsFromInventory(Inventory inventory) {
        String invName = inventory.getClass().getSimpleName();
        for (Entry<Integer, Item> entry : inventory.getContents().entrySet()) {
            int slot = entry.getKey();
            Item item = entry.getValue();
            if (item.isNull()) {
                continue;
            }
            Item[] remains = getInventory().addItem(item);
            if (remains.length == 0) {
                inventory.clear(slot);
            } else {
                Item remain = remains[0];
                if (remain.getItemLockMode() == Item.ItemLockMode.NONE) {
                    this.dropItem(remain);
                    inventory.clear(slot);
                } else if (remain.getCount() != item.getCount()) {
                    log.debug("Partially moved {} to inventory of player {}. {} remains in {} slot {}", item, this.getName(), remain.getCount(), invName, slot);
                    inventory.setItem(slot, remain);
                } else {
                    log.debug("Locked item {} in {} slot {} not moved: inventory of player {} is full and dropping locked items is forbidden. The item will persist", item, invName, slot, this.getName());
                }
            }
        }
    }

    public void removeAllWindows() {
        removeAllWindows(false);
    }

    /**
     * Remove all windows.
     *
     * @param permanent If false, it will skip deleting the corresponding window in {@link #permanentWindows}
     */
    public void removeAllWindows(boolean permanent) {
        for (Entry<Byte, Inventory> entry : new ArrayList<>(this.windowIndex.entrySet())) {
            if (!permanent && this.permanentWindows.contains(entry.getKey())) {
                continue;
            }
            this.removeWindow(entry.getValue());
        }
    }

    /**
     * @since 1.21.90 (818)
     * The client closes inventories when the SLEEP player tag is set.
     * Even the player inventory, which cannot be closed with the ContainerClosePacket.
     * This won't close the inventories on the server side, but the client will send us the ContainerClose which in return will close the inventory on the server side
     * We're setting the flag manually because setPlayerFlag just flips the bit. But we need to set the bits in the correct order.
     */
    @UnintendedClientBehaviour
    public void forceClientCloseInventory() {
        final byte value = getDataProperty(ActorDataTypes.PLAYER_FLAGS, (byte) 0);
        setDataProperty(ActorDataTypes.PLAYER_FLAGS, ((Integer) (value | (byte) 0x2)).byteValue());
        getLevel().getScheduler().scheduleDelayedTask(() -> setDataProperty(ActorDataTypes.PLAYER_FLAGS, ((Integer) (getDataProperty(ActorDataTypes.PLAYER_FLAGS, (byte) 0) & (byte) 0x1)).byteValue()), 2);
    }

    /**
     * Get the id corresponding to the last closed window
     */
    public int getClosingWindowId() {
        return this.closingWindowId;
    }

    @Override
    public void setMetadata(String metadataKey, MetadataValue newMetadataValue) {
        this.server.getPlayerMetadata().setMetadata(this, metadataKey, newMetadataValue);
    }

    @Override
    public List<MetadataValue> getMetadata(String metadataKey) {
        return this.server.getPlayerMetadata().getMetadata(this, metadataKey);
    }

    @Override
    public boolean hasMetadata(String metadataKey) {
        return this.server.getPlayerMetadata().hasMetadata(this, metadataKey);
    }

    @Override
    public void removeMetadata(String metadataKey, Plugin owningPlugin) {
        this.server.getPlayerMetadata().removeMetadata(this, metadataKey, owningPlugin);
    }

    @Override
    public void onChunkChanged(IChunk chunk) {
        this.playerChunkManager.addSendChunk(chunk.getX(), chunk.getZ());
    }

    @Override
    public void onChunkLoaded(IChunk chunk) {
    }


    @Override
    public void onChunkUnloaded(IChunk chunk) {
        this.unloadChunk(chunk.getX(), chunk.getZ(), chunk.getProvider().getLevel());
    }

    @Override
    public int getLoaderId() {
        return this.loaderId;
    }

    @Override
    public boolean isLoaderActive() {
        return this.isConnected();
    }

    /**
     * Get the player's {@link PlayerFood}
     *
     * @return the food data
     */
    public PlayerFood getFoodData() {
        return this.foodData;
    }

    /**
     * Prepares a cross-dimension respawn before READY_TO_SPAWN is sent.
     * Changes dimension while the player is still in the respawn handshake,
     * preventing the client from briefly respawning in the dimension where it died.
     */
    @ApiStatus.Internal
    public boolean prepareRespawnDimension(Position searchingSpawn, Position resolvedSpawn) {
        if (searchingSpawn == null || searchingSpawn.level == null || resolvedSpawn == null || resolvedSpawn.level == null) {
            return false;
        }

        Level oldLevel = this.level;
        Level targetLevel = resolvedSpawn.level;

        if (oldLevel == null || oldLevel.getDimension() == targetLevel.getDimension()) {
            return false;
        }

        if (!super.switchLevel(targetLevel)) {
            return false;
        }

        this.clientMovements.clear();

        long[] oldChunks;
        synchronized (playerChunkManager) {
            oldChunks = playerChunkManager.getUsedChunks().toLongArray();
        }

        for (long index : oldChunks) {
            int chunkX = Level.getHashX(index);
            int chunkZ = Level.getHashZ(index);
            this.unloadChunk(chunkX, chunkZ, oldLevel);
        }

        synchronized (playerChunkManager) {
            playerChunkManager.getUsedChunks().clear();
        }

        Arrays.stream(oldLevel.getEntities()).forEach(entity -> entity.despawnFrom(this));

        Location serverRespawnPosition = Location.fromObject(
                resolvedSpawn,
                targetLevel,
                this.yaw,
                this.pitch,
                this.headYaw
        );

        if (!this.setPositionAndRotation(serverRespawnPosition, serverRespawnPosition.getYaw(), serverRespawnPosition.getPitch(), serverRespawnPosition.getHeadYaw())) {
            return false;
        }

        this.playerChunkManager.handleTeleport();
        this.nextChunkOrderRun = 0;
        this.newPosition = serverRespawnPosition;
        this.positionChanged = true;

        final ChangeDimensionPacket changeDimensionPacket = new ChangeDimensionPacket();
        changeDimensionPacket.setDimension(DimensionType.from(targetLevel.getDimension()));
        changeDimensionPacket.setPosition(Vector3f.from(searchingSpawn.x, 32767, searchingSpawn.z));
        changeDimensionPacket.setRespawn(false);

        this.sendPacket(changeDimensionPacket);

        if (oldLevel.getDimension() == Level.DIMENSION_OVERWORLD || targetLevel.getDimension() == Level.DIMENSION_OVERWORLD) {
            this.server.broadcastSleepingPlayersStatus();
        }

        final PlayerActionPacket dimensionAckPacket = new PlayerActionPacket();
        dimensionAckPacket.setPlayerRuntimeID(this.runtimeId());
        dimensionAckPacket.setAction(PlayerActionType.CHANGE_DIMENSION_ACK);
        dimensionAckPacket.setBlockPosition(Vector3i.ZERO);
        dimensionAckPacket.setResultPos(Vector3i.ZERO);

        this.sendPacket(dimensionAckPacket);

        this.needDimensionChangeACK = false;

        updateTrackingPositions(true);
        this.scheduleUpdate();

        return true;
    }

    @Override
    public boolean switchLevel(Level level) {
        Level oldLevel = this.level;
        if (oldLevel != level && !releaseShoulderParrots()) return false;
        if (super.switchLevel(level)) {
            this.clientMovements.clear();
            Position spawn = level.getSpawnLocation();
            final SetSpawnPositionPacket packet = new SetSpawnPositionPacket();
            packet.setSpawnPositionType(SpawnPositionType.WORLD_SPAWN);
            packet.setBlockPosition(spawn.toNetwork().toInt());
            packet.setDimensionType(DimensionType.from(spawn.getLevel().getDimension()));
            this.sendPacket(packet);

            // Remove old chunks; snapshot under lock so tick() can't mutate sentChunks
            // while we iterate, then clear any residual entries afterward.
            long[] oldChunks;
            synchronized (playerChunkManager) {
                oldChunks = playerChunkManager.getUsedChunks().toLongArray();
            }
            for (long index : oldChunks) {
                int chunkX = Level.getHashX(index);
                int chunkZ = Level.getHashZ(index);
                this.unloadChunk(chunkX, chunkZ, oldLevel);
            }
            synchronized (playerChunkManager) {
                playerChunkManager.getUsedChunks().clear();
            }

            level.sendTime(this);

            GameRulesChangedPacket gameRulesChanged = new GameRulesChangedPacket();
            gameRulesChanged.getRulesData().getRulesList().addAll(level.getGameRules().toNetwork());
            this.sendPacket(gameRulesChanged);

            if (oldLevel.getDimension() != level.getDimension()) {
                this.setDimension(level.getDimension());

                if (oldLevel.getDimension() == Level.DIMENSION_OVERWORLD
                        || level.getDimension() == Level.DIMENSION_OVERWORLD) {
                    this.server.broadcastSleepingPlayersStatus();
                }
            }
            updateTrackingPositions(true);
            this.scheduleUpdate();
            return true;
        }

        return false;
    }

    /**
     * Set whether to check for this player movement
     *
     * @param checkMovement the check movement
     */
    public void setCheckMovement(boolean checkMovement) {
        this.checkMovement = checkMovement;
    }

    /**
     * @since 1.2.1.0-PN
     */
    public boolean isCheckingMovement() {
        return this.checkMovement;
    }

    public synchronized Locale getLocale() {
        return this.locale.get();
    }

    public synchronized void setLocale(Locale locale) {
        this.locale.set(locale);
    }

    @UnmodifiableView
    public Set<Long> getUsedChunks() {
        return Collections.unmodifiableSet(playerChunkManager.getUsedChunks());
    }

    @Override
    public void setSprinting(boolean value) {
        if (value && this.getFreezingTicks() > 0) return;

        if (isSprinting() != value) {
            super.setSprinting(value);
            this.recalcMovementSpeedFromEffects();
        }
    }

    /**
     * Transfers the player to another server
     *
     * @param address the address
     */
    public void transfer(InetSocketAddress address) {
        String hostName = address.getAddress().getHostAddress();
        int port = address.getPort();
        final TransferPacket pk = new TransferPacket();
        pk.setServerAddress(hostName);
        pk.setServerPort(port);
        this.sendPacket(pk);
    }

    /**
     * Get the login chain data of this player
     *
     * @return the login chain data
     */
    public ClientChainData getClientChainData() {
        return this.clientChainData;
    }

    @ApiStatus.Internal
    public boolean pickupEntity(Entity entity, boolean near) {
        if (!this.spawned || !this.isAlive() || !this.isOnline() || this.isSpectator() || entity.isClosed()) {
            return false;
        }

        if (near) {
            Inventory inventory = this.inventory;
            if (entity instanceof EntityArrow entityArrow && entityArrow.hadCollision) {
                ItemArrow item = entityArrow.getArrowItem() != null ? entityArrow.getArrowItem() : new ItemArrow();
                boolean returnItem = entityArrow.shouldReturnItemOnPickup();

                if (returnItem && !this.isCreative()) {
                    // Should only collect to the offhand slot if the item matches what is already there
                    if (Objects.equals(this.offhandInventory.getItem(0).getId(), item.getId()) && this.offhandInventory.canAddItem(item)) {
                        inventory = this.offhandInventory;
                    } else if (!inventory.canAddItem(item)) {
                        return false;
                    }
                }

                InventoryPickupArrowEvent ev = new InventoryPickupArrowEvent(inventory, entityArrow);

                if (!entityArrow.canBePickedUpBy(this)) {
                    ev.setCancelled();
                }

                this.server.getPluginManager().callEvent(ev);
                if (ev.isCancelled()) {
                    return false;
                }

                if (returnItem) {
                    final TakeItemActorPacket pk = new TakeItemActorPacket();
                    pk.setActorRuntimeID(this.runtimeId());
                    pk.setItemRuntimeID(entity.runtimeId());
                    Server.broadcastPacket(entity.getViewers().values(), pk);
                    this.sendPacket(pk);

                    if (!this.isCreative()) {
                        inventory.addItem(item.clone());
                    }
                }

                entity.close();
                return true;
            } else if (entity instanceof EntityThrownTrident) {
                // Check Trident is returning to shooter
                if (!((EntityThrownTrident) entity).hadCollision) {
                    if (entity.isNoClip()) {
                        if (!((EntityProjectile) entity).shootingEntity.equals(this)) {
                            return false;
                        }
                    } else {
                        return false;
                    }
                }

                if (!((EntityThrownTrident) entity).isPlayer()) {
                    return false;
                }

                Item item = ((EntityThrownTrident) entity).getItem();
                if (!this.isCreative() && !this.inventory.canAddItem(item)) {
                    return false;
                }

                InventoryPickupTridentEvent ev = new InventoryPickupTridentEvent(this.inventory, (EntityThrownTrident) entity);

                int pickupMode = ((EntityThrownTrident) entity).getPickupMode();
                if (pickupMode == EntityProjectile.PICKUP_NONE || (pickupMode == EntityProjectile.PICKUP_CREATIVE && !this.isCreative())) {
                    ev.setCancelled();
                }

                this.server.getPluginManager().callEvent(ev);
                if (ev.isCancelled()) {
                    return false;
                }

                final TakeItemActorPacket pk = new TakeItemActorPacket();
                pk.setActorRuntimeID(this.runtimeId());
                pk.setItemRuntimeID(entity.runtimeId());
                Server.broadcastPacket(entity.getViewers().values(), pk);
                this.sendPacket(pk);

                if (!((EntityThrownTrident) entity).isCreative()) {
                    if (inventory.getItem(((EntityThrownTrident) entity).getFavoredSlot()).isNull()) {
                        inventory.setItem(((EntityThrownTrident) entity).getFavoredSlot(), item.clone());
                    } else {
                        inventory.addItem(item.clone());
                    }
                }
                entity.close();
                return true;
            } else if (entity instanceof EntityItem entityItem) {
                if (entityItem.getPickupDelay() <= 0 && !entityItem.isDisplayOnly()) {
                    Item item = entityItem.getItem();

                    if (item != null) {
                        if (!this.isCreative() && !this.inventory.canAddItem(item)) {
                            return false;
                        }

                        if (!inventory.callPickupItemEvent(entityItem)) {
                            return false;
                        }

                        if (item.getBlockUnsafe() instanceof BlockWood) {
                            this.awardAchievement("mineWood");
                        } else if (Objects.equals(item.getId(), Item.DIAMOND)) {
                            this.awardAchievement("diamond");
                        }

                        final TakeItemActorPacket pk = new TakeItemActorPacket();
                        pk.setActorRuntimeID(this.runtimeId());
                        pk.setItemRuntimeID(entity.runtimeId());
                        Server.broadcastPacket(entity.getViewers().values(), pk);
                        this.sendPacket(pk);

                        this.inventory.addItem(item.clone());
                        entity.close();
                        return true;
                    }
                }
            }
        }

        if (entity instanceof EntityXpOrb xpOrb && this.boundingBox.isVectorInside(entity) && xpOrb.shouldPickup()) {
            int exp = xpOrb.getExp();
            entity.kill();
            this.getLevel().addLevelEvent(LevelEvent.SOUND_EXPERIENCE_ORB_PICKUP, 0, this);

            //Mending
            ArrayList<Integer> itemsWithMending = new ArrayList<>();
            int[] equipmentSlots = {
                    inventory.getHeldItemIndex(), -1,
                    HumanInventory.ARMORS_INDEX, HumanInventory.ARMORS_INDEX + 1,
                    HumanInventory.ARMORS_INDEX + 2, HumanInventory.ARMORS_INDEX + 3
            };
            for (int slot : equipmentSlots) {
                Item equipped = slot == -1 ? getOffhandInventory().getItem(0) : inventory.getItem(slot);
                if (equipped.hasEnchantment(Enchantment.ID_MENDING)
                        && equipped.getMaxDurability() > 0
                        && !equipped.isUnbreakable()
                        && !equipped.getNbt().getBoolean("Unbreakable")
                        && equipped.getDamage() > 0) {
                    itemsWithMending.add(slot);
                }
            }
            if (exp > 0 && !itemsWithMending.isEmpty()) {
                int slot = itemsWithMending.get(ThreadLocalRandom.current().nextInt(itemsWithMending.size()));
                Item toRepair = slot == -1 ? getOffhandInventory().getItem(0) : inventory.getItem(slot);
                String itemId = toRepair.getId();
                int previousDamage = toRepair.getDamage();
                int repaired = (int) Math.min(previousDamage, (long) exp * 2);
                toRepair.setDamage(previousDamage - repaired);
                if (toRepair.getDamage() < previousDamage) {
                    boolean applied = slot == -1
                            ? getOffhandInventory().setItem(0, toRepair)
                            : inventory.setItem(slot, toRepair);
                    if (applied) {
                        Item updated = slot == -1 ? getOffhandInventory().getItem(0) : inventory.getItem(slot);
                        if (!updated.isNull() && itemId.equals(updated.getId())) {
                            int actualRepair = Math.max(0, Math.min(repaired, previousDamage - updated.getDamage()));
                            exp -= actualRepair / 2;
                        }
                    }
                }
            }

            if (exp > 0) this.addExperience(exp, true);
            return true;
        }

        return false;
    }

    @Override
    public int hashCode() {
        if ((this.hash == 0) || (this.hash == 485)) {
            this.hash = (485 + (getUniqueId() != null ? getUniqueId().hashCode() : 0));
        }

        return this.hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (!(obj instanceof Player other)) {
            return false;
        }
        return Objects.equals(this.getUniqueId(), other.getUniqueId()) && this.runtimeId() == other.runtimeId();
    }

    /**
     * Whether the player is breaking block
     *
     * @return boolean
     */
    public boolean isBreakingBlock() {
        return this.breakingBlock != null;
    }

    /**
     * Show a window of an XBOX account's profile
     *
     * @param xuid the XUID
     */
    public void showXboxProfile(String xuid) {
        final ShowProfilePacket pk = new ShowProfilePacket();
        pk.setPlayerXUID(xuid);
        this.sendPacket(pk);
    }

    /**
     * Start fishing
     *
     * @param fishingRod fishing rod item
     */
    public void startFishing(Item fishingRod) {
        CompoundTag nbt = new CompoundTag()
            .putList("Pos", new ListTag<FloatTag>()
                .add(new FloatTag((float) x))
                .add(new FloatTag((float) (y + this.getEyeHeight())))
                .add(new FloatTag((float) z)))
            .putList("Motion", new ListTag<FloatTag>()
                .add(new FloatTag((float) (-Math.sin(yaw / 180 + Math.PI) * Math.cos(pitch / 180 * Math.PI))))
                .add(new FloatTag((float) -Math.sin(pitch / 180 * Math.PI)))
                .add(new FloatTag((float) (Math.cos(yaw / 180 * Math.PI) * Math.cos(pitch / 180 * Math.PI)))))
            .putList("Rotation", new ListTag<FloatTag>()
                .add(new FloatTag((float) yaw))
                .add(new FloatTag((float) pitch)));
        double f = 1.1;
        EntityFishingHook fishingHook = new EntityFishingHook(chunk, nbt, this);
        fishingHook.setMotion(new Vector3(-Math.sin(Math.toRadians(yaw)) * Math.cos(Math.toRadians(pitch)) * f * f,
            -Math.sin(Math.toRadians(pitch)) * f * f,
            Math.cos(Math.toRadians(yaw)) * Math.cos(Math.toRadians(pitch)) * f * f)
        );
        ProjectileLaunchEvent ev = new ProjectileLaunchEvent(fishingHook, this);
        this.getServer().getPluginManager().callEvent(ev);
        if (ev.isCancelled()) {
            fishingHook.close();
        } else {
            this.fishing = fishingHook;
            fishingHook.rod = fishingRod;
            fishingHook.checkLure();
            fishingHook.spawnToAll();
        }
    }

    /**
     * Stop fishing
     *
     * @param click clicked or forced
     */
    public void stopFishing(boolean click) {
        if (this.fishing != null && click) {
            fishing.reelLine();
        } else if (this.fishing != null) {
            this.fishing.close();
        }

        this.fishing = null;
    }

    @Override
    public boolean doesTriggerPressurePlate() {
        return this.gamemode != SPECTATOR;
    }

    @Override
    public String toString() {
        return "Player(name='" + getName() +
            "', location=" + super.toString() +
            ')';
    }

    /**
     * Adds the items to the main player inventory and drops on the floor any excess.
     *
     * @param items The items to give to the player.
     */
    public void giveItem(Item... items) {
        for (Item failed : getInventory().addItem(items)) {
            getLevel().dropItem(this, failed);
        }
    }

    /**
     * How many ticks have passed since the player last sleeped, 1 tick = 0.05 s
     *
     * @return the ticks
     */
    public int getTimeSinceRest() {
        return timeSinceRest;
    }

    /**
     * Set the timeSinceRest ticks
     *
     * @see #getTimeSinceRest()
     */
    public void setTimeSinceRest(int timeSinceRest) {
        this.timeSinceRest = timeSinceRest;
    }

    // TODO: Support Translation Parameters
    public void sendPopupJukebox(String message) {
        final MessageAndParams body = new MessageAndParams();
        body.setMessage(this.server.getLanguage().tr(message));

        final TextPacket pk = new TextPacket();
        pk.setMessageType(TextPacketType.JUKEBOX_POPUP);
        pk.setSendersXUID("");
        pk.setBody(body);

        this.sendPacket(pk);
    }

    public void sendSystem(String message) {
        final MessageOnly body = new MessageOnly();
        body.setMessage(this.server.getLanguage().tr(message));

        final TextPacket pk = new TextPacket();
        pk.setMessageType(TextPacketType.SYSTEM_MESSAGE);
        pk.setSendersXUID("");
        pk.setBody(body);

        this.sendPacket(pk);
    }

    public void sendWhisper(String message) {
        this.sendWhisper("", message);
    }

    public void sendWhisper(String source, String message) {
        final AuthorAndMessage body = new AuthorAndMessage();
        body.setPlayerName(source);
        body.setMessage(this.server.getLanguage().tr(message));

        final TextPacket pk = new TextPacket();
        pk.setMessageType(TextPacketType.WHISPER);
        pk.setSendersXUID("");
        pk.setBody(body);

        this.sendPacket(pk);
    }

    public void sendAnnouncement(String message) {
        this.sendAnnouncement("", message);
    }

    public void sendAnnouncement(String source, String message) {
        final AuthorAndMessage body = new AuthorAndMessage();
        body.setPlayerName(source);
        body.setMessage(this.server.getLanguage().tr(message));

        final TextPacket pk = new TextPacket();
        pk.setMessageType(TextPacketType.ANNOUNCEMENT);
        pk.setSendersXUID("");
        pk.setBody(body);

        this.sendPacket(pk);
    }

    public void completeUsingItem(int itemId, ItemUseMethod method) {
        final CompletedUsingItemPacket pk = new CompletedUsingItemPacket();
        pk.setItemId(itemId);
        pk.setItemUseMethod(method);
        this.sendPacket(pk);
    }

    public boolean isShowingCredits() {
        return showingCredits;
    }

    public void setShowingCredits(boolean showingCredits) {
        this.showingCredits = showingCredits;
        if (showingCredits) {
            final ShowCreditsPacket pk = new ShowCreditsPacket();
            pk.setPlayerRuntimeID(this.runtimeId());
            pk.setCreditsState(
                showingCredits ? ShowCreditsPacket.CreditsState.START_CREDITS : ShowCreditsPacket.CreditsState.END_CREDITS
            );
            this.sendPacket(pk);
        }
    }

    public void showCredits() {
        this.setShowingCredits(true);
    }


    public boolean hasSeenCredits() {
        return hasSeenCredits;
    }

    public void setHasSeenCredits(boolean hasSeenCredits) {
        this.hasSeenCredits = hasSeenCredits;
    }

    public boolean sendPacketImmediately(BedrockPacket packet) {
        if (!this.isConnected()) {
            return false;
        }
        if (!this.callPacketSendEvent(packet)) {
            return false;
        }
        this.getSession().sendPacketImmediately(packet);
        return true;
    }

    /**
     * Player screen shake effect
     *
     * @param intensity   the intensity
     * @param duration    the duration
     * @param shakeType   the shake type
     * @param shakeAction the shake action
     */

    public void shakeCamera(float intensity, float duration, CameraShakeType shakeType, CameraShakeAction shakeAction) {
        final CameraShakePacket packet = new CameraShakePacket();
        packet.setIntensity(intensity);
        packet.setSeconds(duration);
        packet.setShakeType(shakeType);
        packet.setShakeAction(shakeAction);
        this.sendPacket(packet);
    }

    /**
     * Send a Toast message box to the player
     *
     * @param title   the title
     * @param content the content
     */
    public void sendToast(String title, String content) {
        final ToastRequestPacket pk = new ToastRequestPacket();
        pk.setTitle(title);
        pk.setContent(content);
        this.sendPacket(pk);
    }

    @Override
    public void removeLine(IScoreboardLine line) {
        final SetScorePacket packet = new SetScorePacket();
        packet.setRemove(true);
        var networkInfo = line.toNetworkInfo();
        if (networkInfo != null) {
            packet.getScoreInfo().add(switch (networkInfo) {
                case RemoveScore ignored -> ignored;
                case ChangePlayerScore changePlayerScore -> {
                    final RemoveScore score = new RemoveScore();
                    score.setScoreboardId(changePlayerScore.getScoreboardId());
                    score.setObjectiveName(changePlayerScore.getObjectiveName());
                    yield score;
                }
                case ChangeEntityScore changeEntityScore -> {
                    final RemoveScore score = new RemoveScore();
                    score.setScoreboardId(changeEntityScore.getScoreboardId());
                    score.setObjectiveName(changeEntityScore.getObjectiveName());
                    yield score;
                }
                case ChangeFakePlayerScore changeFakePlayerScore -> {
                    final RemoveScore score = new RemoveScore();
                    score.setScoreboardId(changeFakePlayerScore.getScoreboardId());
                    score.setObjectiveName(changeFakePlayerScore.getObjectiveName());
                    yield score;
                }
                default -> throw new IllegalStateException("Unexpected value: " + networkInfo);
            });
        }
        this.sendPacket(packet);

        var scorer = new PlayerScorer(this);
        if (line.getScorer().equals(scorer) && line.getScoreboard().getViewers(DisplaySlot.BELOW_NAME).contains(this)) {
            this.setScoreTag("");
        }
    }

    @Override
    public void updateScore(IScoreboardLine line) {
        SetScorePacket packet = new SetScorePacket();
        packet.setRemove(false);
        var networkInfo = line.toNetworkInfo();
        if (networkInfo != null)
            packet.getScoreInfo().add(networkInfo);
        this.sendPacket(packet);

        var scorer = new PlayerScorer(this);
        if (line.getScorer().equals(scorer) && line.getScoreboard().getViewers(DisplaySlot.BELOW_NAME).contains(this)) {
            this.setScoreTag(line.getScore() + " " + line.getScoreboard().getDisplayName());
        }
    }

    @Override
    public void display(IScoreboard scoreboard, DisplaySlot slot) {
        final SetDisplayObjectivePacket setDisplayObjectivePacket = new SetDisplayObjectivePacket();
        setDisplayObjectivePacket.setDisplaySlotName(slot.getSlotName());
        setDisplayObjectivePacket.setObjectiveName(scoreboard.getObjectiveName());
        setDisplayObjectivePacket.setObjectiveDisplayName(scoreboard.getDisplayName() != null ? scoreboard.getDisplayName() : "");
        setDisplayObjectivePacket.setCriteriaName(scoreboard.getCriteriaName());
        setDisplayObjectivePacket.setSortOrder(scoreboard.getSortOrder());
        this.sendPacket(setDisplayObjectivePacket);

        //client will not storage the score of a scoreboard, so we should send the score to client
        final SetScorePacket setScorePacket = new SetScorePacket();
        setScorePacket.setRemove(false);
        setScorePacket.getScoreInfo().addAll(
            scoreboard.getLines().values().stream()
                .map(IScoreboardLine::toNetworkInfo)
                .filter(Objects::nonNull)
                .toList()
        );
        this.sendPacket(setScorePacket);

        var scorer = new PlayerScorer(this);
        var line = scoreboard.getLine(scorer);
        if (slot == DisplaySlot.BELOW_NAME && line != null) {
            this.setScoreTag(line.getScore() + " " + scoreboard.getDisplayName());
        }
    }

    @Override
    public void hide(DisplaySlot slot) {
        final SetDisplayObjectivePacket setDisplayObjectivePacket = new SetDisplayObjectivePacket();
        setDisplayObjectivePacket.setDisplaySlotName(slot.getSlotName());
        setDisplayObjectivePacket.setObjectiveName("");
        setDisplayObjectivePacket.setObjectiveDisplayName("");
        setDisplayObjectivePacket.setCriteriaName("");
        setDisplayObjectivePacket.setSortOrder(ObjectiveSortOrder.ASCENDING);
        this.sendPacket(setDisplayObjectivePacket);

        if (slot == DisplaySlot.BELOW_NAME) {
            this.setScoreTag("");
        }
    }

    @Override
    public void removeScoreboard(IScoreboard scoreboard) {
        final RemoveObjectivePacket removeObjectivePacket = new RemoveObjectivePacket();
        removeObjectivePacket.setObjectiveName(scoreboard.getObjectiveName());

        this.sendPacket(removeObjectivePacket);
    }

    public Boolean isOpenSignFront() {
        return openSignFront;
    }

    /**
     * Set the status of the current player opening sign
     *
     * @param frontSide true means open sign front, vice versa. If it is null, it means that the player has not opened sign
     */
    public void setOpenSignFront(Boolean frontSide) {
        openSignFront = frontSide;
    }

    /**
     * Opens the player's sign editor GUI for the sign at the given position.
     */
    public void openSignEditor(Vector3 position, boolean frontSide) {
        if (openSignFront == null) {
            BlockEntity blockEntity = this.getLevel().getBlockEntity(position);
            if (blockEntity instanceof BlockEntitySign blockEntitySign) {
                if (blockEntitySign.getEditorEntityRuntimeId() == -1) {
                    blockEntitySign.setEditorEntityRuntimeId(this.runtimeId());
                    final OpenSignPacket openSignPacket = new OpenSignPacket();
                    openSignPacket.setPos(position.asBlockVector3().toNetwork());
                    openSignPacket.setFrontSide(frontSide);
                    this.sendPacket(openSignPacket);
                    setOpenSignFront(frontSide);
                }
            } else {
                throw new IllegalArgumentException("Block at this position is not a sign");
            }
        }
    }

    public void setFlySneaking(boolean sneaking) {
        this.flySneaking = sneaking;
    }


    public boolean isFlySneaking() {
        return this.flySneaking;
    }

    /**
     * Returns the current unrestricted base budget of the adaptive chunk publisher.
     * <p>
     * This is no longer a fixed per-player chunks-per-tick limit. Actual publication
     * grants are calculated dynamically by {@link org.powernukkitx.level.ChunkPublisherBudgetController}
     * using network capacity, active-streamer fairness, transport pressure, recent
     * chunk payload cost, available byte tokens, and runtime resource pressure.
     * Consequently, the number returned here may be higher than the number of chunks
     * actually granted to this player during a publisher pass.
     *
     * @return current unrestricted global chunk publication base
     * @deprecated LevelChunk publication no longer uses a fixed per-player chunks-per-tick
     * limit. Plugins should not use this value to control or predict chunk publication.
     */
    @Deprecated(since = "3.1.0", forRemoval = true)
    public int getChunkSendCountPerTick() {
        return this.server.getChunkPublisherBudgetController().getDynamicBaseBudget();
    }

    public void setEnderChestOpen(boolean v) {
        this.enderChestOpen = v;
    }

    public boolean getEnderChestOpen() {
        return this.enderChestOpen;
    }

    public boolean getFakeInventoryOpen() {
        return fakeInventoryOpen;
    }

    public void setFakeInventoryOpen(boolean fakeInventoryOpen) {
        this.fakeInventoryOpen = fakeInventoryOpen;
    }

    public Color getLocatorBarColor() {
        return this.locatorBarColor;
    }

    public void setLocatorBarColor(Color color) {
        this.locatorBarColor = color;
        if (this.spawned) {
            this.server.updatePlayerListData(this.getUniqueId(), this.runtimeId(), this.getDisplayName(), this.getSkin(), this.getXUID(), this.getLocatorBarColor());
        }
    }

    public WardenWarningData getWardenWarningData() {
        return this.wardenWarningData;
    }

    /**
     * Gets fog stack.
     */
    public List<String> getFogStack() {
        return fogStack;
    }

    /**
     * The player's recipe book, holding every recipe this player has discovered.
     * The instance lives as long as the player and is usable before spawn, although it only
     * mirrors changes to the client once {@code recipesUnlock} discovery is active.
     *
     * @return the recipe book, never {@code null}
     */
    public @NotNull PlayerRecipeBook getRecipeBook() {
        return this.recipeBook;
    }

    /**
     * Set the fog stack, if you want to client effect, you need to send the fog stack
     *
     * @param fogStack the fog stack
     */
    public void setFogStack(List<String> fogStack) {
        this.fogStack = fogStack;
    }

    /**
     * Get the player info.
     */
    @NotNull
    public PlayerInfo getPlayerInfo() {
        return this.info;
    }

    /**
     * Gets the XUID of player
     *
     * @return the XUID
     */
    public String getXUID() {
        return Server.resolveXuid(this.info, this.server.getProxyAuthProvider());
    }

    /** @return the two shoulder seats reserved for tame parrots */
    @Override
    public @NotNull RideableComponent getComponentRideable() {
        return PARROT_SHOULDERS;
    }

    /**
     * Returns a shoulder's protocol offset without adding a vehicle base offset.
     * @param seatIndex the shoulder index
     * @param passenger the seated entity
     * @return the passenger's seat offset
     */
    @Override
    @NotNull
    public org.powernukkitx.math.Vector3f getSeatOffsetFor(int seatIndex, @NotNull Entity passenger) {
        if (passenger instanceof EntityParrot) {
            return new org.powernukkitx.math.Vector3f(seatIndex == 0 ? 0.4f : -0.4f, -0.2f, -0.1f);
        }
        return super.getSeatOffsetFor(seatIndex, passenger);
    }

    @Override
    protected void applySeatOffsets() {
        super.applySeatOffsets();
        for (Entity passenger : passengers) {
            if (passenger instanceof EntityParrot) passenger.sendData(this);
        }
    }

    @Override
    protected void broadcastLinkPacket(Entity rider, ActorLinkType type, boolean riderInitiated) {
        super.broadcastLinkPacket(rider, type, riderInitiated);
        SetActorLinkPacket packet = new SetActorLinkPacket();
        packet.setLink(new ActorLink(uniqueIdLong(), rider.uniqueIdLong(), type, false, riderInitiated, 0f));
        sendPacket(packet);
        if (rider instanceof EntityParrot && type != ActorLinkType.NONE) {
            rider.sendData(getViewers().values().toArray(Player.EMPTY_ARRAY));
            rider.sendData(this);
        }
    }

    private boolean releaseShoulderParrots() {
        if (passengers.isEmpty()) return true;
        for (Entity passenger : List.copyOf(passengers)) {
            if (passenger instanceof EntityParrot && !dismountEntity(passenger, true, false)) return false;
        }
        return true;
    }

    /**
     * Applies the shoulder search delay and cleans up links when either endpoint disappears.
     * Exit cancellation is respected while both the player and parrot remain available.
     * @param entity the passenger to release
     * @param sendLinks whether to send the link change to viewers
     * @param riderInitiated whether the passenger initiated the dismount
     * @return whether the passenger was released
     */
    @Override
    public boolean dismountEntity(Entity entity, boolean sendLinks, boolean riderInitiated) {
        boolean dismounted = super.dismountEntity(entity, sendLinks, riderInitiated);
        if (!dismounted && entity instanceof EntityParrot && isPassenger(entity)
                && (!isOnline() || entity.closed)) {
            if (sendLinks) broadcastLinkPacket(entity, ActorLinkType.NONE, riderInitiated);
            detachPassenger(entity);
            updatePassengers(sendLinks, false);
            dismounted = true;
        }
        if (dismounted && entity instanceof EntityParrot parrot) parrot.onShoulderDismounted();
        return dismounted;
    }

    @Override
    protected void updatePassengerPosition(Entity passenger) {
        if (passenger instanceof EntityParrot) {
            org.powernukkitx.math.Vector3f seat = passenger.getSeatPosition(passenger);
            double angle = Math.toRadians(yaw);
            passenger.setPosition(new Vector3(x + seat.x * Math.cos(angle) - seat.z * Math.sin(angle),
                    y + getHeight() + seat.y, z + seat.x * Math.sin(angle) + seat.z * Math.cos(angle)));
            return;
        }
        super.updatePassengerPosition(passenger);
    }

    /**
     * Returns the flight status of player
     */
    public boolean isFlying() {
        return this.getAdventureSettings().get(Type.FLYING);
    }

    /**
     * Sets the flight status of player. If you want to work it properly, you need to use {@link #setAllowFlight}
     *
     * @param value Status value
     */
    public void setFlying(boolean value) {
        boolean isFlying = this.isFlying();

        if (value != isFlying) {
            this.resetFallDistance();

            this.getAdventureSettings().set(Type.FLYING, value);
            this.getAdventureSettings().update();
        }
    }

    public List<Integer> sendPrimitiveShape(PrimitiveShapeDataPayload... shapes) {
        List<Integer> ids = new ArrayList<>();

        for (PrimitiveShapeDataPayload shapeDataPayload : shapes) {
            int id = this.shapeIds.getAndIncrement();
            shapeDataPayload.setNetworkId(id);
            ids.add(id);
        }

        final PrimitiveShapesPacket packet = new PrimitiveShapesPacket();
        packet.getShapes().addAll(Arrays.stream(shapes).toList());
        this.sendPacket(packet);

        return ids;
    }

    public int sendPrimitiveShape(PrimitiveShapeDataPayload shape) {
        final int id = this.shapeIds.getAndIncrement();
        shape.setNetworkId(id);

        final PrimitiveShapesPacket packet = new PrimitiveShapesPacket();
        packet.getShapes().add(shape);

        this.sendPacket(packet);
        return id;
    }

    public void updatePrimitiveShape(int id, PrimitiveShapeDataPayload shape) {
        shape.setNetworkId(id);

        final PrimitiveShapesPacket packet = new PrimitiveShapesPacket();
        packet.getShapes().add(shape);

        this.sendPacket(packet);
    }

    public void removePrimitiveShape(int id) {
        final PrimitiveShapeDataPayload shape = new PrimitiveShapeDataPayload();
        shape.setNetworkId(id);
        shape.setExtraShapeData(PrimitiveShapes.REMOVAL_EXTRA);

        final PrimitiveShapesPacket packet = new PrimitiveShapesPacket();
        packet.getShapes().add(shape);

        this.sendPacket(packet);
    }

    public void clearPrimitiveShapes() {
        List<PrimitiveShapeDataPayload> shapes = new ArrayList<>();

        for (int i = 0; i < shapeIds.get(); i++) {
            final PrimitiveShapeDataPayload shape = new PrimitiveShapeDataPayload();
            shape.setNetworkId(i);
            shape.setExtraShapeData(PrimitiveShapes.REMOVAL_EXTRA);
            shapes.add(shape);
        }

        final PrimitiveShapesPacket packet = new PrimitiveShapesPacket();
        packet.getShapes().addAll(shapes);

        this.sendPacket(packet);

        shapeIds.set(0);
    }

    /**
     * Returns a copy of the active client input lock flags.
     *
     * @return a copy of currently active {@link ClientInputLockComponent}s
     */
    public EnumSet<ClientInputLockComponent> getClientInputLocks() {
        return EnumSet.copyOf(this.clientInputLocks);
    }

    /**
     * Adds a client input lock flag and sends an update packet to the client.
     *
     * <p>
     * Adding a flag means the related input permission will be DISABLED.
     * </p>
     *
     * @param flag the {@link ClientInputLockComponent} to add
     */
    public void addClientInputLock(ClientInputLockComponent flag) {
        if (this.clientInputLocks.add(flag)) {
            this.sendClientInputLocks();
            log.debug("Adding client input lock {} for {}", flag.name(), name);
        }
    }

    /**
     * Removes a client input lock flag and sends an update packet to the client.
     *
     * <p>
     * Removing a flag means the related input permission will be ENABLED.
     * </p>
     *
     * @param flag the {@link ClientInputLockComponent} to remove
     */
    public void removeClientInputLock(ClientInputLockComponent flag) {
        if (this.clientInputLocks.remove(flag)) {
            this.sendClientInputLocks();
            log.debug("Removing client input lock {} for {}", flag.name(), name);
        }
    }

    /**
     * Clears all client input locks and updates the client.
     */
    public void clearClientInputLocks() {
        if (!this.clientInputLocks.isEmpty()) {
            this.clientInputLocks.clear();
            log.debug("Clearing client input locks for {}", name);
            this.sendClientInputLocks();
        }
    }

    /**
     * Sends an {@link UpdateClientInputLocksPacket} to the client
     * using the current input lock state.
     *
     * <p>
     * The server position is mandatory for this packet and must NOT be null.
     * </p>
     */
    protected void sendClientInputLocks() {
        UpdateClientInputLocksPacket pk = new UpdateClientInputLocksPacket();
        pk.getInputLockComponents().addAll(this.clientInputLocks);
        this.sendPacket(pk);
    }

    /**
     * Returns the party of player which is stored in login data.
     *
     * @return partyId
     */
    public String getPartyId() {
        return this.clientChainData.getPartyId();
    }

    @Value
    public static class PlayerInfo {
        ChainValidationResult.IdentityClaims identityClaims;
        ClientChainData clientChainData;
        org.cloudburstmc.protocol.bedrock.data.skin.Skin skin;
        boolean xboxAuth;
    }

    public enum SpawnPointType {
        WORLD,
        PLAYER,
        BLOCK
    }

    /**
     * Sends permitted, registered client commands using their registered labels.
     * Aliases of the same command do not create duplicate entries. No packet is sent
     * when no valid command data is available. Call on the main server loop.
     */
    public void syncAvailableCommands() {
        AvailableCommandsPacket pk = new AvailableCommandsPacket();
        Map<String, CommandDataVersions> data = new HashMap<>();
        int count = 0;
        final Map<String, Command> commands = Server.getInstance().getCommandMap().getCommands();
        // Snapshot the command list under the lock, then release immediately.
        // Permission checks and data generation happen outside the lock to minimise contention.
        List<Command> snapshot;
        synchronized (commands) {
            snapshot = new ArrayList<>(commands.values());
        }
        final Set<Command> distinct = Collections.newSetFromMap(new IdentityHashMap<>());
        for (Command command : snapshot) {
            if (!command.testPermissionSilent(this.getPlayer()) || !command.isRegistered() || command.isServerSideOnly()) {
                continue;
            }
            if (!distinct.add(command)) {
                continue;
            }
            ++count;
            CommandDataVersions data0 = command.generateCustomCommandData(this.getPlayer());
            data.put(command.getLabel(), data0);
        }
        if (count > 0) {
            Map<String, CommandDataVersions> filtered = getStringCommandDataVersionsMap(data);

            if (!filtered.isEmpty()) {
                final List<CommandData> commandData = new ObjectArrayList<>();
                for (Entry<String, CommandDataVersions> entry : filtered.entrySet()) {
                    commandData.addAll(entry.getValue().toNetwork(entry.getKey()));
                }

                pk.getCommands().addAll(commandData);
                this.sendPacketImmediately(pk);
                this.trackDeclaredSoftEnums(commandData);
            }
        }
    }

    private void trackDeclaredSoftEnums(List<CommandData> commandData) {
        final Set<String> declared = new HashSet<>();
        for (CommandData command : commandData) {
            for (CommandOverloadData overload : command.getOverloads()) {
                for (CommandParamData param : overload.getOverloads()) {
                    CommandEnumData enumData = param.getEnumData();
                    if (enumData != null && enumData.isSoft()) {
                        declared.add(enumData.getName());
                    }
                }
            }
        }
        this.declaredSoftEnums.retainAll(declared);
        this.declaredSoftEnums.addAll(declared);
    }

    public boolean knowsSoftEnum(String name) {
        return this.declaredSoftEnums.contains(name);
    }

    private @NotNull Map<String, CommandDataVersions> getStringCommandDataVersionsMap(Map<String, CommandDataVersions> data) {
        Map<String, CommandDataVersions> filtered = new HashMap<>();

        for (Entry<String, CommandDataVersions> entry : data.entrySet()) {
            CommandDataVersions versions = entry.getValue();
            if (versions == null) continue;

            if (versions.versions == null || versions.versions.isEmpty()) continue;

            boolean valid = false;

            for (NukkitCommandData v : versions.versions) {
                if (v == null) continue;
                if (v.overloads == null || v.overloads.isEmpty()) continue;

                boolean overloadValid = false;
                for (CommandOverload overload : v.overloads.values()) {
                    if (overload == null) continue;

                    overloadValid = true;
                }

                if (overloadValid) {
                    valid = true;
                    break;
                }
            }

            if (valid) {
                filtered.put(entry.getKey(), versions);
            }
        }
        return filtered;
    }

    /**
     * Sends the complete UI inventory container during the initial login sequence.
     */
    public void sendInitialUiContents() {
        final InventoryContentPacket packet = new InventoryContentPacket();
        packet.setContainerId(ContainerId.UI);

        for (int i = 0; i < 54; ++i) {
            packet.getSlots().add(ItemData.AIR);
        }

        final Item cursorItem = this.getCursorInventory().getUnclonedItem(0);
        packet.getSlots().set(
                0,
                cursorItem.isNull()
                        ? ItemData.AIR
                        : cursorItem.toNetwork()
        );

        for (int i = 0; i < 4; ++i) {
            final Item craftingItem = this.getCraftingGrid().getUnclonedItem(i);
            packet.getSlots().set(
                    28 + i,
                    craftingItem.isNull()
                            ? ItemData.AIR
                            : craftingItem.toNetwork()
            );
        }

        final Item creativeOutput = this.getCreativeOutputInventory().getUnclonedItem(0);
        packet.getSlots().set(
                50,
                creativeOutput == null || creativeOutput.isNull()
                        ? ItemData.AIR
                        : creativeOutput.toNetwork()
        );

        this.sendPacketImmediately(packet);
    }

    /**
     * Sends the offhand inventory during the initial login sequence.
     */
    public void sendInitialOffhandContents() {
        final InventoryContentPacket packet = new InventoryContentPacket();
        packet.setContainerId(ContainerId.OFFHAND);

        final Item offhandItem = this.getOffhandInventory().getUnclonedItem(0);
        packet.getSlots().add(
                offhandItem == null || offhandItem.isNull()
                        ? ItemData.AIR
                        : offhandItem.toNetwork()
        );

        this.sendPacketImmediately(packet);
    }

    /**
     * Sends the selected hotbar slot during the initial login sequence.
     */
    public void sendInitialHotbar() {
        final PlayerHotbarPacket packet = new PlayerHotbarPacket();
        packet.setSelectedSlot(this.getInventory().getHeldItemIndex());
        packet.setContainerID(ContainerId.INVENTORY);
        packet.setShouldSelectSlot(true);

        this.sendPacketImmediately(packet);
    }

    public void syncInventory() {
        this.syncInventory(true);
    }

    protected void syncInventory(boolean sendArmorDamage) {
        Player player = getPlayer();
        if (player != null) {
            if (player.spawned) {
                player.getInventory().sendHeldItem(player);
                player.getInventory().sendContents(player);
                player.getInventory().sendArmorContents(player, sendArmorDamage);
                player.getCursorInventory().sendContents(player);
                player.getOffhandInventory().sendContents(player);
            } else {
                player.getInventory().sendInitialContents(player);
                player.getInventory().sendInitialArmorContents(player);
                player.sendInitialUiContents();
                player.sendInitialOffhandContents();
                player.sendInitialHotbar();
            }
            player.getEnderChestInventory().sendContents(player);

            //Send bundle content
            this.playerHandle.getWindows().keySet().stream().filter(inv -> !(inv instanceof CreativeOutputInventory)).forEach(inventory -> {
                for (int index : inventory.getContents().keySet()) {
                    Item item = inventory.getUnclonedItem(index);
                    if (item instanceof ItemBundle bundle) {
                        if (bundle.hasNbt()) {
                            bundle.onChange(inventory);
                            inventory.sendSlot(index, player);
                        }
                    }
                }
            });
        }
    }

    public void syncCreativeContent() {
        if (this.isConnected() && PlayerSessionHolder.trySendCreativeContent(this)) {
            return;
        }
        final CreativeContentPacket packet = new CreativeContentPacket();
        packet.getGroups().addAll(Registries.CREATIVE.getCreativeGroups());
        packet.getEntries().addAll(Registries.CREATIVE.getCreativeItemData());

        this.sendPacketImmediately(packet);
    }

    public void clearLastUsedItem() {
        if (this.lastUsedItem == null) {
            return;
        }
        this.removeLastUseTick(this.lastUsedItem.getId());
        this.lastUsedItem = null;
    }

    public void sendFogStack() {
        final PlayerFogPacket playerFogPacket = new PlayerFogPacket();
        playerFogPacket.getFogStack().addAll(this.getFogStack());
        this.sendPacketImmediately(playerFogPacket);
    }

    public void waitForAck(Runnable runnable) {
        long creationTime = this.sendNetworkStackLatencyPacket(runnable);
        this.getLevel().getScheduler().scheduleDelayedTask(InternalPlugin.INSTANCE, () -> {
            Runnable delayedRunnable = this.ackRunnables.remove(creationTime);
            if (delayedRunnable != null) {
                delayedRunnable.run();
            }
        }, 5);
    }

    private long sendNetworkStackLatencyPacket() {
        return this.sendNetworkStackLatencyPacket(null);
    }

    private long sendNetworkStackLatencyPacket(Runnable runnable) {
        final long creationTime = System.currentTimeMillis() * 1_000_000L + Math.floorMod(System.nanoTime(), 1_000_000L);
        if (runnable != null) {
            this.ackRunnables.put(creationTime, runnable);
        }
        final NetworkStackLatencyPacket packet = new NetworkStackLatencyPacket();
        packet.setCreationTime(creationTime);
        packet.setFromServer(true);
        this.session.sendPacketImmediately(packet);
        return creationTime;
    }

    protected void onAckReceive(long creationTime) {
        Runnable runnable = this.ackRunnables.remove(creationTime);
        if (runnable == null) {
            return;
        }
        runnable.run();
    }
}
