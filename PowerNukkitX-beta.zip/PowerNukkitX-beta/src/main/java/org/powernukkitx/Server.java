package org.powernukkitx;

import com.google.common.base.Preconditions;
import com.google.common.util.concurrent.ThreadFactoryBuilder;
import eu.okaeri.configs.ConfigManager;
import io.netty.util.internal.PlatformDependent;
import it.unimi.dsi.fastutil.longs.LongArrayList;
import it.unimi.dsi.fastutil.longs.LongList;
import it.unimi.dsi.fastutil.longs.LongLists;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.FileUtils;
import org.cloudburstmc.nbt.NBTInputStream;
import org.cloudburstmc.nbt.NBTOutputStream;
import org.cloudburstmc.nbt.NbtMap;
import org.cloudburstmc.nbt.NbtUtils;
import org.cloudburstmc.protocol.bedrock.data.BuildPlatform;
import org.cloudburstmc.protocol.bedrock.data.payload.experiment.ExperimentToggle;
import org.cloudburstmc.protocol.bedrock.data.payload.list.PlayerListAddEntry;
import org.cloudburstmc.protocol.bedrock.data.payload.list.PlayerListRemoveEntry;
import org.cloudburstmc.protocol.bedrock.packet.BedrockPacket;
import org.cloudburstmc.protocol.bedrock.packet.PlayerListPacket;
import org.iq80.leveldb.CompressionType;
import org.iq80.leveldb.DB;
import org.iq80.leveldb.DBIterator;
import org.iq80.leveldb.Options;
import org.iq80.leveldb.WriteBatch;
import org.iq80.leveldb.impl.Iq80DBFactory;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.jetbrains.annotations.UnmodifiableView;
import org.powernukkitx.block.BlockComposter;
import org.powernukkitx.block.BlockLightProperties;
import org.powernukkitx.block.dispenser.DispenseBehaviorRegister;
import org.powernukkitx.blockentity.BlockEntity;
import org.powernukkitx.command.Command;
import org.powernukkitx.command.CommandSender;
import org.powernukkitx.command.ConsoleCommandSender;
import org.powernukkitx.command.PluginIdentifiableCommand;
import org.powernukkitx.command.SimpleCommandMap;
import org.powernukkitx.command.defaults.WorldCommand;
import org.powernukkitx.command.function.FunctionManager;
import org.powernukkitx.config.ServerSettings;
import org.powernukkitx.config.category.NetworkSettings;
import org.powernukkitx.config.YamlSnakeYamlConfigurer;
import org.powernukkitx.config.updater.ConfigUpdater;
import org.powernukkitx.console.NukkitConsole;
import org.powernukkitx.education.Education;
import org.powernukkitx.entity.Attribute;
import org.powernukkitx.entity.Entity;
import org.powernukkitx.entity.data.human.Skin;
import org.powernukkitx.entity.data.profession.Profession;
import org.powernukkitx.entity.data.property.EntityProperty;
import org.powernukkitx.event.HandlerList;
import org.powernukkitx.event.level.LevelInitEvent;
import org.powernukkitx.event.level.LevelLoadEvent;
import org.powernukkitx.event.network.NetworkRegisterEvent;
import org.powernukkitx.event.player.PlayerLoginEvent;
import org.powernukkitx.event.server.QueryRegenerateEvent;
import org.powernukkitx.event.server.ServerReloadEvent;
import org.powernukkitx.event.server.ServerStartedEvent;
import org.powernukkitx.event.server.ServerStopEvent;
import org.powernukkitx.item.Item;
import org.powernukkitx.item.enchantment.Enchantment;
import org.powernukkitx.lang.BaseLang;
import org.powernukkitx.lang.LangCode;
import org.powernukkitx.lang.TextContainer;
import org.powernukkitx.level.ChunkPublisherBudgetController;
import org.powernukkitx.level.DimensionEnum;
import org.powernukkitx.level.GameRule;
import org.powernukkitx.level.Level;
import org.powernukkitx.level.Position;
import org.powernukkitx.level.format.Chunk;
import org.powernukkitx.level.format.IChunk;
import org.powernukkitx.level.format.LevelConfig;
import org.powernukkitx.level.format.LevelProvider;
import org.powernukkitx.level.format.LevelProviderFactory;
import org.powernukkitx.level.format.LevelProviderManager;
import org.powernukkitx.level.format.leveldb.LevelDBProvider;
import org.powernukkitx.migration.MigrationService;
import org.powernukkitx.level.tickingarea.manager.SimpleTickingAreaManager;
import org.powernukkitx.level.tickingarea.manager.TickingAreaManager;
import org.powernukkitx.level.tickingarea.storage.LevelDBTickingAreaStorage;
import org.powernukkitx.level.updater.Updater;
import org.powernukkitx.level.updater.block.BlockStateUpdaterBase;
import org.powernukkitx.math.NukkitMath;
import org.powernukkitx.math.Vector3;
import org.powernukkitx.metadata.EntityMetadataStore;
import org.powernukkitx.metadata.LevelMetadataStore;
import org.powernukkitx.metadata.PlayerMetadataStore;
import org.powernukkitx.metrics.NukkitMetrics;
import org.powernukkitx.nbt.tag.CompoundTag;
import org.powernukkitx.nbt.tag.FloatTag;
import org.powernukkitx.nbt.tag.ListTag;
import org.powernukkitx.nbt.tag.StringTag;
import org.powernukkitx.nbt.tag.Tag;
import org.powernukkitx.network.FlushablePeer;
import org.powernukkitx.network.Network;
import org.powernukkitx.network.NetworkConstants;
import org.powernukkitx.network.NetworkInterface;
import org.powernukkitx.network.SharedPacket;
import org.powernukkitx.network.process.LoginService;
import org.powernukkitx.network.process.NetworkState;
import org.powernukkitx.network.process.PlayerListEncoder;
import org.powernukkitx.network.process.PlayerSessionHolder;
import org.powernukkitx.network.process.auth.ProxyAuthProvider;
import org.powernukkitx.permission.BanEntry;
import org.powernukkitx.permission.BanList;
import org.powernukkitx.permission.DefaultPermissions;
import org.powernukkitx.permission.Permissible;
import org.powernukkitx.plugin.InternalPlugin;
import org.powernukkitx.plugin.JavaPluginLoader;
import org.powernukkitx.plugin.Plugin;
import org.powernukkitx.plugin.PluginLoadOrder;
import org.powernukkitx.plugin.PluginManager;
import org.powernukkitx.plugin.service.NKServiceManager;
import org.powernukkitx.plugin.service.ServiceManager;
import org.powernukkitx.network.positiontracking.PositionTrackingService;
import org.powernukkitx.recipe.Recipe;
import org.powernukkitx.registry.CreativeGroupsRegistry;
import org.powernukkitx.registry.RecipeRegistry;
import org.powernukkitx.registry.Registries;
import org.powernukkitx.registry.RegistryCache;
import org.powernukkitx.resourcepacks.ResourcePackManager;
import org.powernukkitx.resourcepacks.loader.CdnResourcePackLoader;
import org.powernukkitx.resourcepacks.loader.JarPluginResourcePackLoader;
import org.powernukkitx.resourcepacks.loader.ZippedResourcePackLoader;
import org.powernukkitx.scheduler.ServerScheduler;
import org.powernukkitx.scheduler.Task;
import org.powernukkitx.scoreboard.manager.IScoreboardManager;
import org.powernukkitx.scoreboard.manager.ScoreboardManager;
import org.powernukkitx.scoreboard.storage.LevelDBScoreboardStorage;
import org.powernukkitx.utils.*;
import org.powernukkitx.utils.collection.FreezableArrayManager;
import org.powernukkitx.wizard.WizardConfig;

import java.awt.*;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.UncheckedIOException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.UnknownHostException;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.util.*;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.ForkJoinWorkerThread;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.locks.LockSupport;
import java.util.function.Function;

/**
 * Represents the main server singleton for PowerNukkitX.
 * <p>
 * This class is instantiated in {@link PowerNukkitX} and can be accessed via
 * {@link org.powernukkitx.Server#getInstance()}.
 * The constructor performs various initialization tasks, including
 * configuration loading, thread and thread pool creation,
 * plugin startup, and registration of recipes, blocks, entities, items, and
 * more.
 *
 * <p>
 * Key responsibilities include:
 * <ul>
 * <li>Managing server lifecycle and configuration</li>
 * <li>Handling plugins, commands, and events</li>
 * <li>Managing players, levels, and networking</li>
 * <li>Providing access to server-wide utilities and managers</li>
 * </ul>
 *
 * <p>
 * Note: This class is a singleton and should be accessed via
 * {@link #getInstance()}.
 *
 * @author MagicDroidX
 * @author Box
 */

@Slf4j
public class Server {
    public static final String BROADCAST_CHANNEL_ADMINISTRATIVE = "nukkit.broadcast.admin";
    public static final String BROADCAST_CHANNEL_USERS = "nukkit.broadcast.user";
    private static final int PLAYER_LIST_ENTRIES_PER_PACKET = 16;
    private static final long PLAYER_DATA_WRITE_WAIT_MILLIS = 10_000L;
    private static Server instance = null;

    private BanList banByName;
    private BanList banByIP;
    private Config operators;
    private Config whitelist;
    private final AtomicBoolean isRunning = new AtomicBoolean(true);
    private final LongList busyingTime = LongLists.synchronize(new LongArrayList(0));
    private boolean hasStopped = false;
    private final AtomicBoolean hasBeforeStopped = new AtomicBoolean(false);
    private PluginManager pluginManager;
    private ServerScheduler scheduler;
    /**
     * A tick counter that records the number of ticks the server has passed.
     * Long: at high tick rates an int overflows within hours (2^31 ticks ≈ 13 h at 45k TPS).
     * Int-typed consumers (scheduler, onUpdate) receive a truncated view that wraps.
     */
    private long tickCounter;
    private long nextTick;
    private long nextTickNanos;
    private long lastTitleTickMillis;
    private long lastQueryRegenMillis;
    private long lastAutoSaveMillis;
    /**
     * Ring buffer of the most recent per-tick durations in nanoseconds, indexed by
     * tickCounter. Used by /debug mspt for percentile statistics.
     */
    private final long[] tickDurationsNanos = new long[8192];
    private final float[] tickAverage = {20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20};
    private final float[] useAverage = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
    private float maxTick = 20;
    private float maxUse = 0;
    private int sendUsageTicker = 0;
    private final NukkitConsole console;
    private final ConsoleThread consoleThread;
    /**
     * FJP thread pool responsible for terrain generation, data compression and
     * other computing tasks
     */
    public final ForkJoinPool computeThreadPool;
    private final ThreadPoolExecutor chunkIoExecutor;
    private final LoginService loginService;
    private final ScheduledExecutorService levelTickExecutor;
    private final ScheduledExecutorService chunkPublisherExecutor;
    private final ChunkPublisherBudgetController chunkPublisherBudgetController;
    private final boolean levelThreadMode;
    private SimpleCommandMap commandMap;
    private ResourcePackManager resourcePackManager;
    private ConsoleCommandSender consoleSender;
    private IScoreboardManager scoreboardManager;
    private FunctionManager functionManager;
    private TickingAreaManager tickingAreaManager;
    private int maxPlayers;
    private boolean autoSave = true;
    /**
     * Does the configuration item check the login time.
     */
    public boolean checkLoginTime = false;
    private EntityMetadataStore entityMetadata;
    private PlayerMetadataStore playerMetadata;
    private LevelMetadataStore levelMetadata;
    private NetworkInterface network;
    private int defaultGamemode = Integer.MAX_VALUE;
    private int autoSaveTicks = 6000;
    private BaseLang baseLang;
    private LangCode baseLangCode;
    private UUID serverID;
    private final String filePath;
    private final String dataPath;
    private final String pluginPath;
    public final String structurePath;
    private final Set<UUID> uniquePlayers = new HashSet<>();
    private final Map<InetSocketAddress, Player> players = new ConcurrentHashMap<>();
    private final Queue<Player> idleInbound = PlatformDependent.newMpscQueue();
    private volatile boolean waitingForTick;
    private final Map<UUID, Player> playerList = new ConcurrentHashMap<>();
    private final Map<UUID, Player> onlinePlayersView = Collections.unmodifiableMap(playerList);
    private final Map<Long, Player> playerListByUniqueId = new ConcurrentHashMap<>();
    private QueryRegenerateEvent queryRegenerateEvent;
    private PositionTrackingService positionTrackingService;

    /**
     * Server-global Dynamic Properties namespace UUID.
     */
    private static volatile String DP_DEFAULT_GROUP_UUID;

    private final Map<Integer, Level> levels = new HashMap<>() {
        @Override
        public Level put(Integer key, Level value) {
            Level result = super.put(key, value);
            levelArray = levels.values().toArray(Level.EMPTY_ARRAY);
            return result;
        }

        @Override
        public boolean remove(Object key, Object value) {
            boolean result = super.remove(key, value);
            levelArray = levels.values().toArray(Level.EMPTY_ARRAY);
            return result;
        }

        @Override
        public Level remove(Object key) {
            Level result = super.remove(key);
            levelArray = levels.values().toArray(Level.EMPTY_ARRAY);
            return result;
        }
    };
    private Level[] levelArray;
    private final ServiceManager serviceManager = new NKServiceManager();
    private final Thread currentThread;
    private final long launchTime;
    private final ServerSettings settings;
    private Watchdog watchdog;
    private DB serverDataDB;
    private ActorUniqueIdManager actorUniqueIdManager;
    private DynamicProperties dynamicProperties;

    /**
     * @param nbt the player data, {@code null} only in a preloaded record whose stored data is
     *            corrupted
     */
    record PlayerDataRecord(@Nullable CompoundTag nbt, CompoundTag pnxExtra, CompoundTag custom) {
    }

    /**
     * Player data read ahead of the player being created, see {@link #preloadPlayerData(UUID)}.
     *
     * @param uuid       the player the data belongs to
     * @param record     the stored data, or {@code null} when the player has none yet; its
     *                   {@code nbt} is {@code null} when the stored data is corrupted
     * @param writeCount the number of saves requested for this player when the data was read
     */
    @ApiStatus.Internal
    public record PreloadedPlayerData(UUID uuid, @Nullable PlayerDataRecord record, long writeCount) {
        /**
         * @return the name of the level the player was last in, or {@code null} when unknown
         */
        public @Nullable String levelName() {
            return this.record != null && this.record.pnxExtra().containsString("Level")
                ? this.record.pnxExtra().getString("Level") : null;
        }

        /**
         * @return the stored position of the player, or {@code null} when unknown
         */
        public @Nullable Vector3 position() {
            if (this.record == null || this.record.nbt() == null || !this.record.nbt().containsList("Pos")) {
                return null;
            }
            ListTag<FloatTag> pos = this.record.nbt().getList("Pos", FloatTag.class);
            return pos.size() == 3 ? new Vector3(pos.get(0).data, pos.get(1).data, pos.get(2).data) : null;
        }
    }

    /**
     * Save requests and completed writes of one player, used to tell whether preloaded data is
     * current. An entry only exists while a save is outstanding or a login is preloading the
     * player, so the counters never restart while somebody compares against them. Changed only
     * inside {@link ConcurrentHashMap#compute}.
     */
    private static final class PlayerDataWrites {
        final AtomicLong requested = new AtomicLong();
        final AtomicLong completed = new AtomicLong();
        int preloads;
        volatile @Nullable CompletableFuture<Void> lastAsyncWrite;
        volatile RequestedPlayerData latest = RequestedPlayerData.NONE;

        boolean idle() {
            return this.requested.get() == this.completed.get() && this.preloads == 0;
        }
    }

    /**
     * The newest data saves were requested with, part by part, each with the request count it was
     * requested at. A save that leaves out a sidecar keeps the one requested before.
     */
    private record RequestedPlayerData(@Nullable CompoundTag nbt, long nbtAt, @Nullable CompoundTag pnxExtra,
                                       long pnxExtraAt, @Nullable CompoundTag custom, long customAt) {
        static final RequestedPlayerData NONE = new RequestedPlayerData(null, 0L, null, 0L, null, 0L);

        RequestedPlayerData with(long at, CompoundTag nbt, @Nullable CompoundTag pnxExtra, @Nullable CompoundTag custom) {
            return new RequestedPlayerData(nbt, at,
                pnxExtra != null ? pnxExtra : this.pnxExtra, pnxExtra != null ? at : this.pnxExtraAt,
                custom != null ? custom : this.custom, custom != null ? at : this.customAt);
        }
    }

    private final ConcurrentHashMap<UUID, PlayerDataWrites> playerDataWrites = new ConcurrentHashMap<>();
    private ProxyAuthProvider proxyAuthProvider;
    private FreezableArrayManager freezableArrayManager;

    // default levels
    private Level defaultLevel = null;
    private List<ExperimentToggle> experiments;
    private final MigrationService migrationService = new MigrationService(this);

    Server(final String filePath, String dataPath, String pluginPath, String predefinedLanguage,
           WizardConfig wizardConfig) {
        Preconditions.checkState(instance == null, "Already initialized!");
        launchTime = System.currentTimeMillis();
        currentThread = Thread.currentThread(); // Saves the current thread instance as a reference, used in
        // Server#isPrimaryThread()
        instance = this;

        this.filePath = filePath;

        File worlds, players, serverData, structures, pluginFile, commandDataFile;
        if (!(worlds = new File(dataPath + "worlds/")).exists()) {
            worlds.mkdirs();
        }
        players = new File(dataPath + "players/");
        if (!(serverData = new File(dataPath + "server_data/")).exists()) {
            serverData.mkdirs();
        }
        if (!(structures = new File(dataPath + "structures/")).exists()) {
            structures.mkdirs();
        }
        if (!(pluginFile = new File(pluginPath)).exists()) {
            pluginFile.mkdirs();
        }

        this.dataPath = new File(dataPath).getAbsolutePath() + "/";
        this.pluginPath = pluginFile.getAbsolutePath() + "/";
        this.structurePath = this.dataPath + "structures/";
        String commandDataPath = this.dataPath + "/command_data";
        if (!(commandDataFile = new File(commandDataPath)).exists()) {
            commandDataFile.mkdirs();
        }

        this.console = new NukkitConsole(this);
        this.consoleThread = new ConsoleThread();
        this.consoleThread.start();

        while (convertLegacyConfiguration()) {
            /* repeat until all legacy configurations are converted */
        }

        File config = new File(this.dataPath + "pnx.yml");
        String chooseLanguage;

        if (!config.exists()) {
            // Config doesn't exist - use wizard config if provided, otherwise use
            // predefined or default
            if (wizardConfig != null) {
                chooseLanguage = wizardConfig.getLanguage();
                log.info("Using language from setup wizard: {}", chooseLanguage);
            } else if (predefinedLanguage != null && !predefinedLanguage.isEmpty()) {
                chooseLanguage = predefinedLanguage;
                log.info("Using predefined language: {}", chooseLanguage);
            } else {
                chooseLanguage = "eng";
                log.info("Using default language: eng");
            }
        } else {
            Config configInstance = new Config(config);
            chooseLanguage = configInstance.getString("settings.language", "eng");
        }
        this.baseLang = new BaseLang(chooseLanguage);
        this.baseLangCode = mapInternalLang(chooseLanguage);
        this.settings = ConfigManager.create(ServerSettings.class, it -> {
            log.info("Loading {}...", TextFormat.GREEN + "pnx.yml" + TextFormat.RESET);
            it.withConfigurer(new YamlSnakeYamlConfigurer());
            it.withBindFile(config);
            it.withRemoveOrphans(true);
            it.saveDefaults();
            it.load(true);
        });

        if (wizardConfig != null && !config.exists()) {
            this.settings.baseSettings().language(wizardConfig.getLanguage());
            this.settings.baseSettings().motd(wizardConfig.getMotd());
            this.settings.baseSettings().port(wizardConfig.getPort());
            this.settings.baseSettings().maxPlayers(wizardConfig.getMaxPlayers());
            this.settings.gameplaySettings().gamemode(wizardConfig.getGamemode());
            this.settings.baseSettings().allowList(wizardConfig.isWhitelistEnabled());
            this.settings.networkSettings().enableQuery(wizardConfig.isQueryEnabled());
        } else {
            this.settings.baseSettings().language(chooseLanguage);
            if (wizardConfig != null) {
                if (wizardConfig.getMotd() != null && !wizardConfig.getMotd().isEmpty()) {
                    this.settings.baseSettings().motd(wizardConfig.getMotd());
                }
                if (wizardConfig.getPort() != 19132) {
                    this.settings.baseSettings().port(wizardConfig.getPort());
                }
            }
        }
        this.settings.save();
        Chunk.setNetworkPayloadBudgetMb(this.settings.chunkSettings().payloadCacheMemoryMb());
        while (updateConfiguration()) {
            /* repeat until all configuration updates are applied */
        }

        // A minimum of 1 is enforced to prevent invalid recursion values.
        this.computeThreadPool = new ForkJoinPool(Math.min(0x7fff, Utils.backgroundPoolThreads(this.settings.levelSettings().levelThread())), new ComputeThreadPoolThreadFactory(), null, false);

        final boolean creativeInventoryEnabled = settings.gameplaySettings().enableCreativeInventory();
        final boolean recipesEnabled;
        {
            boolean recipes = settings.gameplaySettings().enableRecipes();
            if (recipes && !creativeInventoryEnabled) {
                log.warn("gameplay-settings: enableRecipes was forced to false because enableCreativeInventory is false (the recipe registry depends on the creative registry)");
                recipes = false;
            }
            recipesEnabled = recipes;
        }

        final boolean useRegistryCache = settings.performanceSettings().registryCacheEnabled()
            && creativeInventoryEnabled && recipesEnabled;
        if (settings.performanceSettings().registryCacheEnabled() && !useRegistryCache) {
            log.info("Registry cache is bypassed because the creative inventory or recipe registry is disabled by gameplay settings");
        }

        final RegistryCache registryCache;
        Path registryCachePath = Path.of(settings.performanceSettings().registryCachePath());
        {
            RegistryCache cache = null;
            if (useRegistryCache) {
                cache = RegistryCache.tryLoad(registryCachePath);
            }
            registryCache = cache;
        }

        CompletableFuture<Void> registriesF = startRegistries(registryCache, creativeInventoryEnabled, recipesEnabled);

        int chunkIoThreads = this.settings.chunkSettings().chunkIoThreads();
        if (chunkIoThreads <= 0) {
            chunkIoThreads = Math.max(2, Runtime.getRuntime().availableProcessors() / 2);
        }
        this.chunkIoExecutor = new ThreadPoolExecutor(chunkIoThreads, chunkIoThreads, 30L, TimeUnit.SECONDS,
            new LinkedBlockingQueue<>(),
            new ThreadFactoryBuilder().setNameFormat("Chunk IO #%d").setDaemon(true).build());
        this.chunkIoExecutor.allowCoreThreadTimeOut(true);
        this.loginService = new LoginService(this.settings.networkSettings());

        int levelWorkerThreads = this.settings.levelSettings().levelWorkerThreads();
        if (levelWorkerThreads <= 0) {
            // Auto-detected: two workers is the floor, one thread cannot overlap level ticks at all
            levelWorkerThreads = Math.max(2, Runtime.getRuntime().availableProcessors());
        }
        ScheduledThreadPoolExecutor levelTickPool = new ScheduledThreadPoolExecutor(
            levelWorkerThreads, r -> new Thread(r, "Level Worker"));
        levelTickPool.setRemoveOnCancelPolicy(true);
        this.levelTickExecutor = levelTickPool;

        this.chunkPublisherExecutor = new ScheduledThreadPoolExecutor(1, r -> {
            Thread thread = new Thread(r, "Chunk Publisher");
            thread.setDaemon(true);
            return thread;
        });
        this.chunkPublisherBudgetController = new ChunkPublisherBudgetController(this);

        this.levelThreadMode = this.settings.levelSettings().levelThread();

        levelArray = Level.EMPTY_ARRAY;

        org.apache.logging.log4j.Level targetLevel = org.apache.logging.log4j.Level
            .getLevel(this.settings.debugSettings().level());
        org.apache.logging.log4j.Level currentLevel = PowerNukkitX.getLogLevel();
        if (targetLevel != null && targetLevel.intLevel() > currentLevel.intLevel()) {
            PowerNukkitX.setLogLevel(targetLevel);
        }

        if (!StartArgUtils.loadModules()) {
            log.error(getLanguage().tr("nukkit.start.invalid"));
            return;
        }

        this.checkLoginTime = this.settings.networkSettings().checkLoginTime();

        log.info(this.getLanguage().tr("language.selected", getLanguage().getName(), getLanguage().getLang()));
        log.info(getLanguage().tr("nukkit.server.start", TextFormat.AQUA + this.getVersion() + TextFormat.RESET));

        String poolSize = settings.performanceSettings().asyncWorkers();
        int poolSizeNumber;
        try {
            poolSizeNumber = Integer.parseInt(poolSize);
        } catch (Exception e) {
            poolSizeNumber = Math.max(Runtime.getRuntime().availableProcessors(), 4);
        }
        ServerScheduler.WORKERS = poolSizeNumber;
        this.scheduler = new ServerScheduler();

        this.experiments = new ArrayList<>();
        for (String experiment : settings.gameplaySettings().experiments())
            experiments.add(new ExperimentToggle(experiment, true));

        this.entityMetadata = new EntityMetadataStore();
        this.playerMetadata = new PlayerMetadataStore();
        this.levelMetadata = new LevelMetadataStore();
        this.operators = new Config(this.dataPath + "ops.txt", Config.ENUM);
        this.whitelist = new Config(this.dataPath + "white-list.txt", Config.ENUM);

        if (wizardConfig != null && !config.exists()) {
            for (String player : wizardConfig.getWhitelistedPlayers()) {
                this.whitelist.set(player, true);
            }
            this.whitelist.save();

            for (String op : wizardConfig.getOperators()) {
                this.operators.set(op, true);
            }
            this.operators.save();
        }

        this.banByName = new BanList(this.dataPath + "banned-players.json");
        this.banByName.load();
        this.banByIP = new BanList(this.dataPath + "banned-ips.json");
        this.banByIP.load();
        this.maxPlayers = this.settings.baseSettings().maxPlayers();
        this.setAutoSave(this.settings.baseSettings().autoSave());
        if (this.settings.gameplaySettings().hardcore() && this.getDifficulty() < 3) {
            this.settings.gameplaySettings().difficulty(3);
        }

        log.info(this.getLanguage().tr(
            "nukkit.server.info", this.getName(), TextFormat.YELLOW + this.getNukkitVersion() + TextFormat.RESET
                + " (" + TextFormat.YELLOW + this.getGitCommit() + TextFormat.RESET + ")" + TextFormat.RESET,
            this.getApiVersion()));
        log.info(this.getLanguage().tr("nukkit.server.license"));
        this.consoleSender = new ConsoleCommandSender();

        // Initialize metrics
        if (this.settings.miscSettings().enableMetrics()) {
            CompletableFuture.runAsync(NukkitMetrics::startNow, computeThreadPool);
        }

        try {
            migrationService.migrateStructures();
        } catch (IOException e) {
            throw new IllegalStateException("Failed to migrate structure storage", e);
        }

        registriesF.join();
        if (useRegistryCache && registryCache == null) {
            RegistryCache.save(registryCachePath);
        }

        if (settings.gameplaySettings().enableEducation()) Education.enable();

        freezableArrayManager = new FreezableArrayManager(
            this.settings.performanceSettings().enable(),
            this.settings.performanceSettings().slots(),
            this.settings.performanceSettings().defaultTemperature(),
            this.settings.performanceSettings().freezingPoint(),
            this.settings.performanceSettings().absoluteZero(),
            this.settings.performanceSettings().boilingPoint(),
            this.settings.performanceSettings().melting(),
            this.settings.performanceSettings().singleOperation(),
            this.settings.performanceSettings().batchOperation());
        functionManager = new FunctionManager(commandDataPath + "/functions");
        tickingAreaManager = new SimpleTickingAreaManager(new LevelDBTickingAreaStorage(this));

        try {
            serverDataDB = Iq80DBFactory.factory.open(serverData, new Options()
                .createIfMissing(true)
                .compressionType(CompressionType.ZLIB_RAW));

            if (serverDataDB.get(ServerDBStorageFormat.SERVER_DATA_STORAGE_VERSION_KEY) == null) {
                serverDataDB.put(
                    ServerDBStorageFormat.SERVER_DATA_STORAGE_VERSION_KEY,
                    ServerDBStorageFormat.SERVER_DATA_INITIAL_VERSION.getBytes(StandardCharsets.UTF_8)
                );
            }

            String configuredDPGroupUUID = settings.miscSettings().defaultDynamicPropertiesGroupUUID();
            configuredDPGroupUUID = configuredDPGroupUUID == null ? "" : configuredDPGroupUUID.trim();
            if (!configuredDPGroupUUID.isEmpty()) {
                try {
                    configuredDPGroupUUID = UUID.fromString(configuredDPGroupUUID).toString();
                } catch (IllegalArgumentException e) {
                    throw new IllegalStateException("Invalid misc-settings.defaultDynamicPropertiesGroupUUID", e);
                }
            }

            byte[] dynamicPropertiesUUID = serverDataDB.get(ServerDBStorageFormat.SERVER_DATA_DYNAMIC_PROPERTIES_UUID_KEY);
            String persistedDPGroupUUID = dynamicPropertiesUUID == null ? null
                : UUID.fromString(new String(dynamicPropertiesUUID, StandardCharsets.UTF_8)).toString();

            initializeDefaultDynamicPropertiesGroupUUID(configuredDPGroupUUID, persistedDPGroupUUID);

            if (!DP_DEFAULT_GROUP_UUID.equals(persistedDPGroupUUID)) {
                if (persistedDPGroupUUID != null) {
                    log.warn("Overriding persisted Dynamic Properties UUID '{}' with configured UUID '{}'",
                        persistedDPGroupUUID, DP_DEFAULT_GROUP_UUID);
                }
                serverDataDB.put(ServerDBStorageFormat.SERVER_DATA_DYNAMIC_PROPERTIES_UUID_KEY,
                    DP_DEFAULT_GROUP_UUID.getBytes(StandardCharsets.UTF_8));
            }

            dynamicProperties = new DynamicProperties(this::readServerDynamicProperties, this::writeServerDynamicProperties);
            actorUniqueIdManager = new ActorUniqueIdManager(serverDataDB);

            migrationService.migrateLegacyPositionTracking(
                Path.of(this.dataPath, "services", "position_tracking_db"),
                serverDataDB
            );

            if (players.exists()) {
                try (DB legacyPlayerDB = Iq80DBFactory.factory.open(players, new Options()
                    .createIfMissing(false)
                    .compressionType(CompressionType.ZLIB_RAW))) {
                    migrationService.migratePlayers(legacyPlayerDB, serverDataDB, actorUniqueIdManager::assignPlayer);
                }

                FileUtils.deleteDirectory(players);
                log.info("[PlayerData Migration] Deleted legacy player storage");
            } else {
                migrationService.migratePlayers(null, serverDataDB, actorUniqueIdManager::assignPlayer);
            }

            migrationService.migrateScoreboard(serverDataDB);
        } catch (IOException e) {
            log.error("Failed to initialize or migrate server data storage", e);
            System.exit(1);
        }

        scoreboardManager = new ScoreboardManager(new LevelDBScoreboardStorage(serverDataDB));
        this.resourcePackManager = new ResourcePackManager(
            new ZippedResourcePackLoader(new File(PowerNukkitX.DATA_PATH, "resource_packs")),
            new JarPluginResourcePackLoader(new File(this.pluginPath)),
            new CdnResourcePackLoader(this.settings.gameplaySettings()));

        this.commandMap = new SimpleCommandMap(this);
        this.pluginManager = new PluginManager(this, this.commandMap);
        this.pluginManager.subscribeToPermission(Server.BROADCAST_CHANNEL_ADMINISTRATIVE, this.consoleSender);
        this.pluginManager.registerInterface(JavaPluginLoader.class);
        this.console.setExecutingCommands(true);

        log.debug("Loading position tracking service");
        this.positionTrackingService = new PositionTrackingService(serverDataDB);

        this.pluginManager.loadInternalPlugin();

        this.serverID = UUID.randomUUID();
        this.pluginManager.loadPlugins(this.pluginPath);

        {// trim
            Registries.POTION.trim();
            Registries.ENTITY.trim();
            Registries.BLOCKENTITY.trim();
            Registries.BLOCKSTATE.trim();
            Registries.ITEM_RUNTIMEID.trim();
            Registries.BLOCK.trim();
            Registries.ITEM.trim();
            Registries.CREATIVE.trim();
            Registries.BIOME.trim();
            Registries.FUEL.trim();
            Registries.GENERATOR.trim();
            Registries.POPULATOR.trim();
            Registries.GENERATE_STAGE.trim();
            Registries.STRUCTURE.trim();
            Registries.EFFECT.trim();
            Registries.RECIPE.trim();
            Registries.VOXEL_SHAPE.trim();
        }

        this.enablePlugins(PluginLoadOrder.STARTUP);

        LevelProviderManager.addProvider("leveldb", LevelDBProvider.class);

        BlockLightProperties.build();

        try {
            boolean scoreboardMigrated = this.migrationService.migrateWorlds(
                this.serverDataDB,
                this.actorUniqueIdManager::assignPlayer
            );

            if (scoreboardMigrated) {
                this.scoreboardManager.read();
            }
        } catch (IOException e) {
            throw new IllegalStateException("Failed to complete world storage migrations", e);
        }

        loadLevels();

        this.queryRegenerateEvent = new QueryRegenerateEvent(this, 5);
        this.getTickingAreaManager().loadAllTickingArea();

        if (this.getDefaultLevel() == null) {
            log.error(this.getLanguage().tr("nukkit.level.defaultError"));
            this.forceShutdown();

            return;
        }

        this.autoSaveTicks = settings.baseSettings().autosaveDelay();

        this.enablePlugins(PluginLoadOrder.POSTWORLD);

        NetworkRegisterEvent networkRegisterEvent = new NetworkRegisterEvent(new Network(this));
        this.pluginManager.callEvent(networkRegisterEvent);

        NetworkInterface networkInterface = networkRegisterEvent.getNetworkInterface();

        this.getLogger().debug("Registering network interface: " + networkInterface.getClass().getCanonicalName());
        this.network = networkInterface;

        EntityProperty.buildEntityProperty();
        EntityProperty.buildPlayerProperty();

        if (settings.gameplaySettings().enableEducation()) Education.registerCreative();

        CreativeGroupsRegistry.register();

        if (settings.miscSettings().installSpark()) {
            SparkInstaller.initSpark(this);
        }

        if (!Boolean.parseBoolean(System.getProperty("disableWatchdog", "false"))) {
            this.watchdog = new Watchdog(this, 60000);// 60s
            this.watchdog.start();
        }
        Runtime.getRuntime().addShutdownHook(new Thread(this::shutdown));
        this.start();
    }

    private CompletableFuture<Void> startRegistries(RegistryCache registryCache, boolean creativeInventoryEnabled, boolean recipesEnabled) {
        CompletableFuture<Void> blockF = CompletableFuture.runAsync(Registries.BLOCK::init, computeThreadPool);
        CompletableFuture<Void> potionF = CompletableFuture.runAsync(Registries.POTION::init, computeThreadPool);
        CompletableFuture<Void> effectF = CompletableFuture.runAsync(Registries.EFFECT::init, computeThreadPool);
        CompletableFuture<Void> itemF = CompletableFuture.allOf(potionF, effectF)
            .thenRunAsync(Registries.ITEM::init, computeThreadPool);

        CompletableFuture<Void> entityF = CompletableFuture.runAsync(Registries.ENTITY::init, computeThreadPool);
        CompletableFuture<Void> blockEntityF = CompletableFuture.runAsync(Registries.BLOCKENTITY::init, computeThreadPool);
        CompletableFuture<Void> itemRtIdF = CompletableFuture.runAsync(registryCache != null
                ? () -> registryCache.restoreItemRuntimeId(Registries.ITEM_RUNTIMEID)
                : Registries.ITEM_RUNTIMEID::init,
            computeThreadPool);
        CompletableFuture<Void> biomeF = CompletableFuture.runAsync(registryCache != null
                ? () -> registryCache.restoreBiome(Registries.BIOME)
                : Registries.BIOME::init,
            computeThreadPool);
        CompletableFuture<Void> fuelF = CompletableFuture.runAsync(Registries.FUEL::init, computeThreadPool);
        CompletableFuture<Void> generatorF = CompletableFuture.runAsync(Registries.GENERATOR::init, computeThreadPool);
        CompletableFuture<Void> genStageF = CompletableFuture.runAsync(Registries.GENERATE_STAGE::init, computeThreadPool);
        CompletableFuture<Void> populatorF = CompletableFuture.runAsync(Registries.POPULATOR::init, computeThreadPool);
        CompletableFuture<Void> genFeatF = CompletableFuture.runAsync(Registries.GENERATE_FEATURE::init, computeThreadPool);
        CompletableFuture<Void> structureSpawnOverrideF = CompletableFuture.runAsync(Registries.STRUCTURE_SPAWN_OVERRIDE::init, computeThreadPool);
        CompletableFuture<Void> voxelF = CompletableFuture.runAsync(Registries.VOXEL_SHAPE::init, computeThreadPool);
        CompletableFuture<Void> disconnectF = CompletableFuture.runAsync(Registries.DISCONNECT_REASON::init, computeThreadPool);
        CompletableFuture<Void> trimF = CompletableFuture.runAsync(Registries.TRIM::init, computeThreadPool);

        CompletableFuture<Void> blockStateF = blockF.thenRunAsync(registryCache != null
                ? registryCache::restoreBlockStateColors
                : Registries.BLOCKSTATE::init,
            computeThreadPool);
        CompletableFuture<Void> structureF = blockF.thenRunAsync(Registries.STRUCTURE::init, computeThreadPool);
        CompletableFuture<Void> creativeF = creativeInventoryEnabled
            ? CompletableFuture.allOf(itemF, blockStateF, potionF, entityF, itemRtIdF)
            .thenRunAsync(registryCache != null
                          ? () -> registryCache.restoreCreative(Registries.CREATIVE)
                          : Registries.CREATIVE::init,
                computeThreadPool)
            : CompletableFuture.runAsync(Registries.CREATIVE::initDisabled, computeThreadPool);
        CompletableFuture<Void> recipeF = recipesEnabled
            ? creativeF.thenRunAsync(registryCache != null
                                     ? () -> Registries.RECIPE.init(registryCache.getRecipePktBytes())
                                     : Registries.RECIPE::init,
            computeThreadPool)
            : CompletableFuture.runAsync(Registries.RECIPE::initDisabled, computeThreadPool);

        CompletableFuture<Void> miscF = CompletableFuture.runAsync(() -> {
            Profession.init();
            Updater updater = BlockStateUpdaterBase.INSTANCE;
            Enchantment.init();
            Attribute.init();
        }, computeThreadPool);

        CompletableFuture<Void> dispenseF = CompletableFuture.allOf(blockF, itemF)
            .thenRunAsync(() -> {
                BlockComposter.init();
                DispenseBehaviorRegister.init();
            }, computeThreadPool);

        return CompletableFuture.allOf(potionF, entityF, blockEntityF, itemRtIdF, biomeF,
            fuelF, generatorF, genStageF, populatorF, genFeatF, structureF, structureSpawnOverrideF, effectF,
            creativeF, recipeF, voxelF, disconnectF, trimF, miscF, dispenseF);
    }


    private boolean convertLegacyConfiguration() {
        File oldNukkitYml = new File(this.dataPath + "nukkit.yml");
        File oldServerProperties = new File(this.dataPath + "server.properties");
        if (oldNukkitYml.exists() && oldServerProperties.exists()) {
            try {
                File backupFolder = new File(this.dataPath + "backup/");
                if (!backupFolder.exists()) {
                    backupFolder.mkdirs();
                }
                FileUtils.copyFile(oldNukkitYml, new File(backupFolder, "nukkit.yml"));
                FileUtils.copyFile(oldServerProperties, new File(backupFolder, "server.properties"));
                log.info("Copied nukkit.yml and server.properties to backup folder");
                log.info("Start migration now...");

                ConfigUpdater.update("1.0.0", this);

                oldNukkitYml.delete();
                oldServerProperties.delete();

                log.info("Migration completed, start server now...");
            } catch (IOException e) {
                log.error("Failed to copy nukkit.yml to server.properties", e);
            }
            return true;
        }
        return false;
    }

    private boolean updateConfiguration() {
        if (ConfigUpdater.canUpdate(this.settings.configSettings().version())) {
            log.info("New version detected, updating config...");
            ConfigUpdater.update(this.settings.configSettings().version(), this);
            log.info("Config updated to version {}", this.settings.configSettings().version());
            return true;
        }

        return false;
    }

    private void loadLevels() {
        File file = new File(this.getDataPath() + "/worlds");
        Preconditions.checkState(file.isDirectory(), "worlds isn't directory");

        if (this.settings.levelSettings().loadAllLevels()) {
            // load all levels from `worlds` folder
            for (var f : Objects.requireNonNull(file.listFiles(File::isDirectory))) {
                LevelConfig levelConfig = getLevelConfig(f.getName());
                if (levelConfig != null && !levelConfig.enable()) {
                    continue;
                }

                if (!this.loadLevel(f.getName())) {
                    this.generateLevel(f.getName(), null);
                }
            }
        }

        if (this.getDefaultLevel() == null) {
            String levelFolder = this.settings.baseSettings().defaultLevelName();
            if (levelFolder == null || levelFolder.trim().isEmpty()) {
                log.warn("level-name cannot be null, using default");
                levelFolder = "world";
                this.settings.baseSettings().defaultLevelName(levelFolder);
            }

            if (!this.loadLevel(levelFolder)) {
                // default world doesn't exist
                // generate the default world
                HashMap<Integer, LevelConfig.GeneratorConfig> generatorConfig = new HashMap<>();
                long seed = LevelConfig.GeneratorConfig.randomSeed();
                generatorConfig.put(0,
                    new LevelConfig.GeneratorConfig("normal", seed, false, LevelConfig.AntiXrayMode.LOW, true,
                        DimensionEnum.OVERWORLD.getDimensionData(), Collections.emptyMap()));
                generatorConfig.put(1,
                    new LevelConfig.GeneratorConfig("nether", seed, false, LevelConfig.AntiXrayMode.LOW, true,
                        DimensionEnum.NETHER.getDimensionData(), Collections.emptyMap()));
                generatorConfig.put(2,
                    new LevelConfig.GeneratorConfig("the_end", seed, false, LevelConfig.AntiXrayMode.LOW, true,
                        DimensionEnum.THE_END.getDimensionData(), Collections.emptyMap()));
                LevelConfig levelConfig = new LevelConfig("leveldb", true, generatorConfig);
                this.generateLevel(levelFolder, levelConfig);
            }
            this.setDefaultLevel(this.getLevelByName(levelFolder));
        }
    }

    // region lifecycle and ticking

    /**
     * Reloads the server
     */
    public void reload() {
        ServerReloadEvent serverReloadEvent = new ServerReloadEvent();
        getPluginManager().callEvent(serverReloadEvent);

        if (serverReloadEvent.isCancelled())
            return;

        // Set network to starting to prevent new players from joining during the reload
        // process
        this.network.setState(NetworkState.STARTING);

        log.info("Reloading server...");
        log.info("Saving levels...");

        for (Level level : this.levelArray) {
            level.save();
        }

        this.scoreboardManager.save();
        this.pluginManager.disablePlugins();
        this.pluginManager.clearPlugins();
        this.commandMap.clearCommands();

        this.banByIP.load();
        this.banByName.load();
        this.reloadWhitelist();
        this.operators.reload();

        for (BanEntry entry : this.getIPBans().getEntires().values()) {
            try {
                this.getNetwork().blockAddress(InetAddress.getByName(entry.getName()), -1);
            } catch (UnknownHostException e) {
                // ignore
            }
        }

        this.pluginManager.registerInterface(JavaPluginLoader.class);
        this.scoreboardManager.read();

        log.info("Reloading registries...");
        {
            Registries.POTION.reload();
            Registries.ENTITY.reload();
            Registries.BLOCKENTITY.reload();
            Registries.BLOCKSTATE.reload();
            Registries.ITEM_RUNTIMEID.reload();
            Registries.BLOCK.reload();
            Registries.ITEM.reload();
            Registries.CREATIVE.reload();
            Registries.BIOME.reload();
            Registries.FUEL.reload();
            Registries.GENERATOR.reload();
            Registries.GENERATE_STAGE.reload();
            Registries.POPULATOR.reload();
            Registries.GENERATE_FEATURE.reload();
            Registries.STRUCTURE.reload();
            Registries.EFFECT.reload();
            Registries.RECIPE.reload();
            Enchantment.reload();
        }

        this.pluginManager.loadPlugins(this.pluginPath);
        this.functionManager.reload();

        this.enablePlugins(PluginLoadOrder.STARTUP);
        {
            Registries.POTION.trim();
            Registries.ENTITY.trim();
            Registries.BLOCKENTITY.trim();
            Registries.BLOCKSTATE.trim();
            Registries.ITEM_RUNTIMEID.trim();
            Registries.BLOCK.trim();
            Registries.ITEM.trim();
            Registries.CREATIVE.trim();
            Registries.BIOME.trim();
            Registries.FUEL.trim();
            Registries.GENERATOR.trim();
            Registries.GENERATE_STAGE.trim();
            Registries.EFFECT.trim();
            Registries.RECIPE.trim();
        }
        this.enablePlugins(PluginLoadOrder.POSTWORLD);
        CreativeGroupsRegistry.register();
        this.warmLoginPackets();
        this.network.setState(NetworkState.STARTED);
    }

    /**
     * Encodes the login packets that are the same for every player in the background, once the
     * plugins are enabled and the registries complete, see {@link PlayerSessionHolder#warmEncodedPackets()}.
     */
    private void warmLoginPackets() {
        CompletableFuture.runAsync(PlayerSessionHolder::warmEncodedPackets, this.computeThreadPool);
    }

    /**
     * Shutdown the server
     */
    public void shutdown() {
        this.beforeStop();

        network.setState(NetworkState.STOPPING);
        isRunning.compareAndSet(true, false);
    }

    /**
     * Force shutdown the server
     */
    public void forceShutdown() {
        if (this.hasStopped) {
            return;
        }

        try {
            log.debug("BeforeStop");
            this.beforeStop();
        } catch (Throwable e) {
            log.error("Exception while beforestop", e);
        }

        network.setState(NetworkState.STOPPING);
        isRunning.compareAndSet(true, false);

        this.hasStopped = true;

        try {
            ServerStopEvent serverStopEvent = new ServerStopEvent();
            getPluginManager().callEvent(serverStopEvent);
        } catch (Throwable e) {
            log.error("Exception while calling ServerStopEvent", e);
        }

        for (Player player : new ArrayList<>(this.players.values())) {
            try {
                player.close(player.getLeaveMessage(), getSettings().miscSettings().shutdownMessage());
            } catch (Throwable e) {
                log.error("Exception while kicking player on shutdown", e);
            }
        }

        try {
            log.debug("Disabling all plugins");
            this.pluginManager.disablePlugins();
        } catch (Throwable e) {
            log.error("Exception while disabling plugins", e);
        }

        try {
            log.debug("Removing event handlers");
            HandlerList.unregisterAll();
        } catch (Throwable e) {
            log.error("Exception while removing event handlers", e);
        }

        try {
            log.debug("Saving scoreboards data");
            this.scoreboardManager.save();
        } catch (Throwable e) {
            log.error("Exception while saving scoreboards", e);
        }

        try {
            log.debug("Stopping all tasks");
            this.scheduler.cancelAllTasks();
            this.scheduler.mainThreadHeartbeat((int) (this.getNextTick() + 10000));
        } catch (Throwable e) {
            log.error("Exception while stopping tasks", e);
        }

        log.debug("Unloading all levels");
        //Chunks may still generate. Waiting for all generation tasks to complete
        try {
            while (!this.getComputeThreadPool().isQuiescent()) Thread.sleep(1);
        } catch (Throwable e) {
            log.error("Exception while waiting for generation tasks", e);
        }
        for (Level level : this.levelArray) {
            try {
                this.unloadLevel(level, true);
                //Waiting for level to complete its last tick
                while (level.isThreadRunning()) Thread.sleep(1);
            } catch (Throwable e) {
                log.error("Exception while unloading/saving level {}", level.getName(), e);
            }
        }

        try {
            if (positionTrackingService != null) {
                log.debug("Closing position tracking service");
                positionTrackingService.close();
            }
        } catch (Throwable e) {
            log.error("Exception while closing position tracking service", e);
        }

        try {
            this.levelTickExecutor.shutdown();
            this.chunkPublisherExecutor.shutdown();
            this.chunkIoExecutor.shutdown();
            this.chunkPublisherBudgetController.shutdown();
        } catch (Throwable e) {
            log.error("Exception while shutting down level tick executors", e);
        }

        try {
            log.debug("Closing console");
            this.consoleThread.interrupt();
        } catch (Throwable e) {
            log.error("Exception while closing console", e);
        }

        try {
            log.debug("Stopping network interfaces");
            network.shutdown();
            // Player saves are written on the login service, so they have to land before the database closes
            this.loginService.shutdown();
            serverDataDB.close();
        } catch (Throwable e) {
            log.error("Exception while stopping network interfaces", e);
        }

        try {
            // Close watchdog and metrics
            if (this.watchdog != null) {
                this.watchdog.running = false;
            }
        } catch (Throwable e) {
            log.error("Exception while closing watchdog", e);
        }

        try {
            // Close thread pool
            try (ForkJoinPool pool = ForkJoinPool.commonPool()) {
                pool.shutdownNow();
            }
            this.computeThreadPool.shutdownNow();
        } catch (Throwable e) {
            log.error("Exception while closing thread pools", e);
        }
        NukkitMetrics.closeNow();
        // TODO: Other things
    }

    private void beforeStop() {
        if (this.hasBeforeStopped.compareAndSet(false, true)) {
            this.pluginManager.beforeStopPlugins();
        }
    }

    public void start() {
        this.loginService.warmUp();
        this.warmLoginPackets();
        for (BanEntry entry : this.getIPBans().getEntires().values()) {
            try {
                this.network.blockAddress(InetAddress.getByName(entry.getName()));
            } catch (UnknownHostException ignore) {
            }
        }
        this.tickCounter = 0;

        log.info(this.getLanguage().tr("nukkit.server.defaultGameMode", getGamemodeString(this.getGamemode())));
        log.info(this.getLanguage().tr("nukkit.server.networkStart",
            TextFormat.YELLOW + (this.getIp().isEmpty() ? "*" : this.getIp()),
            TextFormat.YELLOW + String.valueOf(this.getPort())));
        log.info(this.getLanguage().tr("nukkit.server.startFinished",
            String.valueOf((double) (System.currentTimeMillis() - PowerNukkitX.START_TIME) / 1000)));

        ServerStartedEvent serverStartedEvent = new ServerStartedEvent();
        getPluginManager().callEvent(serverStartedEvent);

        this.network.setState(NetworkState.STARTED);
        this.network.updatePong(this.network.getPong());

        this.chunkPublisherExecutor.scheduleWithFixedDelay(() -> {
            for (Player player : this.players.values()) {
                try {
                    if (player.isOnline()) {
                        player.getPlayerChunkManager().tickPublisher();
                    }
                } catch (Throwable t) {
                    log.error("Failed to update chunk publisher for player {}", player.getName(), t);
                }
            }
        }, 0, 50, TimeUnit.MILLISECONDS);

        this.tickProcessor();
        this.forceShutdown();
    }

    public void tickProcessor() {
        getScheduler().scheduleDelayedTask(InternalPlugin.INSTANCE, new Task() {
            @Override
            public void onRun(int currentTick) {
                System.gc();
            }
        }, 60);

        this.nextTick = System.currentTimeMillis();
        this.nextTickNanos = System.nanoTime();
        try {
            while (this.isRunning.get()) {
                try {
                    this.tick();

                    long nanosPerTick = getNanosPerTick();
                    if (this.levelThreadMode || nanosPerTick < GameLoop.SPIN_ACTIVATION_NANOS) {
                        GameLoop.waitUntilNanos(this.nextTickNanos,
                            nanosPerTick < GameLoop.SPIN_ACTIVATION_NANOS ? GameLoop.SPIN_MARGIN_NANOS : 0L);
                    } else {
                        this.waitHandlingInbound(this.nextTickNanos);
                    }
                } catch (RuntimeException e) {
                    log.error("A RuntimeException happened while ticking the server", e);
                }
            }
        } catch (Throwable e) {
            log.error("Exception happened while ticking server\n{}", Utils.getAllThreadDumps(), e);
        }
    }

    private void checkTickUpdates(int currentTick) {
        boolean tickPlayers = !this.levelThreadMode && getSettings().levelSettings().alwaysTickPlayers();
        for (Player player : this.players.values()) {
            if (tickPlayers) player.onUpdate(currentTick);
            player.checkNetwork();
        }

        int baseTickRate = getSettings().levelSettings().baseTickRate();
        //Do level ticks if level threading is disabled
        if (!this.levelThreadMode) {
            for (Level level : this.levelArray) {
                if (level.getTickRate() > baseTickRate && --level.tickRateCounter > 0) {
                    for (Player player : level.getPlayers().values()) {
                        try {
                            if (!tickPlayers && player.spawned) player.onUpdate(currentTick);
                        } catch (Exception e) {
                            log.error(this.getLanguage().tr("nukkit.level.tickError",
                                level.getFolderPath(), Utils.getExceptionMessage(e)), e);
                        }
                    }
                    level.releaseTickCachedBlocks();
                    continue;
                }

                try {
                    // Ensures that the server won't try to tick a level without providers.
                    if (level.getProvider().getLevel() == null) {
                        log.warn("Tried to tick Level {} without a provider!", level.getName());
                        continue;
                    }
                    level.tickAndAdjustTickRate(currentTick);
                } catch (Exception e) {
                    log.error(this.getLanguage().tr("nukkit.level.tickError",
                        level.getFolderPath(), Utils.getExceptionMessage(e)), e);
                    e.printStackTrace();
                }
            }
        }
    }

    /**
     * Waits for the next tick, handling inbound packets of spawned players as they arrive. Without
     * it a packet that arrives just after a player was ticked waits for the whole idle part of the
     * tick before anything reacts to it.
     * <p>
     * Only used when levels tick on this thread: the packets are handled on the thread that would
     * otherwise handle them at the start of the player's next update, in the same order. The
     * network threads wake this thread through {@link #onInboundQueued(Player)}; what arrived
     * during the tick, after the player's update, is handled right at the start of the wait.
     */
    private void waitHandlingInbound(long deadlineNanos) {
        this.waitingForTick = true;
        try {
            for (Player player : this.players.values()) {
                if (deadlineNanos - System.nanoTime() <= 0) {
                    return;
                }
                this.handleInboundNow(player);
            }
            long remaining;
            while (deadlineNanos - System.nanoTime() > 0) {
                Player player;
                while (deadlineNanos - System.nanoTime() > 0 && (player = this.idleInbound.poll()) != null) {
                    player.releaseInboundSignal();
                    this.handleInboundNow(player);
                }
                remaining = deadlineNanos - System.nanoTime();
                if (remaining <= 0) {
                    return;
                }
                LockSupport.parkNanos(remaining);
                if (Thread.currentThread().isInterrupted()) {
                    return;
                }
            }
        } finally {
            this.waitingForTick = false;
        }
    }

    /**
     * Handles what a spawned player has queued and writes the replies right away, so they do not
     * wait for the next tick's flush.
     */
    private void handleInboundNow(Player player) {
        if (!player.spawned || player.inboundPackets.isEmpty()) {
            return;
        }
        player.drainInboundPackets();
        player.flushOutbound();
    }

    /**
     * Called on a network thread after a packet was queued for {@code player}, see
     * {@link #waitHandlingInbound(long)}. Does nothing while the tick runs, which handles the
     * packet itself.
     */
    void onInboundQueued(Player player) {
        if (this.waitingForTick && player.claimInboundSignal()) {
            if (this.idleInbound.offer(player)) {
                LockSupport.unpark(this.currentThread);
            } else {
                player.releaseInboundSignal();
            }
        }
    }

    /**
     * Writes what the tick queued for every player right away instead of on the next session
     * timer, see {@link FlushablePeer}. With level threads each level flushes its own players when
     * its tick ends instead, since a flush from here would split a level's tick across batches.
     */
    private void flushPlayerSessions() {
        if (this.levelThreadMode) {
            return;
        }
        for (Player player : this.players.values()) {
            player.flushOutbound();
        }
    }

    public void doAutoSave() {
        if (this.getAutoSave()) {
            for (Player player : new ArrayList<>(this.players.values())) {
                if (player.isOnline()) {
                    if (!player.closed) {
                        try {
                            player.save(true);
                        } catch (IllegalStateException ignored) {
                        }
                    }
                } else if (!player.isConnected()) {
                    this.removePlayer(player);
                }
            }

            for (Level level : this.levelArray) {
                level.save();
            }
            this.getScoreboardManager().save();
        }
    }

    public int getBaseTps() {
        return NukkitMath.clamp(getSettings().performanceSettings().baseTps(), 1, 1_000_000);
    }

    /**
     * @deprecated millisecond resolution cannot represent tick periods above 1000 TPS;
     * use {@link #getNanosPerTick()} instead. Floored at 1 ms for backwards compatibility.
     */
    @Deprecated
    public int getBaseMSPT() {
        return (int) Math.max(1, getNanosPerTick() / 1_000_000L);
    }

    public long getNanosPerTick() {
        return 1_000_000_000L / getBaseTps();
    }

    private void tick() {
        long tickTime = System.currentTimeMillis();
        long tickTimeNano = System.nanoTime();

        ++this.tickCounter;
        this.network.processInterfaces();

        this.getScheduler().mainThreadHeartbeat((int) this.tickCounter);

        this.checkTickUpdates((int) this.tickCounter);
        this.flushPlayerSessions();

        if (tickTime - this.lastTitleTickMillis >= 800) {
            this.lastTitleTickMillis = tickTime;
            this.titleTick();
            this.maxTick = getBaseTps();
            this.maxUse = 0;

            if (tickTime - this.lastQueryRegenMillis >= 25_600) {
                this.lastQueryRegenMillis = tickTime;
                try {
                    this.getPluginManager().callEvent(this.queryRegenerateEvent = new QueryRegenerateEvent(this, 5));
                } catch (Exception e) {
                    log.error("", e);
                }
            }
        }

        if (this.autoSave && tickTime - this.lastAutoSaveMillis >= this.autoSaveTicks * 50L) {
            this.lastAutoSaveMillis = tickTime;
            for (Level level : this.levelArray) {
                LevelProvider levelProvider = level.getProvider();
                if (levelProvider == null) {
                    continue;
                }

                for (IChunk chunk : levelProvider.getLoadedChunks().values()) {
                    if (!chunk.hasChanged()) {
                        continue;
                    }
                    for (BlockEntity be : chunk.getBlockEntities().values()) {
                        if (!be.closed) {
                            be.saveNBT();
                            be.serializationSnapshot = be.getNbt().copy();
                        }
                    }
                    for (Entity entity : chunk.getEntities().values()) {
                        if (!(entity instanceof Player) && !entity.closed) {
                            entity.saveNBT();
                            entity.serializationSnapshot = entity.getNbt().copy();
                        }
                    }
                }
            }
            CompletableFuture.runAsync(this::doAutoSave);
        }

        if (this.sendUsageTicker > 0 && --this.sendUsageTicker == 0) {
            this.sendUsageTicker = 6000;
            // TODO: sendUsage
        }

        long nanosPerTick = getNanosPerTick();

        int freezableArrayCompressTime = (int) ((nanosPerTick - (System.nanoTime() - tickTimeNano)) / 1_000_000L);
        getFreezableArrayManager().setMaxCompressionTime(Math.max(0, freezableArrayCompressTime)).tick();

        long nowNano = System.nanoTime();
        this.tickDurationsNanos[(int) (this.tickCounter & (this.tickDurationsNanos.length - 1))] = nowNano - tickTimeNano;
        float tick = (float) Math.min(getBaseTps(), 1_000_000_000d / Math.max(1, (double) nowNano - tickTimeNano));
        float use = (float) Math.min(1, ((double) (nowNano - tickTimeNano)) / nanosPerTick);

        if (this.maxTick > tick) {
            this.maxTick = tick;
        }

        if (this.maxUse < use) {
            this.maxUse = use;
        }

        System.arraycopy(this.tickAverage, 1, this.tickAverage, 0, this.tickAverage.length - 1);
        this.tickAverage[this.tickAverage.length - 1] = tick;

        System.arraycopy(this.useAverage, 1, this.useAverage, 0, this.useAverage.length - 1);
        this.useAverage[this.useAverage.length - 1] = use;

        if (nowNano - this.nextTickNanos > GameLoop.CATCHUP_RESET_NANOS) {
            this.nextTickNanos = nowNano;
        } else {
            this.nextTickNanos += nanosPerTick;
        }
        this.nextTick = tickTime;
    }

    public long getNextTick() {
        return nextTick;
    }

    /**
     * @return Returns the number of ticks recorded by the server. Wraps after 2^31 ticks —
     * reachable within hours at high tick rates; prefer {@link #getTickLong()}.
     */
    public int getTick() {
        return (int) tickCounter;
    }

    /**
     * @return Returns the number of ticks recorded by the server, without int wraparound
     */
    public long getTickLong() {
        return tickCounter;
    }

    /**
     * Snapshot of the most recent per-tick durations in nanoseconds (unordered; zero
     * entries mean the buffer hasn't filled yet). For diagnostics such as /debug mspt.
     */
    public long[] getTickDurationsNanos() {
        return tickDurationsNanos.clone();
    }

    public float getTicksPerSecond() {
        return getTicksPerSecondAverage();
    }

    public float getMaxTicksPerSecond() {
        return ((float) Math.round(this.maxTick * 100)) / 100;
    }

    public float getTicksPerSecondAverage() {
        float sum = 0;
        int count = this.tickAverage.length;
        for (float aTickAverage : this.tickAverage) {
            sum += aTickAverage;
        }
        return (float) NukkitMath.round(sum / count, 2);
    }

    public float getTickUsage() {
        return (float) NukkitMath.round(this.maxUse * 100, 2);
    }

    public float getTickUsageAverage() {
        float sum = 0;
        int count = this.useAverage.length;
        for (float aUseAverage : this.useAverage) {
            sum += aUseAverage;
        }
        return ((float) Math.round(sum / count * 100)) / 100;
    }

    public String getCPULoad() {
        double load = this.chunkPublisherBudgetController.getSampledProcessCpuLoad();
        if (load >= 0) {
            return String.format("%.1f%%", load * 100);
        }
        return "N/A";
    }

    // TODO: Fix title tick
    public void titleTick() {
        if (!PowerNukkitX.ANSI || !PowerNukkitX.TITLE) {
            return;
        }

        Runtime runtime = Runtime.getRuntime();
        double used = NukkitMath.round((double) (runtime.totalMemory() - runtime.freeMemory()) / 1024 / 1024, 2);
        double max = NukkitMath.round(((double) runtime.maxMemory()) / 1024 / 1024, 2);
        String usage = Math.round(used / max * 100) + "%";
        String title = (char) 0x1b + "]0;" + this.getName() + " "
            + this.getNukkitVersion()
            + " | " + this.getGitCommit()
            + " | Online " + this.players.size() + "/" + this.getMaxPlayers()
            + " | Memory " + usage;
        if (!PowerNukkitX.shortTitle) {
            title += " | U " + NukkitMath.round((this.network.getUpload() / 1024 * 1000), 2)
                + " D " + NukkitMath.round((this.network.getDownload() / 1024 * 1000), 2) + " kB/s";
        }
        title += " | TPS " + this.getTicksPerSecond()
            + " | Load " + this.getTickUsage() + "%" + (char) 0x07;

        System.out.print(title);
    }

    public boolean isRunning() {
        return isRunning.get();
    }

    /**
     * Set the server to busy status, which prevents related code from detecting the
     * server as unresponsive.
     * Remember to clear this setting after use.
     *
     * @param busyTime milliseconds
     * @return id
     */
    public int addBusying(long busyTime) {
        this.busyingTime.add(busyTime);
        return this.busyingTime.size() - 1;
    }

    public void removeBusying(int index) {
        this.busyingTime.removeLong(index);
    }

    public long getBusyingTime() {
        if (this.busyingTime.isEmpty()) {
            return -1;
        }
        return this.busyingTime.getLong(this.busyingTime.size() - 1);
    }

    public TickingAreaManager getTickingAreaManager() {
        return tickingAreaManager;
    }

    public long getLaunchTime() {
        return launchTime;
    }

    // endregion

    // region server singleton

    public static Server getInstance() {
        return instance;
    }

    // endregion

    // region chat and commands

    /**
     * Broadcast a message to all players
     *
     * @param message The broadcasted message
     * @return int Number of players
     */
    public int broadcastMessage(String message) {
        return this.broadcast(message, BROADCAST_CHANNEL_USERS);
    }

    /**
     * @see #broadcastMessage(String)
     */
    public int broadcastMessage(TextContainer message) {
        return this.broadcast(message, BROADCAST_CHANNEL_USERS);
    }

    /**
     * Broadcast a message to the specified {@link CommandSender recipients}
     *
     * @param message The broadcasted message
     * @return int Number of {@link CommandSender recipients}
     */
    public int broadcastMessage(String message, CommandSender[] recipients) {
        for (CommandSender recipient : recipients) {
            recipient.sendMessage(message);
        }

        return recipients.length;
    }

    /**
     * @see #broadcastMessage(String, CommandSender[])
     */
    public int broadcastMessage(String message, Collection<? extends CommandSender> recipients) {
        for (CommandSender recipient : recipients) {
            recipient.sendMessage(message);
        }

        return recipients.size();
    }

    /**
     * @see #broadcastMessage(String, CommandSender[])
     */
    public int broadcastMessage(TextContainer message, Collection<? extends CommandSender> recipients) {
        for (CommandSender recipient : recipients) {
            recipient.sendMessage(message);
        }

        return recipients.size();
    }

    /**
     * Get the sender to broadcast a message from the specified permission name,
     * multiple permissions can be specified, split by <b> ; </b><br>
     * The permission corresponds to a {@link CommandSender Sender} set in
     * {@code PluginManager#permSubs}.
     *
     * @param message     Message content
     * @param permissions Permissions name, need to register first through {@link PluginManager#subscribeToPermission subscribeToPermission}
     * @return Number of {@link CommandSender senders} who received the message
     */
    public int broadcast(String message, String permissions) {
        Set<CommandSender> recipients = new HashSet<>();

        for (String permission : permissions.split(";")) {
            for (Permissible permissible : this.pluginManager.getPermissionSubscriptions(permission)) {
                if (permissible instanceof CommandSender && permissible.hasPermission(permission)) {
                    recipients.add((CommandSender) permissible);
                }
            }
        }

        for (CommandSender recipient : recipients) {
            recipient.sendMessage(message);
        }

        return recipients.size();
    }

    /**
     * @see #broadcast(String, String)
     */
    public int broadcast(TextContainer message, String permissions) {
        Set<CommandSender> recipients = new HashSet<>();

        for (String permission : permissions.split(";")) {
            for (Permissible permissible : this.pluginManager.getPermissionSubscriptions(permission)) {
                if (permissible instanceof CommandSender && permissible.hasPermission(permission)) {
                    recipients.add((CommandSender) permissible);
                }
            }
        }

        for (CommandSender recipient : recipients) {
            recipient.sendMessage(message);
        }

        return recipients.size();
    }

    /**
     * Execute one line of command as sender
     *
     * @param sender      Command sender
     * @param commandLine A command
     * @return Returns 0 for failed execution, greater than or equal to 1 for
     * successful execution
     * @throws ServerException Server exception
     */
    public int executeCommand(CommandSender sender, String commandLine) throws ServerException {
        // First, we need to check if this command is on the main thread or not, if not,
        // merge it in the main thread.
        if (!this.isPrimaryThread()) {
            this.scheduler.scheduleTask(null, () -> executeCommand(sender, commandLine));
            return 1;
        }
        if (sender == null) {
            throw new ServerException("CommandSender is not valid");
        }

        var cmd = commandLine.stripLeading();
        if (cmd.isEmpty()) {
            return 0;
        }
        cmd = cmd.charAt(0) == '/' ? cmd.substring(1) : cmd;

        return this.commandMap.executeCommand(sender, cmd);
    }

    /**
     * Execute these commands silently as the console, ignoring permissions.
     *
     * @param commands the commands
     * @throws ServerException Server exception
     */
    public void silentExecuteCommand(String... commands) {
        this.silentExecuteCommand(null, commands);
    }

    /**
     * Execute these commands silently as this player, ignoring permissions.
     *
     * @param sender   command sender
     * @param commands the commands
     * @throws ServerException Server exception
     */
    public void silentExecuteCommand(@Nullable Player sender, String... commands) {
        final var revert = new ArrayList<Level>();
        final var server = Server.getInstance();
        for (var level : server.getLevels().values()) {
            if (level.getGameRules().getBoolean(GameRule.SEND_COMMAND_FEEDBACK)) {
                level.getGameRules().setGameRule(GameRule.SEND_COMMAND_FEEDBACK, false);
                revert.add(level);
            }
        }
        if (sender == null) {
            for (var cmd : commands) {
                server.executeCommand(server.getConsoleSender(), cmd);
            }
        } else {
            for (var cmd : commands) {
                server.executeCommand(server.getConsoleSender(),
                    "execute as " + "\"" + sender.getName() + "\" run " + cmd);
            }
        }

        for (var level : revert) {
            level.getGameRules().setGameRule(GameRule.SEND_COMMAND_FEEDBACK, true);
        }
    }

    /**
     * Get the console sender
     *
     * @return {@link ConsoleCommandSender}
     */
    // TODO: use ticker to check console
    public ConsoleCommandSender getConsoleSender() {
        return consoleSender;
    }

    public SimpleCommandMap getCommandMap() {
        return commandMap;
    }

    public PluginIdentifiableCommand getPluginCommand(String name) {
        Command command = this.commandMap.getCommand(name);
        if (command instanceof PluginIdentifiableCommand) {
            return (PluginIdentifiableCommand) command;
        } else {
            return null;
        }
    }

    public IScoreboardManager getScoreboardManager() {
        return scoreboardManager;
    }

    public FunctionManager getFunctionManager() {
        return functionManager;
    }

    // endregion

    // region networking

    /**
     * @see #broadcastPacket(Player[], BedrockPacket)
     */
    public static void broadcastPacket(Collection<Player> players, BedrockPacket packet) {
        final BedrockPacket shared = SharedPacket.forBroadcast(packet, players.size());
        for (Player player : players) {
            player.sendPacket(player.getClass() == Player.class ? shared : packet);
        }
    }

    /**
     * Broadcast a packet to the specified players.
     *
     * @param players All players receiving the data packet
     * @param packet  The data packet
     */
    public static void broadcastPacket(Player[] players, BedrockPacket packet) {
        final BedrockPacket shared = SharedPacket.forBroadcast(packet, players.length);
        for (Player player : players) {
            player.sendPacket(player.getClass() == Player.class ? shared : packet);
        }
    }

    public QueryRegenerateEvent getQueryInformation() {
        return this.queryRegenerateEvent;
    }

    public NetworkInterface getNetwork() {
        return network;
    }

    // endregion

    // region plugins

    /**
     * Enable plugins in the specified plugin loading order
     *
     * @param type Plugin loading order
     */
    public void enablePlugins(PluginLoadOrder type) {
        for (Plugin plugin : new ArrayList<>(this.pluginManager.getPlugins().values())) {
            if (!plugin.isEnabled() && type == plugin.getDescription().getOrder()) {
                this.enablePlugin(plugin);
            }
        }

        if (type == PluginLoadOrder.POSTWORLD) {
            DefaultPermissions.registerCorePermissions();
        }
    }

    /**
     * Enable a specified plugin
     *
     * @param plugin Plugin instance
     */
    public void enablePlugin(Plugin plugin) {
        this.pluginManager.enablePlugin(plugin);
    }

    /**
     * Disable all plugins
     */
    public void disablePlugins() {
        this.pluginManager.disablePlugins();
    }

    public PluginManager getPluginManager() {
        return this.pluginManager;
    }

    public ServiceManager getServiceManager() {
        return serviceManager;
    }

    // endregion

    // region players

    public void onPlayerCompleteLoginSequence(Player player) {
        this.sendFullPlayerListData(player);
    }

    public void onPlayerLogin(InetSocketAddress socketAddress, Player player) {
        PlayerLoginEvent ev = new PlayerLoginEvent(player, "Plugin reason");
        this.getPluginManager().callEvent(ev);

        if (ev.isCancelled()) {
            player.close(player.getLeaveMessage(), ev.getKickMessage());
        }

        // A handler may also kick the player itself without cancelling, so check the connection
        // rather than the event. Putting a closed player in here would leak it for good.
        if (!player.isConnected()) {
            this.removeOnlinePlayer(player);
            this.players.remove(socketAddress);
            this.uniquePlayers.remove(player.getUniqueId());

            return;
        }

        for (Player existing : new ArrayList<>(this.players.values())) {
            if (existing == player || this.playerList.get(existing.getUniqueId()) == existing) {
                continue;
            }

            if (existing.getUniqueId().equals(player.getUniqueId()) || existing.getName().equalsIgnoreCase(player.getName())) {
                existing.close("disconnectionScreen.loggedinOtherLocation");
            }
        }

        this.players.put(socketAddress, player);
        if (this.sendUsageTicker > 0) {
            this.uniquePlayers.add(player.getUniqueId());
        }
    }

    @ApiStatus.Internal
    public void sendSleepingPlayersStatus(Collection<Player> recipients) {
        this.sendSleepingPlayersStatus(recipients, false);
    }

    @ApiStatus.Internal
    public void sendSleepingPlayersStatusImmediately(Collection<Player> recipients) {
        this.sendSleepingPlayersStatus(recipients, true);
    }

    private void sendSleepingPlayersStatus(Collection<Player> recipients, boolean immediately) {
        Level overworld = this.getDefaultLevel();

        int overworldPlayerCount = 0;
        int sleepingPlayerCount = 0;

        if (overworld != null) {
            for (Player player : overworld.getPlayers().values()) {
                overworldPlayerCount++;
                if (player.isSleeping()) sleepingPlayerCount++;
            }
        }

        overworldPlayerCount = Math.max(1, overworldPlayerCount);

        for (Player recipient : recipients) {
            if (immediately) {
                recipient.sendSleepingPlayersStatusImmediately(1, overworldPlayerCount, sleepingPlayerCount);
            } else {
                recipient.sendSleepingPlayersStatus(1, overworldPlayerCount, sleepingPlayerCount);
            }
        }
    }

    @ApiStatus.Internal
    public void broadcastSleepingPlayersStatus() {
        this.sendSleepingPlayersStatus(this.playerList.values());
    }


    @ApiStatus.Internal
    public void addOnlinePlayer(Player player) {
        if (player.uniqueIdLong() == 0) {
            throw new IllegalStateException("Player " + player.getName() + " has no persistent ActorUniqueID");
        }

        Player existing = this.playerListByUniqueId.putIfAbsent(player.uniqueIdLong(), player);

        if (existing != null && existing != player) {
            throw new IllegalStateException("Player ActorUniqueID " + player.uniqueIdLong() + " is already online as " + existing.getName());
        }

        this.playerList.put(player.getUniqueId(), player);

        final List<Player> recipients = new ArrayList<>(this.playerList.values());
        recipients.remove(player);

        if (!recipients.isEmpty()) {
            this.sendSleepingPlayersStatus(recipients);

            this.updatePlayerListData(
                player.getUniqueId(),
                player.uniqueIdLong(),
                player.getDisplayName(),
                player.getSkin(),
                player.getXUID(),
                player.getLocatorBarColor(),
                recipients
            );
        }

        this.getNetwork().updatePong(this.getNetwork().getPong().playerCount(playerList.size()));
    }

    @ApiStatus.Internal
    public void removeOnlinePlayer(Player player) {
        boolean removed = this.playerList.remove(player.getUniqueId(), player);
        this.playerListByUniqueId.remove(player.uniqueIdLong(), player);

        PlayerListEncoder.forget(player.getUniqueId());
        if (removed) {
            this.sendSleepingPlayersStatus(this.playerList.values());

            final PlayerListPacket pk = new PlayerListPacket();
            final PlayerListRemoveEntry entry = new PlayerListRemoveEntry();
            entry.setUuid(player.getUniqueId());

            pk.getEntries().add(entry);

            Server.broadcastPacket(this.playerList.values(), pk);
            this.getNetwork().updatePong(this.getNetwork().getPong().playerCount(playerList.size()));
        }
    }

    /**
     * @see #updatePlayerListData(UUID, long, String, Skin, String, Color, Player[])
     */

    public void updatePlayerListData(UUID uuid, long entityId, String name, Skin skin) {
        this.updatePlayerListData(uuid, entityId, name, skin, "", Color.WHITE, this.playerList.values());
    }

    public void updatePlayerListData(UUID uuid, long entityId, String name, Skin skin, Color color) {
        this.updatePlayerListData(uuid, entityId, name, skin, "", color, this.playerList.values());
    }

    /**
     * @see #updatePlayerListData(UUID, long, String, Skin, String, Color, Player[])
     */
    public void updatePlayerListData(UUID uuid, long entityId, String name, Skin skin, String xboxUserId, Color color) {
        this.updatePlayerListData(uuid, entityId, name, skin, xboxUserId, color, this.playerList.values());
    }

    /**
     * @see #updatePlayerListData(UUID, long, String, Skin, String, Color, Player[])
     */
    public void updatePlayerListData(UUID uuid, long entityId, String name, Skin skin, Player[] players) {
        this.updatePlayerListData(uuid, entityId, name, skin, "", Color.WHITE, players);
    }

    /**
     * @see #updatePlayerListData(UUID, long, String, Skin, String, Color, Player[])
     */
    public void updatePlayerListData(UUID uuid, long entityId, String name, Skin skin, Color color, Player[] players) {
        this.updatePlayerListData(uuid, entityId, name, skin, "", color, players);
    }

    /**
     * Update {@link PlayerListPacket} data packets (i.e., player list data) for
     * specified players
     *
     * @param uuid       the uuid
     * @param entityId   entity id
     * @param name       player name
     * @param skin       player skin
     * @param xboxUserId xbox user id
     * @param players    players to send packet
     */
    public void updatePlayerListData(UUID uuid, long entityId, String name, Skin skin, String xboxUserId, Color color, Player[] players) {
        final PlayerListPacket pk = new PlayerListPacket();
        final PlayerListAddEntry entry = new PlayerListAddEntry();
        entry.setUuid(uuid);
        entry.setActorUniqueID(entityId);
        entry.setPlayerName(name);
        entry.setXblXUID(xboxUserId);
        entry.setPlayFabID(Objects.requireNonNullElse(skin.getSkin().getPlayFabId(), ""));
        entry.setPlatformOnlineID("");
        entry.setBuildPlatform(BuildPlatform.UNKNOWN);
        entry.setSerializedSkin(skin.toSerializedSkin());
        entry.setPlayerColor(color.getRGB());

        pk.getEntries().add(entry);
        Server.broadcastPacket(players, pk);
    }

    /**
     * @see #updatePlayerListData(UUID, long, String, Skin, String, Color, Player[])
     */
    public void updatePlayerListData(UUID uuid, long entityId, String name, Skin skin, String xboxUserId, Color color, Collection<Player> players) {
        this.updatePlayerListData(uuid, entityId, name, skin, xboxUserId, color, players.toArray(Player.EMPTY_ARRAY));
    }

    public void removePlayerListData(UUID uuid) {
        this.removePlayerListData(uuid, this.playerList.values());
    }

    /**
     * Remove player list data for all players in the array.
     *
     * @param players player array
     */
    public void removePlayerListData(UUID uuid, Player[] players) {
        final PlayerListPacket pk = new PlayerListPacket();
        final PlayerListRemoveEntry entry = new PlayerListRemoveEntry();
        entry.setUuid(uuid);

        pk.getEntries().add(entry);

        Server.broadcastPacket(players, pk);
    }

    /**
     * Remove this player's player list data.
     *
     * @param player The player
     */

    public void removePlayerListData(UUID uuid, Player player) {
        final PlayerListPacket pk = new PlayerListPacket();
        final PlayerListRemoveEntry entry = new PlayerListRemoveEntry();
        entry.setUuid(uuid);

        pk.getEntries().add(entry);

        player.sendPacket(pk);
    }

    public void removePlayerListData(UUID uuid, Collection<Player> players) {
        this.removePlayerListData(uuid, players.toArray(Player.EMPTY_ARRAY));
    }

    /**
     * Send a player list packet to a player.
     *
     * @param player The player
     */
    public void sendFullPlayerListData(Player player) {
        if (PlayerListEncoder.trySend(player, this.playerList.values(), PLAYER_LIST_ENTRIES_PER_PACKET)) {
            return;
        }
        PlayerListPacket pk = new PlayerListPacket();

        for (Player value : this.playerList.values()) {
            pk.getEntries().add(PlayerListEncoder.addEntry(value));
            // Every entry carries a whole skin, so a full server would otherwise make one packet
            // of many megabytes that has to be encoded and acknowledged in one go
            if (pk.getEntries().size() >= PLAYER_LIST_ENTRIES_PER_PACKET) {
                player.sendPacketImmediately(pk);
                pk = new PlayerListPacket();
            }
        }
        if (!pk.getEntries().isEmpty()) {
            player.sendPacketImmediately(pk);
        }
    }

    /**
     * Get all unique player UUIDs that have connected to the server during the
     * current uptime.
     *
     * @return Set of UUIDs
     */
    public Set<UUID> getUniquePlayers() {
        return uniquePlayers;
    }

    /**
     * Get the player instance from the specified UUID.
     *
     * @param uuid uuid
     * @return Player example can be empty
     */
    public Optional<Player> getPlayer(UUID uuid) {
        Preconditions.checkNotNull(uuid, "uuid");
        return Optional.ofNullable(playerList.get(uuid));
    }

    /**
     * Returns an online player by Bedrock ActorUniqueID.
     *
     * @param uniqueId actor unique ID
     * @return matching online player
     */
    public Optional<Player> getPlayerByUniqueId(long uniqueId) {
        return Optional.ofNullable(this.playerListByUniqueId.get(uniqueId));
    }

    /**
     * Resolves a reserved player ActorUniqueID to its UUID.
     *
     * @param uniqueId actor unique ID
     * @return matching player UUID
     */
    @ApiStatus.Internal
    public Optional<UUID> getPlayerUuidByUniqueId(long uniqueId) {
        return Optional.ofNullable(this.actorUniqueIdManager.getPlayerUuid(uniqueId));
    }

    /**
     * Returns the registered ActorUniqueID for the specified player UUID.
     *
     * @param uuid player UUID
     * @return registered actor unique ID
     */
    @ApiStatus.Internal
    public long resolvePlayerUniqueId(UUID uuid) {
        Preconditions.checkNotNull(uuid, "uuid");
        return this.actorUniqueIdManager.requirePlayer(uuid);
    }

    /**
     * Validates and returns the registered ActorUniqueID from canonical player data.
     *
     * @param uuid player UUID
     * @param nbt canonical player data
     * @return validated actor unique ID
     */
    @ApiStatus.Internal
    public long requirePlayerUniqueId(UUID uuid, CompoundTag nbt) {
        Preconditions.checkNotNull(uuid, "uuid");
        Preconditions.checkNotNull(nbt, "nbt");
        return this.actorUniqueIdManager.requirePlayer(uuid, nbt);
    }

    /**
     * Returns whether an ActorUniqueID is reserved for a player.
     *
     * @param uniqueId actor unique ID
     * @return whether the ID is player-reserved
     */
    @ApiStatus.Internal
    public boolean isPlayerUniqueIdReserved(long uniqueId) {
        return this.actorUniqueIdManager != null && this.actorUniqueIdManager.isPlayerReserved(uniqueId);
    }

    /**
     * Allocates a new server-global ActorUniqueID.
     *
     * @return allocated actor unique ID
     */
    @ApiStatus.Internal
    public long getNewActorUniqueId() {
        if (this.actorUniqueIdManager == null) {
            throw new IllegalStateException(
                    "Server-global ActorUniqueID manager has not been initialized"
            );
        }

        return this.actorUniqueIdManager.next();
    }

    /**
     * Find the UUID corresponding to the specified player name from the database.
     *
     * @param name player name
     * @return The player's UUID, which can be empty.
     */
    public Optional<UUID> lookupName(String name) {
        byte[] nameKey = PlayerDataKeys.name(name);
        byte[] uuidBytes = serverDataDB.get(nameKey);
        if (uuidBytes == null) {
            return Optional.empty();
        }

        if (uuidBytes.length != 16) {
            log.debug("Invalid uuid in name lookup database detected! Removing");
            serverDataDB.delete(nameKey);
            return Optional.empty();
        }

        ByteBuffer buffer = ByteBuffer.wrap(uuidBytes);
        return Optional.of(new UUID(buffer.getLong(), buffer.getLong()));
    }

    /**
     * Update the UUID of the specified player name in the database, or add it if it
     * does not exist.
     *
     * @param info the player info
     */
    void updateName(Player.PlayerInfo info) {
        var uniqueId = uuidFromXUID(resolveXuid(info, this.getProxyAuthProvider()));
        var name = info.getIdentityClaims().extraData.displayName;

        byte[] nameKey = PlayerDataKeys.name(name);

        ByteBuffer buffer = ByteBuffer.allocate(16);
        buffer.putLong(uniqueId.getMostSignificantBits());
        buffer.putLong(uniqueId.getLeastSignificantBits());
        byte[] array = buffer.array();
        byte[] existing = serverDataDB.get(nameKey);
        if (existing == null || !Arrays.equals(existing, array)) {
            serverDataDB.put(nameKey, array);
        }
    }

    /**
     * The XUID a login identifies as, after the {@link ProxyAuthProvider} has had its say.
     *
     * @param info  the login of the player
     * @param proxy the installed proxy authentication provider, or {@code null}
     * @return the XUID, which may be empty for a login that is not signed by Xbox Live
     */
    public static String resolveXuid(Player.PlayerInfo info, @Nullable ProxyAuthProvider proxy) {
        String xuid = info.getIdentityClaims().extraData.xuid;
        return proxy != null ? proxy.getXuid(info.getClientChainData(), xuid) : xuid;
    }

    /**
     * Derives a stable {@link UUID} from a player's XUID (Xbox User ID).
     * <p>
     * The XUID is namespaced with the {@code "pocket-auth-1-xuid:"} prefix and hashed
     * using {@link UUID#nameUUIDFromBytes(byte[])} (a type 3, name-based UUID). Because
     * the derivation is deterministic, the same XUID always yields the same UUID, while
     * different XUIDs yield different UUIDs.
     *
     * @param xuid the player's XUID, as provided by Xbox Live authentication
     * @return a deterministic, name-based {@link UUID} derived from the given XUID
     */
    public static UUID uuidFromXUID(String xuid) {
        return UUID.nameUUIDFromBytes(("pocket-auth-1-xuid:" + xuid).getBytes(StandardCharsets.UTF_8));
    }

    public IPlayer getOfflinePlayer(final String name) {
        IPlayer result = this.getPlayerExact(name.toLowerCase(Locale.ENGLISH));
        if (result != null) {
            return result;
        }

        return lookupName(name).map(uuid -> new OfflinePlayer(this, uuid))
            .orElse(new OfflinePlayer(this, name));
    }

    /**
     * Get a player instance from the specified UUID, either online or offline.
     *
     * @param uuid uuid
     * @return player
     */
    public IPlayer getOfflinePlayer(UUID uuid) {
        Preconditions.checkNotNull(uuid, "uuid");
        Optional<Player> onlinePlayer = getPlayer(uuid);
        if (onlinePlayer.isPresent()) {
            return onlinePlayer.get();
        }

        return new OfflinePlayer(this, uuid);
    }

    /**
     * Gets a player instance from the specified Bedrock ActorUniqueID, either online or offline.
     *
     * @param uniqueId Bedrock ActorUniqueID
     * @return matching player, or {@code null} when the ActorUniqueID is not registered to a player
     */
    public @Nullable IPlayer getOfflinePlayer(long uniqueId) {
        return this.getPlayerUuidByUniqueId(uniqueId)
            .map(this::getOfflinePlayer)
            .orElse(null);
    }

    /**
     * Gets a player instance from the specified Xbox User ID, either online or offline.
     *
     * @param xuid Xbox User ID
     * @return player
     */
    public IPlayer getOfflinePlayerByXUID(String xuid) {
        Preconditions.checkNotNull(xuid, "xuid");
        Preconditions.checkArgument(!xuid.isBlank(), "xuid cannot be blank");
        return this.getOfflinePlayer(uuidFromXUID(xuid));
    }

    /**
     * create is false
     *
     * @see #getOfflinePlayerData(UUID, boolean)
     */
    public CompoundTag getOfflinePlayerData(UUID uuid) {
        return getOfflinePlayerData(uuid, false);
    }

    public CompoundTag getOfflinePlayerData(UUID uuid, boolean create) {
        return getOfflinePlayerDataInternal(uuid, create);
    }

    /**
     * Retrieve the NBT data for the player specified by the UUID
     *
     * @param uuid   UUID of the player to get data from
     * @param create If player data does not exist, whether to create.
     * @return {@link CompoundTag}
     */
    PlayerDataRecord getOfflinePlayerDataRecord(UUID uuid, boolean create) {
        CompoundTag nbt = getOfflinePlayerDataInternal(uuid, create);

        if (nbt == null) return null;

        return new PlayerDataRecord(nbt, getOfflinePlayerExtraDataInternal(uuid), getOfflinePlayerCustomDataInternal(uuid));
    }

    public CompoundTag getOfflinePlayerData(String name) {
        return getOfflinePlayerData(name, false);
    }

    public CompoundTag getOfflinePlayerData(String name, boolean create) {
        Optional<UUID> uuid = lookupName(name);
        if (uuid.isEmpty()) {
            log.debug("Invalid uuid in name lookup database detected! Removing");
            serverDataDB.delete(PlayerDataKeys.name(name));
            return null;
        }
        return getOfflinePlayerDataInternal(uuid.get(), create);
    }

    public boolean hasOfflinePlayerData(String name) {
        Optional<UUID> uuid = lookupName(name);
        if (uuid.isEmpty()) {
            log.debug("Invalid uuid in name lookup database detected! Removing");
            serverDataDB.delete(PlayerDataKeys.name(name));
            return false;
        }
        return hasOfflinePlayerData(uuid.get());
    }

    public boolean hasOfflinePlayerData(UUID uuid) {
        return serverDataDB.get(PlayerDataKeys.player(uuid)) != null;
    }

    private CompoundTag getOfflinePlayerDataInternal(UUID uuid, boolean create) {
        if (uuid == null) {
            log.error("UUID is empty, cannot query player data");
            return null;
        }
        byte[] bytes = serverDataDB.get(PlayerDataKeys.player(uuid));

        if (bytes != null) {
            try (final ByteArrayInputStream inputStream = new ByteArrayInputStream(bytes);
                 final NBTInputStream nbtInputStream = NbtUtils.createGZIPReader(inputStream)) {
                return CompoundTag.fromNetwork((NbtMap) nbtInputStream.readTag());
            } catch (IOException e) {
                log.warn(this.getLanguage().tr("nukkit.data.playerCorrupted", uuid), e);
                return null;
            }
        }

        if (create) {
            final PlayerDataRecord created = this.newPlayerData(uuid);
            this.saveOfflinePlayerDataInternal(created.nbt(), created.pnxExtra(), created.custom(), uuid);
            return created.nbt();
        } else {
            log.error("Player {} does not exist and cannot read playerdata", uuid);
            return null;
        }
    }

    /**
     * Creates the data of a player that has none stored yet and writes it on the player data
     * thread, so the caller neither touches storage nor waits for it. The spawn position is taken
     * from the default level.
     */
    PlayerDataRecord createPlayerData(UUID uuid) {
        final PlayerDataRecord created = this.newPlayerData(uuid);
        this.queueOfflinePlayerDataWrite(uuid, created.nbt(), created.pnxExtra().copy(), new CompoundTag(), true);
        return created;
    }

    private PlayerDataRecord newPlayerData(UUID uuid) {
        if (this.getSettings().playerSettings().savePlayerData()) {
            log.info(this.getLanguage().tr("nukkit.data.playerNotFound", uuid));
        }
        Position spawn = this.getDefaultLevel().getSafeSpawn();

        ListTag<CompoundTag> inventory = new ListTag<>(Tag.TAG_Compound);
        for (int slot = 0; slot < 36; slot++) {
            inventory.add(ItemHelper.write(Item.AIR, slot));
        }

        ListTag<CompoundTag> armor = new ListTag<>(Tag.TAG_Compound);
        for (int slot = 0; slot < 5; slot++) {
            armor.add(ItemHelper.write(Item.AIR));
        }

        ListTag<CompoundTag> mainhand = new ListTag<CompoundTag>(Tag.TAG_Compound).add(ItemHelper.write(Item.AIR));
        ListTag<CompoundTag> offhand = new ListTag<CompoundTag>(Tag.TAG_Compound).add(ItemHelper.write(Item.AIR));
        ListTag<CompoundTag> enderChest = new ListTag<>(Tag.TAG_Compound);
        for (int slot = 0; slot < 27; slot++) {
            enderChest.add(ItemHelper.write(Item.AIR, slot));
        }

        Attribute knockbackResistance = Attribute.getAttribute(Attribute.KNOCKBACK_RESISTANCE)
            .setMinValue(-2f)
            .setDefaultMinimum(-2f);

        Attribute attackDamage = Attribute.getAttribute(Attribute.ATTACK_DAMAGE)
            .setMinValue(1f)
            .setMaxValue(1f)
            .setDefaultMinimum(1f)
            .setDefaultMaximum(1f)
            .setDefaultValue(1f)
            .setValue(1f);

        ListTag<CompoundTag> attributes = new ListTag<CompoundTag>(Tag.TAG_Compound)
            .add(Attribute.toNBT(Attribute.getAttribute(Attribute.HEALTH).setValue(20)))
            .add(Attribute.toNBT(Attribute.getAttribute(Attribute.FOLLOW_RANGE)))
            .add(Attribute.toNBT(knockbackResistance))
            .add(Attribute.toNBT(Attribute.getAttribute(Attribute.MOVEMENT_SPEED)))
            .add(Attribute.toNBT(Attribute.getAttribute(Attribute.UNDER_WATER_MOVEMENT_SPEED)))
            .add(Attribute.toNBT(Attribute.getAttribute(Attribute.LAVA_MOVEMENT_SPEED)))
            .add(Attribute.toNBT(attackDamage))
            .add(Attribute.toNBT(Attribute.getAttribute(Attribute.ABSORPTION).setValue(0)))
            .add(Attribute.toNBT(Attribute.getAttribute(Attribute.LUCK)))
            .add(Attribute.toNBT(Attribute.getAttribute(Attribute.FRICTION_MODIFIER)))
            .add(Attribute.toNBT(Attribute.getAttribute(Attribute.BOUNCINESS)))
            .add(Attribute.toNBT(Attribute.getAttribute(Attribute.AIR_DRAG_MODIFIER)))
            .add(Attribute.toNBT(Attribute.getAttribute(Attribute.FOOD).setValue(20)))
            .add(Attribute.toNBT(Attribute.getAttribute(Attribute.SATURATION).setValue(5)))
            .add(Attribute.toNBT(Attribute.getAttribute(Attribute.EXHAUSTION).setValue(0)))
            .add(Attribute.toNBT(Attribute.getAttribute(Attribute.EXPERIENCE_LEVEL).setDefaultValue(0).setValue(0)))
            .add(Attribute.toNBT(Attribute.getAttribute(Attribute.EXPERIENCE).setDefaultValue(0).setValue(0)));

        int defaultGamemode = this.getGamemode();
        boolean creative = defaultGamemode == Player.CREATIVE;
        boolean spectator = defaultGamemode == Player.SPECTATOR;

        CompoundTag abilities = new CompoundTag()
            .putByte("attackmobs", 1)
            .putByte("attackplayers", 1)
            .putByte("build", 1)
            .putByte("doorsandswitches", 1)
            .putFloat("flySpeed", Player.DEFAULT_FLY_SPEED)
            .putByte("flying", spectator ? 1 : 0)
            .putByte("instabuild", creative ? 1 : 0)
            .putByte("invulnerable", 0)
            .putByte("lightning", 0)
            .putByte("mayfly", creative || spectator ? 1 : 0)
            .putByte("mine", 1)
            .putByte("op", 0)
            .putByte("opencontainers", 1)
            .putByte("teleport", 0)
            .putFloat("verticalFlySpeed", 1f)
            .putFloat("walkSpeed", Player.DEFAULT_SPEED);

        long now = System.currentTimeMillis() / 1000;

        final CompoundTag pnxExtra = new CompoundTag()
            .putLong("firstPlayed", now)
            .putLong("lastPlayed", now)
            .putString("Level", this.getDefaultLevel().getName())
            .putCompound("Achievements", new CompoundTag());

        final CompoundTag nbt = new CompoundTag()
            .putList("Pos", new ListTag<FloatTag>()
                .add(new FloatTag((float) spawn.x))
                .add(new FloatTag((float) spawn.y))
                .add(new FloatTag((float) spawn.z)))
            .putInt("DimensionId", this.getDefaultLevel().getDimension())
            .putList("Inventory", inventory)
            .putList("Armor", armor)
            .putList("Mainhand", mainhand)
            .putList("Offhand", offhand)
            .putList("EnderChestInventory", enderChest)
            .putInt("SelectedInventorySlot", 0)
            .putInt("SelectedContainerId", 0)
            .putList("Attributes", attributes)
            .putList("definitions", new ListTag<StringTag>(Tag.TAG_String)
                .add(new StringTag("+minecraft:player")))
            .putString("format_version", "1.12.0")
            .putString("identifier", "minecraft:player")
            .putList("fogCommandStack", new ListTag<>())
            .putList("PlayerUIItems", new ListTag<>())
            .putInt("SpawnX", Integer.MIN_VALUE)
            .putInt("SpawnY", Integer.MIN_VALUE)
            .putInt("SpawnZ", Integer.MIN_VALUE)
            .putInt("SpawnBlockPositionX", Integer.MIN_VALUE)
            .putInt("SpawnBlockPositionY", Integer.MIN_VALUE)
            .putInt("SpawnBlockPositionZ", Integer.MIN_VALUE)
            .putInt("SpawnDimension", 3)
            .putInt("PlayerGameMode", Player.toStorageGamemode(defaultGamemode))
            .putInt("PlayerLevel", 0)
            .putFloat("PlayerLevelProgress", 0)
            .putInt("EnchantmentSeed", Player.generateEnchantmentSeed())
            .putList("Motion", new ListTag<FloatTag>()
                .add(new FloatTag(0))
                .add(new FloatTag(0))
                .add(new FloatTag(0)))
            .putList("Rotation", new ListTag<FloatTag>()
                .add(new FloatTag(0))
                .add(new FloatTag(0)))
            .putFloat("FallDistance", 0)
            .putShort("Fire", 0)
            .putShort("Air", 400)
            .putBoolean("OnGround", true)
            .putBoolean("Invulnerable", false)
            .putCompound("abilities", abilities)
            .putInt("permissionsLevel", 0)
            .putInt("playerPermissionsLevel", Player.PERMISSION_MEMBER);

        this.actorUniqueIdManager.assignPlayer(uuid, nbt);
        return new PlayerDataRecord(nbt, pnxExtra, new CompoundTag());
    }

    private CompoundTag getOfflinePlayerExtraDataInternal(UUID uuid) {
        return getOfflinePlayerSidecarDataInternal(PlayerDataKeys.pnxExtra(uuid), "PNX extra", uuid);
    }

    private CompoundTag getOfflinePlayerCustomDataInternal(UUID uuid) {
        return getOfflinePlayerSidecarDataInternal(PlayerDataKeys.custom(uuid), "custom", uuid);
    }

    private CompoundTag getOfflinePlayerSidecarDataInternal(byte[] key, String type, UUID uuid) {
        byte[] bytes = serverDataDB.get(key);

        if (bytes == null) {
            return new CompoundTag();
        }

        try (final ByteArrayInputStream inputStream = new ByteArrayInputStream(bytes);
             final NBTInputStream nbtInputStream = NbtUtils.createGZIPReader(inputStream)) {
            return CompoundTag.fromNetwork((NbtMap) nbtInputStream.readTag());
        } catch (IOException e) {
            throw new UncheckedIOException("Unable to read " + type + " player data for " + uuid, e);
        }
    }

    /**
     * @see #saveOfflinePlayerData(String, CompoundTag, boolean)
     */
    public void saveOfflinePlayerData(UUID uuid, CompoundTag tag) {
        this.saveOfflinePlayerData(uuid, tag, false);
    }

    /**
     * @see #saveOfflinePlayerData(String, CompoundTag, boolean)
     */
    public void saveOfflinePlayerData(UUID uuid, CompoundTag tag, boolean async) {
        this.saveOfflinePlayerData(uuid.toString(), tag, async);
    }

    /**
     * @see #saveOfflinePlayerData(String, CompoundTag, boolean)
     */
    public void saveOfflinePlayerData(String name, CompoundTag tag) {
        this.saveOfflinePlayerData(name, tag, false);
    }

    /**
     * Save player data, players can be offline.
     *
     * @param nameOrUUid the name or uuid
     * @param tag        nbt data
     * @param async      Whether to save asynchronously
     */
    public void saveOfflinePlayerData(String nameOrUUid, CompoundTag tag, boolean async) {
        UUID uuid = lookupName(nameOrUUid).orElseGet(() -> UUID.fromString(nameOrUUid));
        saveOfflinePlayerData(uuid, tag, null, null, async);
    }

    void saveOfflinePlayerData(UUID uuid, CompoundTag tag, CompoundTag pnxExtra, CompoundTag custom, boolean async) {
        if (!this.getSettings().playerSettings().savePlayerData()) {
            return;
        }
        this.queueOfflinePlayerDataWrite(uuid, tag, pnxExtra, custom, async);
    }

    private void queueOfflinePlayerDataWrite(UUID uuid, CompoundTag tag, CompoundTag pnxExtra, CompoundTag custom, boolean async) {
        final CompletableFuture<Void> written = async ? new CompletableFuture<>() : null;
        final CompoundTag snapshot = async ? tag.copy() : tag;
        this.playerDataWrites.compute(uuid, (_, writes) -> {
            final PlayerDataWrites entry = writes != null ? writes : new PlayerDataWrites();
            entry.latest = entry.latest.with(entry.requested.incrementAndGet(), snapshot, pnxExtra, custom);
            if (written != null) {
                entry.lastAsyncWrite = written;
            }
            return entry;
        });

        if (async) {
            final Runnable write = () -> {
                try {
                    saveOfflinePlayerDataInternal(snapshot, pnxExtra, custom, uuid);
                } catch (Exception e) {
                    log.error("Failed to save player data for {}", uuid, e);
                } finally {
                    this.completePlayerDataWrite(uuid);
                    written.complete(null);
                }
            };
            try {
                this.loginService.executePlayerData(write);
            } catch (RejectedExecutionException e) {
                // Shutting down: write on the caller rather than lose the data
                write.run();
            }
            return;
        }

        this.getScheduler().scheduleTask(InternalPlugin.INSTANCE, new Task() {
            final AtomicBoolean hasRun = new AtomicBoolean(false);

            @Override
            public void onRun(int currentTick) {
                this.onCancel();
            }

            @Override
            public void onCancel() {
                if (!hasRun.getAndSet(true)) {
                    try {
                        saveOfflinePlayerDataInternal(tag, pnxExtra, custom, uuid);
                    } finally {
                        completePlayerDataWrite(uuid);
                    }
                }
            }
        }, false);
    }

    private void completePlayerDataWrite(UUID uuid) {
        this.playerDataWrites.computeIfPresent(uuid, (_, writes) -> {
            writes.completed.incrementAndGet();
            return writes.idle() ? null : writes;
        });
    }

    /**
     * Marks that a login is about to preload this player's data, which keeps the save counters
     * of the player around until {@link #endPlayerDataPreload(UUID)}. Every call must be paired
     * with exactly one call to that method.
     */
    @ApiStatus.Internal
    public void beginPlayerDataPreload(UUID uuid) {
        this.playerDataWrites.compute(uuid, (_, writes) -> {
            final PlayerDataWrites entry = writes != null ? writes : new PlayerDataWrites();
            entry.preloads++;
            return entry;
        });
    }

    /**
     * Ends what {@link #beginPlayerDataPreload(UUID)} started.
     */
    @ApiStatus.Internal
    public void endPlayerDataPreload(UUID uuid) {
        this.playerDataWrites.computeIfPresent(uuid, (_, writes) -> {
            writes.preloads--;
            return writes.idle() ? null : writes;
        });
    }

    /**
     * Reads a player's stored data ahead of creating the player. Runs on the player data thread
     * of the {@link LoginService}, so it is ordered after every save requested before it. The
     * caller must have called {@link #beginPlayerDataPreload(UUID)} first.
     * <p>
     * Unlike {@link #getOfflinePlayerDataRecord(UUID, boolean)} this never creates data, since new
     * player data needs a safe spawn position from the world.
     *
     * @return the data, or {@code null} when a save requested earlier has not been written yet
     */
    @ApiStatus.Internal
    public @Nullable PreloadedPlayerData preloadPlayerData(UUID uuid) {
        final PlayerDataWrites writes = this.playerDataWrites.get(uuid);
        final long requested = writes != null ? writes.requested.get() : 0L;
        if (writes != null && writes.completed.get() != requested) {
            return null;
        }
        final PlayerDataRecord record = this.hasOfflinePlayerData(uuid)
            ? new PlayerDataRecord(this.getOfflinePlayerDataInternal(uuid, false),
                this.getOfflinePlayerExtraDataInternal(uuid), this.getOfflinePlayerCustomDataInternal(uuid))
            : null;
        return new PreloadedPlayerData(uuid, record, requested);
    }

    /**
     * The data a joining player is created from: the preloaded data, updated with every save of
     * that player requested since it was read, such as one from a {@code PlayerLoginEvent}
     * listener. Never reads storage or waits for a write, so it is safe on a level thread. Must be
     * called before the preload ends, see {@link #endPlayerDataPreload(UUID)}.
     *
     * @return {@code null} when the player has neither stored data nor a save requested
     */
    @Nullable PlayerDataRecord resolvePreloadedPlayerData(PreloadedPlayerData preloaded) {
        final PlayerDataRecord stored = preloaded.record();
        final PlayerDataWrites writes = this.playerDataWrites.get(preloaded.uuid());
        if (writes == null || writes.requested.get() == preloaded.writeCount()) {
            return stored;
        }

        final long since = preloaded.writeCount();
        final RequestedPlayerData latest = writes.latest;
        final CompoundTag nbt;
        if (latest.nbtAt() > since) {
            nbt = latest.nbt().copy();
            this.cleanupOfflinePlayerData(nbt);
        } else if (stored != null) {
            nbt = stored.nbt();
        } else {
            return null;
        }
        final CompoundTag pnxExtra = latest.pnxExtraAt() > since ? latest.pnxExtra().copy()
            : stored != null ? stored.pnxExtra() : new CompoundTag();
        final CompoundTag custom = latest.customAt() > since ? latest.custom().copy()
            : stored != null ? stored.custom() : new CompoundTag();
        return new PlayerDataRecord(nbt, pnxExtra, custom);
    }

    /**
     * Waits for the last save of this player queued on the player data thread, so a read that
     * follows sees it. Only this player's own write is waited for, not the whole queue. Saves
     * scheduled on the main thread are not waited for, since the caller may be the main thread
     * itself.
     */
    void awaitPlayerDataWrites(UUID uuid) {
        final PlayerDataWrites writes = this.playerDataWrites.get(uuid);
        final CompletableFuture<Void> pending = writes != null ? writes.lastAsyncWrite : null;
        if (pending == null || pending.isDone()) {
            return;
        }
        try {
            pending.get(PLAYER_DATA_WRITE_WAIT_MILLIS, TimeUnit.MILLISECONDS);
        } catch (TimeoutException e) {
            log.warn("Player data of {} was still being written after {} ms, it may load outdated",
                uuid, PLAYER_DATA_WRITE_WAIT_MILLIS);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        } catch (ExecutionException e) {
            log.error("Waiting for the player data of {} failed", uuid, e);
        }
    }

    /**
     * Whether preloaded data is still what storage holds, meaning no save of that player was
     * requested since it was read. Data whose preload has already ended is never current.
     */
    @ApiStatus.Internal
    public boolean isPreloadCurrent(PreloadedPlayerData preloaded) {
        final PlayerDataWrites writes = this.playerDataWrites.get(preloaded.uuid());
        return writes != null && writes.requested.get() == preloaded.writeCount();
    }

    private void saveOfflinePlayerDataInternal(CompoundTag tag, CompoundTag pnxExtra, CompoundTag custom, UUID uuid) {
        try {
            cleanupOfflinePlayerData(tag);

            try (WriteBatch batch = serverDataDB.createWriteBatch()) {
                batch.put(PlayerDataKeys.player(uuid), writeOfflinePlayerCompound(tag));

                writeOfflinePlayerSidecar(batch, PlayerDataKeys.pnxExtra(uuid), pnxExtra);
                writeOfflinePlayerSidecar(batch, PlayerDataKeys.custom(uuid), custom);

                serverDataDB.write(batch);
            }
        } catch (IOException e) {
            throw new UncheckedIOException(e);
        }
    }

    private static void writeOfflinePlayerSidecar(WriteBatch batch, byte[] key, CompoundTag tag) throws IOException {
        if (tag == null) return;

        if (tag.isEmpty()) {
            batch.delete(key);
        } else {
            batch.put(key, writeOfflinePlayerCompound(tag));
        }
    }

    private static byte[] writeOfflinePlayerCompound(CompoundTag tag) throws IOException {
        try (final ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
             final NBTOutputStream nbtOutputStream = NbtUtils.createGZIPWriter(outputStream)) {
            nbtOutputStream.writeTag(tag.toNetwork());
            nbtOutputStream.close();
            return outputStream.toByteArray();
        }
    }

    private void cleanupOfflinePlayerData(CompoundTag tag) {
        tag.remove("Colors", "PieceTintColors", "Skin");
    }

    private Player findPlayerByString(Function<Player, String> extractor, String name, boolean exact) {
        if (name == null) return null;
        String q = name.toLowerCase(Locale.ENGLISH);
        if (exact) {
            for (Player player : this.getOnlinePlayers().values()) {
                String value = extractor.apply(player);
                if (value != null && value.toLowerCase(Locale.ENGLISH).equals(q)) {
                    return player;
                }
            }
            return null;
        } else {
            Player found = null;
            int delta = Integer.MAX_VALUE;
            for (Player player : this.getOnlinePlayers().values()) {
                String value = extractor.apply(player);
                if (value == null) continue;
                String lower = value.toLowerCase(Locale.ENGLISH);
                if (lower.startsWith(q)) {
                    int curDelta = value.length() - q.length();
                    if (curDelta < delta) {
                        found = player;
                        delta = curDelta;
                    }
                    if (curDelta == 0) {
                        break;
                    }
                }
            }
            return found;
        }
    }

    private Player[] matchPlayersByString(Function<Player, String> extractor, String partialName) {
        if (partialName == null) return Player.EMPTY_ARRAY;
        String q = partialName.toLowerCase(Locale.ENGLISH);
        List<Player> matched = new ArrayList<>();
        for (Player player : this.getOnlinePlayers().values()) {
            String value = extractor.apply(player);
            if (value == null) continue;
            String lower = value.toLowerCase(Locale.ENGLISH);
            if (lower.equals(q)) {
                return new Player[]{player};
            } else if (lower.contains(q)) {
                matched.add(player);
            }
        }
        return matched.toArray(Player.EMPTY_ARRAY);
    }

    /**
     * Get an online player from the player name, this method is a fuzzy match and
     * will be returned as long as the player name has the name prefix.
     *
     * @param name player name
     * @return Player instance object, failed to get null
     */
    public Player getPlayer(String name) {
        return findPlayerByString(Player::getName, name, false);
    }

    /**
     * Get an online player from a player name, this method is an exact match and
     * returns when the player name string is identical.
     *
     * @param name player name
     * @return Player instance object, failed to get null
     */
    public Player getPlayerExact(String name) {
        return findPlayerByString(Player::getName, name, true);
    }

    /**
     * Specify a partial player name and return all players with or equal to that
     * name.
     *
     * @param partialName partial name
     * @return All players matched, if not matched then an empty array
     */
    public Player[] matchPlayer(String partialName) {
        return matchPlayersByString(Player::getName, partialName);
    }

    /**
     * Get an online player from the display name, this method is a fuzzy match and
     * will be returned as long as the player name has the name prefix.
     *
     * @param name display name
     * @return Player instance object, failed to get null
     */
    public Player getPlayerByDisplayName(String name) {
        return findPlayerByString(Player::getDisplayName, name, false);
    }

    /**
     * Get an online player from a display name, this method is an exact match and
     * returns when the player name string is identical.
     *
     * @param name display name
     * @return Player instance object, failed to get null
     */
    public Player getPlayerExactByDisplayName(String name) {
        return findPlayerByString(Player::getDisplayName, name, true);
    }

    /**
     * Specify a partial display name and return all players with or equal to that
     * name.
     *
     * @param partialName partial name
     * @return All players matched, if not matched then an empty array
     */
    public Player[] matchPlayerByDisplayName(String partialName) {
        return matchPlayersByString(Player::getDisplayName, partialName);
    }

    @ApiStatus.Internal
    public void removePlayer(Player player) {
        if (this.players.remove(player.getRawSocketAddress(), player)) {
            return;
        }

        for (InetSocketAddress socketAddress : new ArrayList<>(this.players.keySet())) {
            if (this.players.remove(socketAddress, player)) {
                break;
            }
        }
    }

    /**
     * Returns a live, unmodifiable view of the online players keyed by UUID - not a snapshot, so joins and quits are
     * reflected immediately. Iteration is weakly consistent and never throws {@link ConcurrentModificationException},
     * so it is safe from any thread; copy it if you need a stable set.
     *
     * @return an unmodifiable view of the online players
     */
    @UnmodifiableView
    public Map<UUID, Player> getOnlinePlayers() {
        return this.onlinePlayersView;
    }

    /**
     * Deletes all player data for the specified player name.
     *
     * @param name The player name to delete (case-insensitive)
     */
    public void deletePlayerData(String name) {
        try {
            byte[] nameKey = PlayerDataKeys.name(name);
            byte[] uuidBytes = serverDataDB.get(nameKey);

            if (uuidBytes != null && uuidBytes.length == 16) {
                ByteBuffer buffer = ByteBuffer.wrap(uuidBytes);
                UUID uuid = new UUID(buffer.getLong(), buffer.getLong());

                serverDataDB.delete(PlayerDataKeys.player(uuid));
                serverDataDB.delete(PlayerDataKeys.pnxExtra(uuid));
                serverDataDB.delete(PlayerDataKeys.custom(uuid));
                serverDataDB.delete(nameKey);

                log.info("{} player data deleted (UUID: {})", name, uuid);
            } else {
                log.warn("{} player not found or invalid UUID data", name);
            }
        } catch (Exception e) {
            log.error("Error deleting player data for {}", name, e);
        }
    }

    /**
     * Deletes all player data for the specified UUID.
     *
     * @param uuid The UUID of the player to delete
     */
    public void deletePlayerData(UUID uuid) {
        try {
            ByteBuffer buffer = ByteBuffer.allocate(16);
            buffer.putLong(uuid.getMostSignificantBits());
            buffer.putLong(uuid.getLeastSignificantBits());
            byte[] uuidBytes = buffer.array();

            serverDataDB.delete(PlayerDataKeys.player(uuid));
            serverDataDB.delete(PlayerDataKeys.pnxExtra(uuid));
            serverDataDB.delete(PlayerDataKeys.custom(uuid));

            try (DBIterator iterator = serverDataDB.iterator()) {
                iterator.seekToFirst();

                while (iterator.hasNext()) {
                    Map.Entry<byte[], byte[]> entry = iterator.next();
                    byte[] key = entry.getKey();
                    byte[] value = entry.getValue();

                    if (PlayerDataKeys.isName(key) && Arrays.equals(value, uuidBytes)) {
                        serverDataDB.delete(key);
                        log.info("Deleted name mapping for {}", PlayerDataKeys.readName(key));
                        break;
                    }
                }
            }
        } catch (Exception e) {
            log.error("Error deleting player data for UUID {}", uuid, e);
        }
    }

    // endregion

    // region constants

    /**
     * @return The name of server
     */
    public String getName() {
        return "PowerNukkitX";
    }

    public String getNukkitVersion() {
        return PowerNukkitX.VERSION;
    }

    public String getBStatsNukkitVersion() {
        return PowerNukkitX.VERSION;
    }

    public String getGitCommit() {
        return PowerNukkitX.GIT_COMMIT;
    }

    public String getCodename() {
        return PowerNukkitX.CODENAME;
    }

    public String getVersion() {
        return NetworkConstants.CODEC.getMinecraftVersion();
    }

    public String getApiVersion() {
        return PowerNukkitX.API_VERSION;
    }

    // endregion

    public String getFilePath() {
        return filePath;
    }

    public String getDataPath() {
        return dataPath;
    }

    public String getPluginPath() {
        return pluginPath;
    }

    /**
     * @return server UUID
     */
    public UUID getServerUniqueId() {
        return this.serverID;
    }

    public MainLogger getLogger() {
        return MainLogger.getLogger();
    }

    public EntityMetadataStore getEntityMetadata() {
        return entityMetadata;
    }

    public PlayerMetadataStore getPlayerMetadata() {
        return playerMetadata;
    }

    public LevelMetadataStore getLevelMetadata() {
        return levelMetadata;
    }

    public ResourcePackManager getResourcePackManager() {
        return resourcePackManager;
    }

    public FreezableArrayManager getFreezableArrayManager() {
        return freezableArrayManager;
    }

    @NotNull
    public PositionTrackingService getPositionTrackingService() {
        return positionTrackingService;
    }

    // region crafting a recipe

    /**
     * Send a recipe list packet to a player.
     *
     * @param player the player
     */
    public void sendRecipeList(Player player) {
        player.sendPacketImmediately(Registries.RECIPE.getCraftingPacket());
    }

    /**
     * Register the recipe to recipe manager
     *
     * @param recipe the recipe
     */
    public void addRecipe(Recipe recipe) {
        Registries.RECIPE.register(recipe);
    }

    public RecipeRegistry getRecipeRegistry() {
        return Registries.RECIPE;
    }

    // endregion

    // region levels

    /**
     * @return Get all the game world
     */
    public Map<Integer, Level> getLevels() {
        return levels;
    }

    /**
     * @return Get the default overworld
     */
    public Level getDefaultLevel() {
        return defaultLevel;
    }

    /**
     * Set default overworld
     */
    public void setDefaultLevel(Level defaultLevel) {
        if (defaultLevel == null || (this.isLevelLoaded(defaultLevel.getName()) && defaultLevel != this.defaultLevel)) {
            this.defaultLevel = defaultLevel;
        }
    }

    /**
     * @param name the level name
     * @return Is the world already loaded
     */
    public boolean isLevelLoaded(String name) {
        return this.getLevelByName(name) != null;
    }

    /**
     * Get world from world id, 0 OVERWORLD 1 NETHER 2 THE_END
     *
     * @param levelId world id
     * @return level The Level instance
     */
    public Level getLevel(int levelId) {
        if (this.levels.containsKey(levelId)) {
            return this.levels.get(levelId);
        }
        return null;
    }

    /**
     * Get world from world name, {@code overworld nether the_end}
     *
     * @param name world name
     * @return level instance
     */
    public Level getLevelByName(String name) {
        for (Level level : this.levelArray) {
            if (level.getName().equals(name)) {
                return level;
            }
        }
        return null;
    }

    public boolean unloadLevel(Level level) {
        return this.unloadLevel(level, false);
    }

    /**
     * Unloads the level
     *
     * @param level       the level
     * @param forceUnload Whether force to unload.
     * @return was the uninstallation successful
     */
    public boolean unloadLevel(Level level, boolean forceUnload) {
        if (level == this.getDefaultLevel() && !forceUnload) {
            throw new IllegalStateException(
                "The default level cannot be unloaded while running, please switch levels.");
        }
        return level.unload(forceUnload);

    }

    public @Nullable LevelConfig getLevelConfig(String levelFolderName) {
        if (Objects.equals(levelFolderName.trim(), "")) {
            throw new LevelException("Invalid empty level name");
        }
        String path;
        if (levelFolderName.contains("/") || levelFolderName.contains("\\")) {
            path = levelFolderName;
        } else {
            path = new File(this.getDataPath(), "worlds/" + levelFolderName).getAbsolutePath();
        }
        Path jpath = Path.of(path);
        path = jpath.toString();
        if (!jpath.toFile().exists()) {
            log.warn(this.getLanguage().tr("nukkit.level.notFound", levelFolderName));
            return null;
        }

        File config = jpath.resolve("config.json").toFile();
        LevelConfig levelConfig;
        if (config.exists()) {
            try {
                levelConfig = JSONUtils.from(config, LevelConfig.class);
                FileUtils.write(config, JSONUtils.toPretty(levelConfig), StandardCharsets.UTF_8);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        } else {
            // verify the provider
            LevelProviderFactory provider = LevelProviderManager.getProviderFactory(path);
            if (provider == null) {
                log.error(this.getLanguage().tr("nukkit.level.loadError", levelFolderName, "Unknown provider"));
                return null;
            }
            Map<Integer, LevelConfig.GeneratorConfig> map = new HashMap<>();
            long seed = System.currentTimeMillis();

            map.put(0, new LevelConfig.GeneratorConfig("normal", seed, false, LevelConfig.AntiXrayMode.LOW, true,
                DimensionEnum.OVERWORLD.getDimensionData(), Collections.emptyMap()));
            map.put(1, new LevelConfig.GeneratorConfig("nether", seed, false, LevelConfig.AntiXrayMode.LOW, true,
                DimensionEnum.NETHER.getDimensionData(), Collections.emptyMap()));
            map.put(2, new LevelConfig.GeneratorConfig("the_end", seed, false, LevelConfig.AntiXrayMode.LOW, true,
                DimensionEnum.THE_END.getDimensionData(), Collections.emptyMap()));
            levelConfig = new LevelConfig(provider.getName(), true, map);
            try {
                config.createNewFile();
                FileUtils.write(config, JSONUtils.toPretty(levelConfig), StandardCharsets.UTF_8);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
        return levelConfig;
    }

    /**
     * Loads the selected level by its folder name
     *
     * @param levelFolderName the level folder name
     * @return whether load success
     */
    public boolean loadLevel(String levelFolderName) {
        return loadLevelInternal(levelFolderName);
    }

    private boolean loadLevelInternal(String levelFolderName) {
        LevelConfig levelConfig = getLevelConfig(levelFolderName);
        if (levelConfig == null) return false;

        String path;
        if (levelFolderName.contains("/") || levelFolderName.contains("\\")) {
            path = levelFolderName;
        } else {
            path = new File(this.getDataPath(), "worlds/" + levelFolderName).getAbsolutePath();
        }
        String pathS = Path.of(path).toString();

        LevelProviderFactory provider = LevelProviderManager.getProviderFactory(pathS);
        if (provider == null && "leveldb".equalsIgnoreCase(levelConfig.format())) {
            return false;
        }
        if (provider == null) {
            provider = LevelProviderManager.getProviderFactoryByName(levelConfig.format());
        }

        Map<Integer, LevelConfig.GeneratorConfig> generators = levelConfig.generators();

        for (var entry : generators.entrySet()) {
            String levelName = levelFolderName
                + (generators.size() > 1 ? entry.getValue().dimensionData().getSuffix() : "");
            if (this.isLevelLoaded(levelName)) {
                return true;
            }
            Level level;
            try {
                if (provider == null) {
                    log.error(this.getLanguage().tr("nukkit.level.loadError", levelFolderName, "the level does not exist"));
                    return false;
                }

                level = new Level(this, levelName, pathS, generators.size(), provider, entry.getValue());
            } catch (Exception e) {
                log.error(this.getLanguage().tr("nukkit.level.loadError", levelFolderName, e.getMessage()), e);
                return false;
            }

            level.advanceWorldStartCount();

            this.levels.put(level.getId(), level);
            level.initLevel();
            this.getPluginManager().callEvent(new LevelLoadEvent(level));
            level.setTickRate(getSettings().levelSettings().baseTickRate());
        }
        if (tickCounter != 0) { // Update world enum when loading
            WorldCommand.WORLD_NAME_ENUM.updateSoftEnum();
        }
        return true;
    }

    /**
     * Generates a level with selected name and LevelConfig options.
     *
     * @param name        The level name
     * @param levelConfig The level config
     * @return boolean
     */
    public boolean generateLevel(String name, @Nullable LevelConfig levelConfig) {
        if (name.isBlank()) {
            return false;
        }
        String path;
        if (name.contains("/") || name.contains("\\")) {
            path = name;
        } else {
            path = this.getDataPath() + "worlds/" + name + "/";
        }

        Path jpath = Path.of(path);
        path = jpath.toString();
        File config = jpath.resolve("config.json").toFile();
        if (config.exists()) {
            try {
                levelConfig = JSONUtils.from(new FileReader(config), LevelConfig.class);
                FileUtils.write(config, JSONUtils.toPretty(levelConfig), StandardCharsets.UTF_8);
            } catch (Exception e) {
                log.error("The levelConfig is not exists under the {} path", path);
                return false;
            }
        } else if (levelConfig != null) {
            try {
                jpath.toFile().mkdirs();
                config.createNewFile();
                FileUtils.write(config, JSONUtils.toPretty(levelConfig), StandardCharsets.UTF_8);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        } else {
            log.error("The levelConfig is not specified and no config.json exists under the {} path", path);
            return false;
        }
        if (levelConfig == null) {
            log.error("Could not load level " + name, new LevelException("Level config is not a valid"));
            return false;
        }
        boolean freshLevelDBStorage = "leveldb".equalsIgnoreCase(levelConfig.format()) && !jpath.resolve("db").toFile().exists();
        var generatorEntries = levelConfig.generators().entrySet().stream()
                .sorted(Comparator.comparingInt(entry -> entry.getValue().dimensionData().getDimensionId() == Level.DIMENSION_OVERWORLD ? 0 : 1))
                .toList();
        for (var entry : generatorEntries) {
            LevelConfig.GeneratorConfig generatorConfig = entry.getValue();
            var provider = LevelProviderManager.getProviderFactoryByName(levelConfig.format());
            if (provider == null) {
                log.error(this.getLanguage().tr("nukkit.level.generationError", name,
                    "Unknown provider " + levelConfig.format()));
                return false;
            }
            Level level;
            try {
                provider.generate(path, name, generatorConfig);
                String levelName = name
                    + (levelConfig.generators().size() > 1 ? entry.getValue().dimensionData().getSuffix() : "");
                if (this.isLevelLoaded(levelName)) {
                    log.warn("level {} has already been loaded!", levelName);
                    continue;
                }
                level = new Level(this, levelName, path, levelConfig.generators().size(), provider, generatorConfig);

                level.advanceWorldStartCount();

                this.getLevels().put(level.getId(), level);
                level.initLevel();
                level.setTickRate(getSettings().levelSettings().baseTickRate());
                this.getPluginManager().callEvent(new LevelInitEvent(level));
                this.getPluginManager().callEvent(new LevelLoadEvent(level));
            } catch (Exception e) {
                log.error(this.getLanguage().tr("nukkit.level.generationError", name, Utils.getExceptionMessage(e)), e);
                return false;
            }
        }

        if (freshLevelDBStorage && generatorEntries.size() != 0) {
            try {
                LevelDBProvider.completeGeneration(path, levelConfig);
            } catch (Exception e) {
                log.error(this.getLanguage().tr("nukkit.level.generationError", name, Utils.getExceptionMessage(e)), e);
                return false;
            }
        }
        return true;
    }
    // endregion

    // region Ban, OP and Whitelist
    public BanList getNameBans() {
        return this.banByName;
    }

    public BanList getIPBans() {
        return this.banByIP;
    }

    public void addOp(String name) {
        this.operators.set(name.toLowerCase(Locale.ENGLISH), true);
        Player player = this.getPlayerExact(name);
        if (player != null) {
            player.recalculatePermissions();
            player.getAdventureSettings().onOpChange(true);
            player.getAdventureSettings().update();
            player.syncAvailableCommands();
        }
        this.operators.save(true);
    }

    public void removeOp(String name) {
        this.operators.remove(name.toLowerCase(Locale.ENGLISH));
        Player player = this.getPlayerExact(name);
        if (player != null) {
            player.recalculatePermissions();
            player.getAdventureSettings().onOpChange(false);
            player.getAdventureSettings().update();
            player.syncAvailableCommands();
        }
        this.operators.save();
    }

    public void addWhitelist(String name) {
        this.whitelist.set(name.toLowerCase(Locale.ENGLISH), true);
        this.whitelist.save(true);
    }

    public void removeWhitelist(String name) {
        this.whitelist.remove(name.toLowerCase(Locale.ENGLISH));
        this.whitelist.save(true);
    }

    public boolean isWhitelisted(String name) {
        return !this.hasWhitelist() || this.operators.exists(name, true) || this.whitelist.exists(name, true);
    }

    public String getWhitelistMessage() {
        return this.settings.baseSettings().allowListMessage();
    }

    public void setWhitelistMessage(String message) {
        this.settings.baseSettings().allowListMessage(message);
        this.settings.save();
    }

    public boolean isOp(String name) {
        return name != null && this.operators.exists(name, true);
    }

    public Config getWhitelist() {
        return whitelist;
    }

    public Config getOps() {
        return operators;
    }

    public void reloadWhitelist() {
        this.whitelist.reload();
    }

    // endregion

    // region configs

    public int getMaxPlayers() {
        return maxPlayers;
    }

    /**
     * Set the players count is allowed
     *
     * @param maxPlayers the max players
     */
    public void setMaxPlayers(int maxPlayers) {
        this.maxPlayers = maxPlayers;
        this.getNetwork().updatePong(this.getNetwork().getPong().maximumPlayerCount(maxPlayers));
    }

    /**
     * @return The server port
     */
    public int getPort() {
        return this.settings.baseSettings().port();
    }

    /**
     * @return The server view distance
     */
    public int getViewDistance() {
        return this.settings.gameplaySettings().viewDistance();
    }

    /**
     * @return The server ip
     */
    public String getIp() {
        return this.settings.baseSettings().ip();
    }

    /**
     * @return Does the server automatically save
     */
    public boolean getAutoSave() {
        return this.autoSave;
    }

    /**
     * Set server autosave
     *
     * @param autoSave Whether to save automatically
     */
    public void setAutoSave(boolean autoSave) {
        this.autoSave = autoSave;
        for (Level level : this.levelArray) {
            level.setAutoSave(this.autoSave);
        }
    }

    /**
     * Get the gamemode of the server
     *
     * @return gamemode id
     */
    public int getGamemode() {
        return this.settings.gameplaySettings().gamemode() & 0b11;

    }

    public boolean getForceGamemode() {
        return this.settings.gameplaySettings().forceGamemode();
    }

    /**
     * default {@code direct=false}
     *
     * @see #getGamemodeString(int, boolean)
     */
    public static String getGamemodeString(int mode) {
        return getGamemodeString(mode, false);
    }

    /**
     * Get game mode string from gamemode id.
     *
     * @param mode   gamemode id
     * @param direct If true, the string is returned directly, and if false, the
     *               hard-coded string representing the game mode is returned.
     * @return Gamemode string
     */
    public static String getGamemodeString(int mode, boolean direct) {
        return switch (mode) {
            case Player.SURVIVAL -> direct ? "Survival" : "%gameMode.survival";
            case Player.CREATIVE -> direct ? "Creative" : "%gameMode.creative";
            case Player.ADVENTURE -> direct ? "Adventure" : "%gameMode.adventure";
            case Player.SPECTATOR -> direct ? "Spectator" : "%gameMode.spectator";
            default -> "UNKNOWN";
        };
    }

    /**
     * Get gamemode from string
     *
     * @param gamemodeString A string representing the game mode, e.g., 0 for
     *                       survival...
     * @return gamemode id
     */
    public static int getGamemodeFromString(String gamemodeString) {
        return switch (gamemodeString.trim().toLowerCase(Locale.ENGLISH)) {
            case "0", "survival", "s" -> Player.SURVIVAL;
            case "1", "creative", "c" -> Player.CREATIVE;
            case "2", "adventure", "a" -> Player.ADVENTURE;
            case "3", "spectator", "spc", "view", "v" -> Player.SPECTATOR;
            default -> -1;
        };
    }

    /**
     * Get game difficulty from string
     *
     * @param difficultyString A string representing the game difficulty, e.g.,
     *                         0,peaceful...
     * @return game difficulty id
     */
    public static int getDifficultyFromString(String difficultyString) {
        return switch (difficultyString.trim().toLowerCase(Locale.ENGLISH)) {
            case "0", "peaceful", "p" -> 0;
            case "1", "easy", "e" -> 1;
            case "2", "normal", "n" -> 2;
            case "3", "hard", "h" -> 3;
            default -> -1;
        };
    }

    /**
     * Get server game difficulty
     *
     * @return game difficulty id
     */
    public int getDifficulty() {
        return this.settings.gameplaySettings().difficulty();
    }

    /**
     * Set server game difficulty
     *
     * @param difficulty game difficulty id
     */
    public void setDifficulty(int difficulty) {
        int value = difficulty;
        if (value < 0)
            value = 0;
        if (value > 3)
            value = 3;
        this.settings.gameplaySettings().difficulty(value);
        this.settings.save();
    }

    /**
     * @return Whether to start server whitelist
     */
    public boolean hasWhitelist() {
        return this.settings.baseSettings().allowList();
    }

    /**
     * Enable or disable the server whitelist and persist the change.
     *
     * @param value whether the whitelist should be enforced
     */
    public void setWhitelist(boolean value) {
        this.settings.baseSettings().allowList(value);
        this.settings.save();
    }

    /**
     * @return Get server birth point protection radius
     */
    public int getSpawnRadius() {
        return this.settings.playerSettings().spawnRadius();
    }

    /**
     * @return Whether the server is in hardcore mode
     */
    public boolean isHardcore() {
        return this.settings.gameplaySettings().hardcore();
    }

    /**
     * @return Get default gamemode
     */
    public int getDefaultGamemode() {
        if (this.defaultGamemode == Integer.MAX_VALUE) {
            this.defaultGamemode = this.getGamemode();
        }
        return this.defaultGamemode;
    }

    /**
     * Set the default gamemode for the server.
     *
     * @param defaultGamemode the default gamemode
     */
    public void setDefaultGamemode(int defaultGamemode) {
        this.defaultGamemode = defaultGamemode;
        this.getNetwork().updatePong(this.getNetwork().getPong().gameType(Server.getGamemodeString(defaultGamemode, true)));
    }

    /**
     * @return Get server motd
     */
    public String getMotd() {
        return this.settings.baseSettings().motd();
    }

    /**
     * Set the motd of server.
     *
     * @param motd the motd content
     */
    public void setMotd(String motd) {
        this.settings.baseSettings().motd(motd);
        this.settings.save();
        this.getNetwork().updatePong(this.getNetwork().getPong().motd(motd));
    }

    /**
     * @return Get the server subheading
     */
    public String getSubMotd() {
        String subMotd = this.settings.baseSettings().subMotd();
        if (subMotd.isEmpty()) {
            subMotd = "powernukkitx.org";
        }
        return subMotd;
    }

    /**
     * Set the sub motd of server.
     *
     * @param subMotd the sub motd
     */
    public void setSubMotd(String subMotd) {
        this.settings.baseSettings().subMotd(subMotd);
        this.settings.save();
        this.getNetwork().updatePong(this.getNetwork().getPong().subMotd(subMotd));
    }

    /**
     * @return Whether to force the use of server resource pack
     */
    public boolean getForceResources() {
        return this.settings.gameplaySettings().forceResources();
    }

    /**
     * @return Whether to force the use of the server resource pack while allowing
     * the loading of the client resource pack
     */
    public boolean getForceResourcesAllowOwnPacks() {
        return this.settings.gameplaySettings().allowClientPacks();
    }

    private LangCode mapInternalLang(String langName) {
        return switch (langName) {
            case "bra" -> LangCode.valueOf("pt_BR");
            case "chs" -> LangCode.valueOf("zh_CN");
            case "cht" -> LangCode.valueOf("zh_TW");
            case "cze" -> LangCode.valueOf("cs_CZ");
            case "deu" -> LangCode.valueOf("de_DE");
            case "fil" -> LangCode.valueOf("tl_PH");
            case "fin" -> LangCode.valueOf("fi_FI");
            case "eng" -> LangCode.valueOf("en_US");
            case "fra" -> LangCode.valueOf("fr_FR");
            case "idn" -> LangCode.valueOf("id_ID");
            case "jpn" -> LangCode.valueOf("ja_JP");
            case "kor" -> LangCode.valueOf("ko_KR");
            case "ltu" -> LangCode.valueOf("lt_LT");
            case "pol" -> LangCode.valueOf("pl_PL");
            case "rus" -> LangCode.valueOf("ru_RU");
            case "spa" -> LangCode.valueOf("es_ES");
            case "tur" -> LangCode.valueOf("tr_TR");
            case "ukr" -> LangCode.valueOf("uk_UA");
            case "vie" -> LangCode.valueOf("vi_VN");
            default -> throw new IllegalArgumentException();
        };
    }

    public BaseLang getLanguage() {
        return baseLang;
    }

    public LangCode getLanguageCode() {
        return baseLangCode;
    }

    public ScheduledExecutorService getLevelTickExecutor() {
        return levelTickExecutor;
    }

    /**
     * Whether levels tick on their own dedicated threads (true) or on the main server
     * loop (false). Fixed at boot from {@code level-settings.levelThread} — runtime
     * changes to the setting are deliberately ignored so both tick paths can never be
     * active at once.
     */
    public boolean isLevelThreadMode() {
        return levelThreadMode;
    }

    public ServerSettings getSettings() {
        return settings;
    }

    public ProxyAuthProvider getProxyAuthProvider() {
        return proxyAuthProvider;
    }

    public void setProxyAuthProvider(ProxyAuthProvider proxyAuthProvider) {
        this.proxyAuthProvider = proxyAuthProvider;
    }

    public boolean canLogPacket(Class<? extends BedrockPacket> clazz) {
        if (!this.getSettings().debugSettings().mode()) // ignored mode
            return !this.getSettings().debugSettings().packetList().contains(clazz.getSimpleName());
        else // allow mode
            return this.getSettings().debugSettings().packetList().contains(clazz.getSimpleName());
    }

    // endregion

    // region threading

    /**
     * Checks the current thread against the expected primary thread for the
     * server.
     * <p>
     * <b>Note:</b> this method should not be used to indicate the current
     * synchronized state of the runtime. A current thread matching the main
     * thread indicates that it is synchronized, but a mismatch does not
     * preclude the same assumption.
     *
     * @return true if the current thread matches the expected primary thread,
     * false otherwise
     */
    public final boolean isPrimaryThread() {
        return (Thread.currentThread() == currentThread);
    }

    public Thread getPrimaryThread() {
        return currentThread;
    }

    public ServerScheduler getScheduler() {
        return scheduler;
    }

    public ForkJoinPool getComputeThreadPool() {
        return computeThreadPool;
    }

    /**
     * Executor that loads chunks from storage for {@link Level#getChunkAsync(int, int, boolean)}.
     * Kept apart from the plugin {@link ServerScheduler#getAsyncTaskThreadPool() async pool}, which
     * grows a thread per task, and from the compute pool, which world generation saturates.
     */
    @ApiStatus.Internal
    public ThreadPoolExecutor getChunkIoExecutor() {
        return chunkIoExecutor;
    }

    @ApiStatus.Internal
    public LoginService getLoginService() {
        return loginService;
    }

    /**
     * Returns the global adaptive chunk publication controller.
     *
     * @return chunk publication controller
     */
    public ChunkPublisherBudgetController getChunkPublisherBudgetController() {
        return chunkPublisherBudgetController;
    }

    public boolean allowVibrantVisuals() {
        return settings.gameplaySettings().allowVibrantVisuals();
    }

    public List<ExperimentToggle> getExperiments() {
        return experiments;
    }

    public static String getDynamicPropertyRoot() {
        return DynamicProperties.ROOT;
    }

    public static String getDefaultDynamicPropertiesGroupUUID() {
        return DP_DEFAULT_GROUP_UUID;
    }

    private static void initializeDefaultDynamicPropertiesGroupUUID(String configuredUUID, String persistedUUID) {
        DP_DEFAULT_GROUP_UUID = !configuredUUID.isEmpty() ? configuredUUID
            : persistedUUID != null ? persistedUUID : UUID.randomUUID().toString();
    }

    public static int getDynamicPropertiesMaxStringBytes() {
        return DynamicProperties.MAX_STRING_BYTES;
    }

    public static double getDynamicPropertiesNumberAbsMax() {
        return DynamicProperties.NUMBER_ABS_MAX;
    }

    /**
     * Returns the server-scoped dynamic properties.
     *
     * @return server dynamic properties
     */
    public DynamicProperties getDynamicProperties() {
        return dynamicProperties;
    }

    /**
     * Remove a DynamicProperty by key id.
     *
     * @param key the key id of the DynamicProperty
     */
    public Server removeDynamicProperty(String key) {
        dynamicProperties.remove(DP_DEFAULT_GROUP_UUID, key);
        return this;
    }

    /**
     * Remove all DynamicProperties in the world.
     */
    public Server clearDynamicProperties() {
        dynamicProperties.clear(DP_DEFAULT_GROUP_UUID);
        return this;
    }

    /**
     * Set a double int DynamicProperty.
     *
     * @param key   the key id of the DynamicProperty
     * @param value the double int value of the DynamicProperty
     */
    public Server setDynamicProperty(String key, Double value) {
        dynamicProperties.set(DP_DEFAULT_GROUP_UUID, key, value);
        return this;
    }

    /**
     * Set an int DynamicProperty.
     *
     * @param key   the key id of the DynamicProperty
     * @param value the int value of the DynamicProperty
     */
    public Server setDynamicProperty(String key, Integer value) {
        return setDynamicProperty(key, value == null ? null : value.doubleValue());
    }

    /**
     * Set an int DynamicProperty.
     *
     * @param key   the key id of the DynamicProperty
     * @param value the int value of the DynamicProperty
     */
    public Server setDynamicProperty(String key, Float value) {
        return setDynamicProperty(key, value == null ? null : value.doubleValue());
    }

    /**
     * Set a boolean DynamicProperty.
     *
     * @param key  the key id of the DynamicProperty
     * @param bool the bool value of the DynamicProperty
     */
    public Server setDynamicProperty(String key, Boolean bool) {
        dynamicProperties.set(DP_DEFAULT_GROUP_UUID, key, bool);
        return this;
    }

    /**
     * Set a string DynamicProperty.
     *
     * @param key    the key id of the DynamicProperty
     * @param string the string value of the DynamicProperty
     */
    public Server setDynamicProperty(String key, String string) {
        dynamicProperties.set(DP_DEFAULT_GROUP_UUID, key, string);
        return this;
    }

    /**
     * Set a Vec3 DynamicProperty.
     *
     * @param key  the key id of the DynamicProperty
     * @param vec3 the vec3 value of the DynamicProperty
     */
    public Server setVec3DynamicProperty(String key, Vector3 vec3) {
        dynamicProperties.setVec3(DP_DEFAULT_GROUP_UUID, key, vec3);
        return this;
    }

    /**
     * Set a Vec3 DynamicProperty.
     *
     * @param key the key id of the DynamicProperty
     * @param xyz a map with keys "x","y","z" and numeric values, e.g. {x: 400, y:
     *            60, z: 300}
     */
    public Server setVec3DynamicProperty(String key, Map<String, Number> xyz) {
        if (xyz == null)
            return removeDynamicProperty(key);

        Number nx = xyz.get("x"), ny = xyz.get("y"), nz = xyz.get("z");
        if (nx == null || ny == null || nz == null) {
            log.warn("DynamicProperty '{}' rejected: vec3 map must contain numeric keys 'x','y','z'", key);
            return this;
        }

        // Delegate to the Vector3 overload (keeps validation + storage consistent)
        return setVec3DynamicProperty(key, new Vector3(nx.doubleValue(), ny.doubleValue(), nz.doubleValue()));
    }

    /**
     * Get a double int DynamicProperty.
     *
     * @param key the key id of the DynamicProperty
     * @return the double int value or null if not available.
     */
    public Double getDoubleDynamicProperty(String key) {
        return dynamicProperties.getDouble(DP_DEFAULT_GROUP_UUID, key);
    }

    /**
     * Get a double int DynamicProperty.
     *
     * @param key          the key id of the DynamicProperty
     * @param defaultValue the default value to be returned if null.
     * @return the double int value or defaultValue if not available.
     */
    public Double getDoubleDynamicProperty(String key, double defaultValue) {
        Double d = getDoubleDynamicProperty(key);
        return (d != null) ? d : defaultValue;
    }

    /**
     * Get an int DynamicProperty.
     *
     * @param key the key id of the DynamicProperty
     * @return the int value or defaultValue if not available.
     */
    public Integer getIntDynamicProperty(String key) {
        Double d = getDoubleDynamicProperty(key);
        if (d == null)
            return null;
        return (int) Math.floor(d);
    }

    /**
     * Get an int DynamicProperty.
     *
     * @param key          the key id of the DynamicProperty
     * @param defaultValue the default value to be returned if null.
     * @return the int value or defaultValue if not available.
     */
    public int getIntDynamicProperty(String key, int defaultValue) {
        Integer i = getIntDynamicProperty(key);
        return (i != null) ? i : defaultValue;
    }

    /**
     * Get a float DynamicProperty.
     *
     * @param key the key id of the DynamicProperty
     * @return the float value or null if not available.
     */
    public Float getFloatDynamicProperty(String key) {
        Double d = getDoubleDynamicProperty(key);
        if (d == null)
            return null;
        return d.floatValue();
    }

    /**
     * Get a float DynamicProperty.
     *
     * @param key          the key id of the DynamicProperty
     * @param defaultValue the default value to be returned if null.
     * @return the float value or defaultValue if not available.
     */
    public float getFloatDynamicProperty(String key, float defaultValue) {
        Float f = getFloatDynamicProperty(key);
        return (f != null) ? f : defaultValue;
    }

    /**
     * Get a boolean DynamicProperty.
     *
     * @param key the key id of the DynamicProperty
     * @return the bool value or false if not available.
     */
    public Boolean getBoolDynamicProperty(String key) {
        return dynamicProperties.getBoolean(DP_DEFAULT_GROUP_UUID, key);
    }

    /**
     * Get a boolean DynamicProperty.
     *
     * @param key          the key id of the DynamicProperty
     * @param defaultValue the default value to be returned if null.
     * @return the bool value or defaultValue if not available.
     */
    public boolean getBoolDynamicProperty(String key, boolean defaultValue) {
        Boolean b = getBoolDynamicProperty(key);
        return (b != null) ? b : defaultValue;
    }

    /**
     * Get a string DynamicProperty.
     *
     * @param key the key id of the DynamicProperty
     * @return the bool value or null if not available.
     */
    public String getStringDynamicProperty(String key) {
        return dynamicProperties.getString(DP_DEFAULT_GROUP_UUID, key);
    }

    /**
     * Get a string DynamicProperty.
     *
     * @param key          the key id of the DynamicProperty
     * @param defaultValue the default value to be returned if null.
     * @return the string value or defaultValue if not available.
     */
    public String getStringDynamicProperty(String key, String defaultValue) {
        String s = getStringDynamicProperty(key);
        return (s != null) ? s : defaultValue;
    }

    /**
     * Get a vec3 DynamicProperty.
     *
     * @param key the key id of the DynamicProperty
     * @return the bool value or null if not available.
     */
    public Vector3 getVec3DynamicProperty(String key) {
        return dynamicProperties.getVec3(DP_DEFAULT_GROUP_UUID, key);
    }

    // Dynamic Properties Helpers start
    private CompoundTag readServerDynamicProperties() {
        byte[] bytes = serverDataDB.get(ServerDBStorageFormat.SERVER_DATA_DYNAMIC_PROPERTIES_KEY);
        if (bytes == null) return new CompoundTag();

        try (var inputStream = new ByteArrayInputStream(bytes);
             var nbtInputStream = NbtUtils.createReaderLE(inputStream)) {
            return CompoundTag.fromNetwork((NbtMap) nbtInputStream.readTag());
        } catch (IOException e) {
            throw new UncheckedIOException("Failed to read server Dynamic Properties", e);
        }
    }

    private void writeServerDynamicProperties(CompoundTag root) {
        try (var outputStream = new ByteArrayOutputStream();
             var nbtOutputStream = NbtUtils.createWriterLE(outputStream)) {
            nbtOutputStream.writeTag(root.toNetwork());
            serverDataDB.put(ServerDBStorageFormat.SERVER_DATA_DYNAMIC_PROPERTIES_KEY, outputStream.toByteArray());
        } catch (IOException e) {
            throw new UncheckedIOException("Failed to write server Dynamic Properties", e);
        }
    }
    // Dynamic Properties Helpers end


    // TODO: It will block NukkitConsole and cannot be turned off.
    private class ConsoleThread extends Thread implements InterruptibleThread {
        public ConsoleThread() {
            super("Console Thread");
        }

        @Override
        public void run() {
            console.start();
        }
    }

    private static class ComputeThread extends ForkJoinWorkerThread {
        /**
         * Creates a ForkJoinWorkerThread operating in the given pool.
         *
         * @param pool the pool this thread works in
         * @throws NullPointerException if the pool is null
         */
        ComputeThread(ForkJoinPool pool, AtomicInteger threadCount) {
            super(pool);
            this.setName("ComputeThreadPool-thread-" + threadCount.getAndIncrement());
        }
    }

    private static class ComputeThreadPoolThreadFactory implements ForkJoinPool.ForkJoinWorkerThreadFactory {
        private static final AtomicInteger threadCount = new AtomicInteger(0);

        public ForkJoinWorkerThread newThread(ForkJoinPool pool) {
            return new ComputeThread(pool, threadCount);
        }
    }

    // endregion

}
