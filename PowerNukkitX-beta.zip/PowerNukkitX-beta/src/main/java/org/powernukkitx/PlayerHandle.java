package org.powernukkitx;

import org.powernukkitx.block.Block;
import org.powernukkitx.dialog.window.FormWindowDialog;
import org.powernukkitx.entity.Entity;
import org.powernukkitx.event.entity.EntityDamageEvent;
import org.powernukkitx.form.window.Form;
import org.powernukkitx.inventory.Inventory;
import org.powernukkitx.level.Level;
import org.powernukkitx.level.Location;
import org.powernukkitx.level.Position;
import org.powernukkitx.math.BlockFace;
import org.powernukkitx.math.BlockVector3;
import org.powernukkitx.math.Vector3;
import org.powernukkitx.network.process.auth.ClientChainData;
import org.powernukkitx.network.security.PacketRateLimiter;
import org.powernukkitx.scheduler.AsyncTask;
import org.powernukkitx.utils.DummyBossBar;

import org.cloudburstmc.protocol.bedrock.data.PlayerBlockActionData;
import org.cloudburstmc.protocol.bedrock.packet.BedrockPacket;

import org.jetbrains.annotations.NotNull;
import com.github.benmanes.caffeine.cache.Cache;
import com.google.common.collect.BiMap;

import java.net.InetSocketAddress;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * A PlayerHandle is used to access a player's protected data.
 */
public final class PlayerHandle {
    public final @NotNull Player player;
    public final @NotNull PacketRateLimiter packetRateLimiter;

    public PlayerHandle(@NotNull Player player) {
        this.player = player;
        this.packetRateLimiter = new PacketRateLimiter(
                Server.getInstance().getSettings().networkSettings().rateLimitSettings()
        );
    }

    public void forceSendEmptyChunks() {
        player.forceSendEmptyChunks();
    }

    public void removeWindow(Inventory inventory) {
        player.removeWindow(inventory);
    }

    public void onBlock(Entity entity, EntityDamageEvent e, boolean animate) {
        player.onBlock(entity, e, animate);
    }

    public long getBreakingBlockTime() {
        return player.breakingBlockTime;
    }

    public void setBreakingBlockTime(long breakingBlockTime) {
        player.breakingBlockTime = breakingBlockTime;
    }

    public double getBlockBreakProgress() {
        return player.blockBreakProgress;
    }

    public void setBlockBreakProgress(double blockBreakProgress) {
        player.blockBreakProgress = blockBreakProgress;
    }

    public Map<UUID, Player> getHiddenPlayers() {
        return player.hiddenPlayers;
    }

    /**
     * Returns the current unrestricted base budget of the adaptive chunk publisher.
     * <p>
     * This is no longer a fixed per-player chunks-per-tick limit. Actual publication
     * grants are calculated dynamically by the server-global chunk publisher using
     * network capacity, active-streamer fairness, transport pressure, recent chunk
     * payload cost, available byte tokens, and runtime resource pressure.
     *
     * @return current unrestricted global chunk publication base
     * @deprecated LevelChunk publication no longer uses a fixed per-player chunks-per-tick
     * limit. Use the adaptive chunk publisher architecture instead.
     */
    @Deprecated(since = "3.1.0", forRemoval = true)
    public int getChunksPerTick() {
        return player.getChunkSendCountPerTick();
    }

    public int getSpawnThreshold() {
        return player.spawnThreshold;
    }

    public int getMessageCounter() {
        return player.messageLimitCounter;
    }

    public void setMessageCounter(int messageCounter) {
        player.messageLimitCounter = messageCounter;
    }

    public void setConnected(boolean connected) {
        player.connected.set(connected);
    }

    public void setSocketAddress(InetSocketAddress socketAddress) {
        player.socketAddress = socketAddress;
    }

    public String getUsername() {
        return player.getName();
    }

    public String getDisplayName() {
        return player.displayName;
    }

    public void setDisplayName(String displayName) {
        player.displayName = displayName;
    }

    public Vector3 getSleeping() {
        return player.sleeping;
    }

    public void setSleeping(Vector3 sleeping) {
        player.sleeping = sleeping;
    }

    public int getChunkLoadCount() {
        return player.chunkLoadCount;
    }

    public void setChunkLoadCount(int chunkLoadCount) {
        player.chunkLoadCount = chunkLoadCount;
    }

    public int getNextChunkOrderRun() {
        return player.nextChunkOrderRun;
    }

    public void setNextChunkOrderRun(int nextChunkOrderRun) {
        player.nextChunkOrderRun = nextChunkOrderRun;
    }

    public Vector3 getNewPosition() {
        return player.newPosition;
    }

    public void setNewPosition(Vector3 newPosition) {
        player.newPosition = newPosition;
    }

    public int getChunkRadius() {
        return player.chunkRadius;
    }

    public void setChunkRadius(int chunkRadius) {
        player.chunkRadius = chunkRadius;
    }

    public Position getSpawnPosition() {
        return player.spawnPoint;
    }

    public void setSpawnPosition(Position spawnPosition) {
        player.spawnPoint = spawnPosition;
    }

    /**
     * Returns the pending End portal destination.
     *
     * @return pending destination, or {@code null} when none is pending
     */
    public Level getPendingEndPortalDestination() {
        return player.pendingEndPortalDestination;
    }

    /**
     * Sets the pending End portal destination.
     *
     * @param destination pending destination, or {@code null} to clear it
     */
    public void setPendingEndPortalDestination(Level destination) {
        player.pendingEndPortalDestination = destination;
    }

    public void setInAirTicks(int inAirTicks) {
        player.inAirTicks = inAirTicks;
    }

    public int getStartAirTicks() {
        return player.startAirTicks;
    }

    public void setStartAirTicks(int startAirTicks) {
        player.startAirTicks = startAirTicks;
    }

    public boolean isCheckMovement() {
        return player.checkMovement;
    }

    public void setFoodData(PlayerFood foodData) {
        player.foodData = foodData;
    }

    public int getFormWindowCount() {
        return player.formWindowCount;
    }

    public void setFormWindowCount(int formWindowCount) {
        player.formWindowCount = formWindowCount;
    }

    public Map<Integer, Form<?>> getFormWindows() {
        return player.formWindows;
    }

    public BiMap<Inventory, Byte> getWindows() {
        return player.windows;
    }

    public BiMap<Byte, Inventory> getWindowIndex() {
        return player.windowIndex;
    }

    public int getClosingWindowId() {
        return player.closingWindowId;
    }

    public void setClosingWindowId(int closingWindowId) {
        player.closingWindowId = closingWindowId;
    }

    public void setFormWindows(Map<Integer, Form<?>> formWindows) {
        player.formWindows = formWindows;
    }

    public Map<Integer, Form<?>> getServerSettings() {
        return player.serverSettings;
    }

    public void setServerSettings(Map<Integer, Form<?>> serverSettings) {
        player.serverSettings = serverSettings;
    }

    public Cache<String, FormWindowDialog> getDialogWindows() {
        return player.dialogWindows;
    }

    public void setDialogWindows(Cache<String, FormWindowDialog> dialogWindows) {
        player.dialogWindows = dialogWindows;
    }

    public void setInteract() {
        player.previousInteractTick = player.getServer().getTick();
    }

    public void setDummyBossBars(Map<Long, DummyBossBar> dummyBossBars) {
        player.dummyBossBars = dummyBossBars;
    }

    public void setLastInAirTick(int lastInAirTick) {
        player.lastInAirTick = lastInAirTick;
    }

    public int getLastPlayedLevelUpSoundTime() {
        return player.lastPlayedLevelUpSoundTime;
    }

    public void setLastPlayedLevelUpSoundTime(int lastPlayedLevelUpSoundTime) {
        player.lastPlayedLevelUpSoundTime = lastPlayedLevelUpSoundTime;
    }

    public void setLastAttackEntity(Entity lastAttackEntity) {
        player.lastAttackEntity = lastAttackEntity;
    }

    public List<String> getFogStack() {
        return player.fogStack;
    }

    public void setFogStack(List<String> fogStack) {
        player.fogStack = fogStack;
    }

    public void setLastBeAttackEntity(Entity lastBeAttackEntity) {
        player.lastBeAttackEntity = lastBeAttackEntity;
    }

    public ClientChainData getLoginChainData() {
        return player.clientChainData;
    }

    public AsyncTask getPreLoginEventTask() {
        return player.preLoginEventTask;
    }

    public void setPreLoginEventTask(AsyncTask preLoginEventTask) {
        player.preLoginEventTask = preLoginEventTask;
    }

    public void onPlayerLocallyInitialized() {
        player.onPlayerLocallyInitialized();
    }

    public boolean isValidRespawnBlock(Block block) {
        return player.isValidRespawnBlock(block);
    }

    public void respawn() {
        player.respawn();
    }

    public void checkChunks() {
        player.checkChunks();
    }

    public void processLogin() {
        player.processLogin();
    }

    public void initEntity() {
        player.initEntity();
    }

    public void checkGroundState(double movX, double movY, double movZ, double dx, double dy, double dz) {
        player.checkGroundState(movX, movY, movZ, dx, dy, dz);
    }

    public void checkBlockCollision() {
        player.checkBlockCollision();
    }

    public void checkNearEntities() {
        player.checkNearEntities();
    }

    public void handleMovement(Location clientPos) {
        player.handleMovement(clientPos);
    }

    public void offerMovementTask(Location newPosition) {
        player.offerMovementTask(newPosition);
    }

    public void handleLogicInMove(boolean invalidMotion, double distance) {
        player.handleLogicInMove(invalidMotion, distance);
    }

    public void handleLogicInMove(boolean invalidMotion, double deltaX, double deltaY, double deltaZ) {
        player.handleLogicInMove(invalidMotion, deltaX, deltaY, deltaZ);
    }

    public void resetClientMovement() {
        player.resetClientMovement();
    }

    public void revertClientMotion(Location originalPos) {
        player.revertClientMotion(originalPos);
    }

    public float getBaseOffset() {
        return player.getBaseOffset();
    }

    public PlayerBlockActionData getLastBlockAction() {
        return player.lastBlockAction;
    }

    public void setLastBlockAction(PlayerBlockActionData actionData) {
        player.lastBlockAction = actionData;
    }

    public void onBlockBreakContinue(Vector3 pos, BlockFace face) {
        player.onBlockBreakContinue(pos, face);
    }

    public void onBlockBreakStart(Vector3 pos, BlockFace face) {
        player.onBlockBreakStart(pos, face);
    }

    public void onBlockBreakAbort(Vector3 pos) {
        player.onBlockBreakAbort(pos);
    }

    public void onBlockBreakComplete(BlockVector3 blockPos, BlockFace face) {
        player.onBlockBreakComplete(blockPos, face);
    }

    public boolean getShowingCredits() {
        return player.showingCredits;
    }

    public static int getNoShieldDelay() {
        return Player.NO_SHIELD_DELAY;
    }

    public boolean getInventoryOpen() {
        return player.inventoryOpen;
    }

    public void setInventoryOpen(boolean inventoryOpen) {
        player.inventoryOpen = inventoryOpen;
    }

    public void addDefaultWindows() {
        player.addDefaultWindows();
    }

    public void doFirstSpawn() {
        this.player.doFirstSpawn();
    }

    public void onAckReceive(long creationTime) {
        this.player.onAckReceive(creationTime);
    }

    public void handlePacket(BedrockPacket packet) {
        this.player.handlePacket(packet);
    }
}
