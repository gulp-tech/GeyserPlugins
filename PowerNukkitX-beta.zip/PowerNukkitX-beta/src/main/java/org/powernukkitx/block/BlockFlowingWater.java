package org.powernukkitx.block;

import org.powernukkitx.block.definition.BlockDefinition;

import org.powernukkitx.Player;
import org.powernukkitx.block.property.CommonBlockProperties;
import org.powernukkitx.entity.Entity;
import org.powernukkitx.item.Item;
import org.powernukkitx.level.Level;
import org.powernukkitx.math.BlockFace;
import org.powernukkitx.utils.BlockColor;
import org.jetbrains.annotations.NotNull;

public class BlockFlowingWater extends BlockLiquid {
    public static final BlockProperties PROPERTIES = new BlockProperties(FLOWING_WATER, CommonBlockProperties.LIQUID_DEPTH);
    public static final BlockDefinition DEFINITION = BlockLiquid.DEFINITION.toBuilder()
            .tickRate(5)
            .build();

    @Override
    @NotNull public BlockProperties getProperties() {
        return PROPERTIES;
    }

    public BlockFlowingWater() {
        this(PROPERTIES.getDefaultState());
    }

    public BlockFlowingWater(BlockState blockstate) {
        super(blockstate, DEFINITION);
    }

    public BlockFlowingWater(BlockState blockstate, BlockDefinition definition) {
        super(blockstate, definition);
    }

    @Override
    public String getName() {
        return "Flowing Water";
    }

    @Override
    public boolean place(@NotNull Item item, @NotNull Block block, @NotNull Block target, @NotNull BlockFace face, double fx, double fy, double fz, Player player) {
        boolean ret = this.getLevel().setBlock(this, this, true, false);
        this.getLevel().scheduleUpdate(this, this.tickRate());
        return ret;
    }

    @Override
    public void afterRemoval(Block newBlock, boolean update) {
        if (!update) {
            return;
        }

        String newId = newBlock.getId();
        if (newId.equals(FLOWING_WATER) || newId.equals(WATER)) {
            return;
        }

        Block up = up(1, 0);
        for (BlockFace diagonalFace : BlockFace.Plane.HORIZONTAL) {
            Block diagonal = up.getSide(diagonalFace);
            if (diagonal.getId().equals(BlockID.REEDS)) {
                diagonal.onUpdate(Level.BLOCK_UPDATE_SCHEDULED);
            }
        }
    }

    @Override
    public BlockLiquid getLiquidWithNewDepth(int depth) {
        return new BlockFlowingWater(this.blockstate.setPropertyValue(PROPERTIES, CommonBlockProperties.LIQUID_DEPTH.createValue(depth)));
    }

    @Override
    public void onEntityCollide(Entity entity) {
        super.onEntityCollide(entity);

        if (entity.fireTicks > 0) {
            entity.extinguish();
        }
    }

    
    @Override
    public boolean usesWaterLogging() {
        return true;
    }

    @Override
    public double getPassableBlockFrictionFactor() {
        return 0.5;
    }

    @Override
    public BlockColor getColor() {
        BlockColor color = BlockColor.WATER_BLOCK_COLOR.clone();
        color.applyTint(level.getBiomeId(getFloorX(), getFloorY(), getFloorZ()));
        return color;
    }
}