package org.powernukkitx.block;

import org.powernukkitx.block.definition.BlockDefinition;

import org.powernukkitx.Player;
import org.powernukkitx.Server;
import org.powernukkitx.event.block.BlockGrowEvent;
import org.powernukkitx.item.Item;
import org.powernukkitx.item.ItemID;
import org.powernukkitx.level.Level;
import org.powernukkitx.level.particle.BoneMealParticle;
import org.powernukkitx.math.BlockFace;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

import static org.powernukkitx.block.property.CommonBlockProperties.GROWING_PLANT_AGE;


public class BlockCaveVines extends BlockTransparent {
    public static final BlockProperties PROPERTIES = new BlockProperties(CAVE_VINES, GROWING_PLANT_AGE);
    public static final BlockDefinition DEFINITION = TRANSPARENT.toBuilder()
            .hardness(0)
            .canBeActivated(true)
            .isTransparent(true)
            .isSolid(false)
            .build();

    @Override
    @NotNull public BlockProperties getProperties() {
        return PROPERTIES;
    }

    public BlockCaveVines() {
        this(PROPERTIES.getDefaultState());
    }

    public BlockCaveVines(BlockState blockstate) {
        super(blockstate, DEFINITION);
    }

    public BlockCaveVines(BlockState blockstate, BlockDefinition definition) {
        super(blockstate, definition);
    }

    @Override
    public String getName() {
        return "Cave Vines";
    }

    public static boolean isValidSupport(Block block) {
        if (block instanceof BlockLiquid) return false;
        else return block.up().isSolid() || block.up() instanceof BlockCaveVines;
    }

    
    @Override
    public int onUpdate(int type) {
        if (type == Level.BLOCK_UPDATE_NORMAL) {
            if (!isValidSupport(this)) {
                this.getLevel().useBreakOn(this);
            }
            return type;
        } else if (type == Level.BLOCK_UPDATE_RANDOM) {
            Random random = ThreadLocalRandom.current();
            //random mature,The feature that I added.
            if (random.nextInt(4) == 0) {
                int growth = getGrowth();
                if (growth + 4 < getMaxGrowth()) {
                    BlockCaveVines block = (BlockCaveVines) this.clone();
                    block.setGrowth(growth + 4);
                    BlockGrowEvent ev = new BlockGrowEvent(this, block);
                    Server.getInstance().getPluginManager().callEvent(ev);
                    if (!ev.isCancelled()) {
                        this.getLevel().setBlock(this, ev.getNewState(), false, true);
                    } else {
                        return type;
                    }
                } else {
                    BlockCaveVines block;
                    if (this.up() instanceof BlockCaveVines && !(this.down() instanceof BlockCaveVines)) {
                        block = new BlockCaveVinesHeadWithBerries();
                    } else block = new BlockCaveVinesBodyWithBerries();
                    block.setGrowth(getMaxGrowth());
                    BlockGrowEvent ev = new BlockGrowEvent(this, block);
                    Server.getInstance().getPluginManager().callEvent(ev);
                    if (!ev.isCancelled()) {
                        this.getLevel().setBlock(this, ev.getNewState(), false, true);
                    } else {
                        return type;
                    }
                }
            }
            //random grow feature,according to wiki in https://minecraft.wiki/w/Glow_Berries#Growth
            if (down().isAir() && random.nextInt(10) == 0) {
                BlockCaveVines block;
                if (this.up() instanceof BlockCaveVines && !(this.down() instanceof BlockCaveVines)) {
                    block = new BlockCaveVinesHeadWithBerries();
                } else block = new BlockCaveVinesBodyWithBerries();
                block.setGrowth(getMaxGrowth());
                BlockGrowEvent ev = new BlockGrowEvent(this, block);
                Server.getInstance().getPluginManager().callEvent(ev);
                if (!ev.isCancelled()) {
                    this.getLevel().setBlock(this.down(), ev.getNewState(), false, true);
                } else {
                    return type;
                }
            } else if (down().isAir()) {
                BlockCaveVines block = new BlockCaveVines();
                block.setGrowth(0);
                BlockGrowEvent ev = new BlockGrowEvent(this, block);
                Server.getInstance().getPluginManager().callEvent(ev);
                if (!ev.isCancelled()) {
                    this.getLevel().setBlock(this.down(), ev.getNewState(), false, true);
                }
            }
            return type;
        }
        return 0;
    }

    @Override
    public boolean onActivate(@NotNull Item item, @Nullable Player player, BlockFace blockFace, float fx, float fy, float fz) {
        if (item.isFertilizer()) {
            BlockCaveVines block;
            if (this.up() instanceof BlockCaveVines && !(this.down() instanceof BlockCaveVines)) {
                block = new BlockCaveVinesHeadWithBerries();
            } else block = new BlockCaveVinesBodyWithBerries();
            int max = getMaxGrowth();
            int growth = getGrowth();
            if (growth < max) {
                block.setGrowth(max);
                BlockGrowEvent ev = new BlockGrowEvent(this, block);
                Server.getInstance().getPluginManager().callEvent(ev);
                if (ev.isCancelled()) {
                    return false;
                }
                this.getLevel().setBlock(this, ev.getNewState(), false, true);
                this.level.addParticle(new BoneMealParticle(this));
                if (player != null && !player.isCreative()) {
                    item.count--;
                }
            }
            return true;
        }
        if (item.isNull()) {
            if (this.getGrowth() == 25) {
                BlockCaveVines block = new BlockCaveVines();
                block.setGrowth(0);
                this.getLevel().setBlock(this, block, false, true);
                this.getLevel().dropItem(this, Item.get(ItemID.GLOW_BERRIES));
            }
            return true;
        }
        return false;
    }

    @Override
    public Item[] getDrops(Item item) {
        return Item.EMPTY_ARRAY;
    }

    private int getMaxGrowth() {
        return GROWING_PLANT_AGE.getMax();
    }

    private int getGrowth() {
        return getPropertyValue(GROWING_PLANT_AGE);
    }

    private void setGrowth(int growth) {
        setPropertyValue(GROWING_PLANT_AGE, growth);
    }
}
