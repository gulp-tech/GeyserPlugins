package org.powernukkitx.block;

import org.powernukkitx.item.ItemTool;

import org.powernukkitx.block.definition.BlockDefinition;

import org.powernukkitx.Player;
import org.powernukkitx.Server;
import org.powernukkitx.block.property.enums.CauldronLiquid;
import org.powernukkitx.blockentity.BlockEntity;
import org.powernukkitx.blockentity.BlockEntityCauldron;
import org.powernukkitx.entity.Entity;
import org.powernukkitx.entity.effect.EffectType;
import org.powernukkitx.event.entity.EntityCombustByBlockEvent;
import org.powernukkitx.event.entity.EntityDamageByBlockEvent;
import org.powernukkitx.event.entity.EntityDamageEvent;
import org.powernukkitx.event.player.PlayerBucketEmptyEvent;
import org.powernukkitx.event.player.PlayerBucketFillEvent;
import org.powernukkitx.item.*;
import org.powernukkitx.level.Sound;
import org.powernukkitx.level.particle.SmokeParticle;
import org.powernukkitx.level.vibration.VibrationEvent;
import org.powernukkitx.level.vibration.VibrationType;
import org.powernukkitx.math.AxisAlignedBB;
import org.powernukkitx.math.BlockFace;
import org.powernukkitx.math.NukkitMath;
import org.powernukkitx.nbt.tag.CompoundTag;
import org.powernukkitx.utils.BlockColor;
import org.cloudburstmc.protocol.bedrock.data.LevelEvent;
import org.jetbrains.annotations.NotNull;

import javax.annotation.Nullable;

import static org.powernukkitx.block.property.CommonBlockProperties.CAULDRON_LIQUID;
import static org.powernukkitx.block.property.CommonBlockProperties.FILL_LEVEL;

/**
 * @author CreeperFace (Nukkit Project)
 */

public class BlockCauldron extends BlockSolid implements BlockEntityHolder<BlockEntityCauldron> {

    public static final BlockProperties PROPERTIES = new BlockProperties(CAULDRON, CAULDRON_LIQUID, FILL_LEVEL);
    public static final BlockDefinition DEFINITION = SOLID.toBuilder()
            .hardness(2)
            .resistance(10)
            .toolType(ItemTool.TYPE_PICKAXE)
            .toolTier(ItemTool.TIER_WOODEN)
            .canBeActivated(true)
            .canHarvestWithHand(false)
            .isTransparent(true)
            .hasEntityCollision(true)
            .hasComparatorInputOverride(true)
            .build();

    @Override
    @NotNull
    public BlockProperties getProperties() {
        return PROPERTIES;
    }

    public BlockCauldron() {
        this(PROPERTIES.getDefaultState());
    }

    public BlockCauldron(BlockState blockstate) {
        super(blockstate, DEFINITION);
    }

    @Override
    @NotNull
    public String getBlockEntityType() {
        return BlockEntity.CAULDRON;
    }

    @Override
    @NotNull
    public Class<? extends BlockEntityCauldron> getBlockEntityClass() {
        return BlockEntityCauldron.class;
    }

    @Override
    public String getName() {
        return getCauldronLiquid() == CauldronLiquid.LAVA ? "Lava Cauldron" : "Cauldron Block";
    }

    public boolean isFull() {
        return getFillLevel() == FILL_LEVEL.getMax();
    }

    public boolean isEmpty() {
        return getFillLevel() == FILL_LEVEL.getMin();
    }

    public int getFillLevel() {
        return getPropertyValue(FILL_LEVEL);
    }

    public void setFillLevel(int fillLevel) {
        this.setFillLevel(fillLevel, null);
    }

    public void setFillLevel(int fillLevel, @Nullable Player player) {
        if (fillLevel == getFillLevel()) return;

        if (fillLevel > getFillLevel()) {
            this.level.getVibrationManager().callVibrationEvent(new VibrationEvent(player != null ? player : this, this.add(0.5, 0.5, 0.5), VibrationType.FLUID_PLACE));
        } else {
            this.level.getVibrationManager().callVibrationEvent(new VibrationEvent(player != null ? player : this, this.add(0.5, 0.5, 0.5), VibrationType.FLUID_PICKUP));
        }

        this.setPropertyValue(FILL_LEVEL, fillLevel);
    }

    public CauldronLiquid getCauldronLiquid() {
        return this.getPropertyValue(CAULDRON_LIQUID);
    }

    public void setCauldronLiquid(CauldronLiquid liquid) {
        this.setPropertyValue(CAULDRON_LIQUID, liquid);
    }

    @Override
    public boolean onActivate(@NotNull Item item, Player player, BlockFace blockFace, float fx, float fy, float fz) {
        if (isNotActivate(player)) return false;
        if (getCauldronLiquid() == CauldronLiquid.LAVA) {
            return onLavaActivate(item, player, blockFace, fx, fy, fz);
        }

        BlockEntityCauldron cauldron = getBlockEntity();

        if (cauldron == null) {
            return false;
        }

        if (item instanceof ItemBucket bucket) {
            if (bucket.getFishEntityId() != null) {
                return false;
            }
            if (bucket.isEmpty()) {
                if (!isFull() || cauldron.isCustomColor() || cauldron.hasPotion()) {
                    return false;
                }

                String newBucketID = switch (this.getCauldronLiquid()) {
                    case POWDER_SNOW -> ItemID.POWDER_SNOW_BUCKET;
                    case LAVA -> ItemID.LAVA_BUCKET;
                    default -> ItemID.WATER_BUCKET;
                };

                PlayerBucketFillEvent ev = new PlayerBucketFillEvent(player, this, null, this, item, Item.get(newBucketID, 0, 1, bucket.getNbtBytes()));
                this.level.getServer().getPluginManager().callEvent(ev);
                if (!ev.isCancelled()) {
                    replaceBucket(bucket, player, ev.getItem());
                    this.setFillLevel(FILL_LEVEL.getMin(), player);
                    this.level.setBlock(this, this, true);
                    cauldron.clearCustomColor();
                    this.getLevel().addLevelEvent(this.add(0.5, 0.375 + getFillLevel() * 0.125, 0.5), LevelEvent.CAULDRON_TAKE_WATER);
                }
            } else if (bucket.isWater() || bucket.isLava() || bucket.isPowderSnow()) {
                if (isFull() && !cauldron.isCustomColor() && !cauldron.hasPotion() && item.getDamage() == 8) {
                    return false;
                }

                PlayerBucketEmptyEvent ev = new PlayerBucketEmptyEvent(player, this, null, this, item, Item.get(ItemID.BUCKET, 0, 1, bucket.getNbtBytes()));
                this.level.getServer().getPluginManager().callEvent(ev);
                if (!ev.isCancelled()) {
                    if (player.isSurvival() || player.isAdventure()) {
                        replaceBucket(bucket, player, ev.getItem());
                    }
                    if (cauldron.hasPotion()) {
                        clearWithFizz(cauldron, player);
                    } else if (bucket.isWater()) {
                        if (!isEmpty() && getCauldronLiquid() != CauldronLiquid.WATER) {
                            clearWithFizz(cauldron, player);
                        } else {
                            this.setFillLevel(FILL_LEVEL.getMax(), player);
                            cauldron.clearCustomColor();
                            this.level.setBlock(this, this, true);
                            this.getLevel().addSound(this.add(0.5, 1, 0.5), Sound.CAULDRON_FILLWATER);
                        }
                    } else if (bucket.isPowderSnow()) {
                        if (!isEmpty() && getCauldronLiquid() != CauldronLiquid.POWDER_SNOW) {
                            clearWithFizz(cauldron, player);
                        } else {
                            this.setCauldronLiquid(CauldronLiquid.POWDER_SNOW);
                            this.setFillLevel(FILL_LEVEL.getMax(), player);
                            cauldron.clearCustomColor();
                            this.level.setBlock(this, this, true);
                            this.getLevel().addSound(this.add(0.5, 1, 0.5), Sound.BUCKET_EMPTY_POWDER_SNOW);
                        }
                    } else if (bucket.isLava()) {
                        if (!isEmpty() && getCauldronLiquid() != CauldronLiquid.LAVA) {
                            clearWithFizz(cauldron, player);
                        } else {
                            this.setCauldronLiquid(CauldronLiquid.LAVA);
                            this.setFillLevel(FILL_LEVEL.getMax(), player);
                            cauldron.setType(BlockEntityCauldron.PotionType.LAVA);
                            cauldron.clearCustomColor();
                            this.level.setBlock(this, this, true);
                            this.getLevel().addSound(this.add(0.5, 1, 0.5), Sound.BUCKET_EMPTY_LAVA);
                        }
                    }
                }
            }
        }

        switch (item.getId()) {
            case ItemID.DYE:
                if (isEmpty() || cauldron.hasPotion()) {
                    break;
                }

                if (player.isSurvival() || player.isAdventure()) {
                    item.setCount(item.getCount() - 1);
                    player.getInventory().setItemInMainHand(item);
                }

                BlockColor color = new ItemDye(item.getDamage()).getDyeColor().getLeatherColor();
                if (!cauldron.isCustomColor()) {
                    cauldron.setCustomColor(color);
                } else {
                    BlockColor current = cauldron.getCustomColor();
                    BlockColor mixed = new BlockColor(
                        (int) Math.round(Math.sqrt(color.getRed() * current.getRed()) * 0.965),
                        (int) Math.round(Math.sqrt(color.getGreen() * current.getGreen()) * 0.965),
                        (int) Math.round(Math.sqrt(color.getBlue() * current.getBlue()) * 0.965)
                    );
                    cauldron.setCustomColor(mixed);
                }
                this.level.addLevelEvent(
                        this.add(0.5, 0.375 + getFillLevel() * 0.125, 0.5),
                        LevelEvent.CAULDRON_ADD_DYE,
                        cauldron.getCustomColor().getRGB() << 8 >> 8
                );

                break;
            case ItemID.WOLF_ARMOR:
            case ItemID.LEATHER_HELMET:
            case ItemID.LEATHER_CHESTPLATE:
            case ItemID.LEATHER_LEGGINGS:
            case ItemID.LEATHER_BOOTS:
            case ItemID.LEATHER_HORSE_ARMOR:
                if (isEmpty() || cauldron.hasPotion()) {
                    break;
                }

                if (cauldron.isCustomColor()) {
                    CompoundTag compoundTag = item.hasNbt() ? item.getNbt().copy() : new CompoundTag();
                    compoundTag.putInt("customColor", cauldron.getCustomColor().getRGB());
                    item.setNbt(compoundTag);
                    player.getInventory().setItemInMainHand(item);
                    setFillLevel(NukkitMath.clamp(getFillLevel() - 2, FILL_LEVEL.getMin(), FILL_LEVEL.getMax()), player);
                    this.level.setBlock(this, this, true, true);
                    this.level.addSound(add(0.5, 0.5, 0.5), Sound.CAULDRON_DYEARMOR);
                } else {
                    if (!item.hasNbt()) {
                        break;
                    }

                    CompoundTag compoundTag = item.getNbt();
                    if (!compoundTag.contains("customColor")) {
                        break;
                    }

                    compoundTag.remove("customColor");
                    item.setNbt(compoundTag);
                    player.getInventory().setItemInMainHand(item);

                    setFillLevel(NukkitMath.clamp(getFillLevel() - 2, FILL_LEVEL.getMin(), FILL_LEVEL.getMax()), player);
                    this.level.setBlock(this, this, true, true);
                    this.getLevel().addSound(this.add(0.5, 1, 0.5), Sound.CAULDRON_TAKEWATER);
                }

                break;
            case ItemID.POTION:
            case ItemID.SPLASH_POTION:
            case ItemID.LINGERING_POTION:
                if (!isEmpty() && (cauldron.hasPotion() ? cauldron.getPotionId() != item.getDamage() : item.getDamage() != 0)) {
                    clearWithFizz(cauldron, player);
                    consumePotion(item, player);
                    break;
                }
                if (isFull()) {
                    break;
                }

                if (item.getDamage() != 0 && isEmpty()) {
                    cauldron.setPotionId(item.getDamage());
                }

                cauldron.setType(
                    item.getId().equals(ItemID.POTION) ? BlockEntityCauldron.PotionType.NORMAL :
                        item.getId().equals(ItemID.SPLASH_POTION) ? BlockEntityCauldron.PotionType.SPLASH :
                        BlockEntityCauldron.PotionType.LINGERING
                );
                cauldron.spawnToAll();

                setFillLevel(NukkitMath.clamp(getFillLevel() + 2, FILL_LEVEL.getMin(), FILL_LEVEL.getMax()), player);
                this.level.setBlock(this, this, true);

                consumePotion(item, player);

                this.level.addLevelEvent(this.add(0.5, 0.375 + getFillLevel() * 0.125, 0.5), LevelEvent.CAULDRON_FILL_POTION);
                break;
            case ItemID.GLASS_BOTTLE:
                if (isEmpty()) {
                    break;
                }

                int meta = cauldron.hasPotion() ? cauldron.getPotionId() : 0;

                Item potion;
                if (meta == 0) {
                    potion = new ItemPotion();
                } else {
                    potion = switch (cauldron.getType()) {
                        case SPLASH -> new ItemSplashPotion(meta);
                        case LINGERING -> new ItemLingeringPotion(meta);
                        default -> new ItemPotion(meta);
                    };
                }

                setFillLevel(NukkitMath.clamp(getFillLevel() - 2, FILL_LEVEL.getMin(), FILL_LEVEL.getMax()), player);
                if (isEmpty()) {
                    cauldron.setPotionId(-1);
                    cauldron.clearCustomColor();
                }
                this.level.setBlock(this, this, true);

                boolean consumeBottle = player.isSurvival() || player.isAdventure();
                if (consumeBottle && item.getCount() == 1) {
                    player.getInventory().setItemInMainHand(potion);
                } else if (item.getCount() > 1) {
                    if (consumeBottle) {
                        item.setCount(item.getCount() - 1);
                        player.getInventory().setItemInMainHand(item);
                    }

                    if (player.getInventory().canAddItem(potion)) {
                        player.getInventory().addItem(potion);
                    } else {
                        player.getLevel().dropItem(player.add(0, 1.3, 0), potion, player.getDirectionVector().multiply(0.4));
                    }
                }

                this.level.addLevelEvent(this.add(0.5, 0.375 + getFillLevel() * 0.125, 0.5), LevelEvent.CAULDRON_TAKE_POTION);
                break;
            case ItemID.BANNER:
                if (isEmpty() || cauldron.isCustomColor() || cauldron.hasPotion()) {
                    break;
                }

                ItemBanner banner = (ItemBanner) item;
                if (!banner.hasPattern()) {
                    break;
                }

                banner.removePattern(banner.getPatternsSize() - 1);
                boolean consumeBanner = player.isSurvival() || player.isAdventure();
                if (consumeBanner && item.getCount() < item.getMaxStackSize()) {
                    player.getInventory().setItemInMainHand(banner);
                } else {
                    if (consumeBanner) {
                        item.setCount(item.getCount() - 1);
                        player.getInventory().setItemInMainHand(item);
                    }

                    if (player.getInventory().canAddItem(banner)) {
                        player.getInventory().addItem(banner);
                    } else {
                        player.getLevel().dropItem(player.add(0, 1.3, 0), banner, player.getDirectionVector().multiply(0.4));
                    }
                }

                setFillLevel(NukkitMath.clamp(getFillLevel() - 2, FILL_LEVEL.getMin(), FILL_LEVEL.getMax()), player);
                this.level.setBlock(this, this, true, true);
                this.getLevel().addSound(this.add(0.5, 1, 0.5), Sound.CAULDRON_TAKEWATER);

                break;
            default:
                if (item instanceof ItemDye) {
                    if (isEmpty() || cauldron.hasPotion()) {
                        break;
                    }

                    if (player.isSurvival() || player.isAdventure()) {
                        item.setCount(item.getCount() - 1);
                        player.getInventory().setItemInMainHand(item);
                    }

                    color = ((ItemDye) item).getDyeColor().getColor();
                    if (!cauldron.isCustomColor()) {
                        cauldron.setCustomColor(color);
                    } else {
                        BlockColor current = cauldron.getCustomColor();
                        BlockColor mixed = new BlockColor(
                            current.getRed() + (color.getRed() - current.getRed()) / 2,
                            current.getGreen() + (color.getGreen() - current.getGreen()) / 2,
                            current.getBlue() + (color.getBlue() - current.getBlue()) / 2
                        );
                        cauldron.setCustomColor(mixed);
                    }
                    this.level.addLevelEvent(
                            this.add(0.5, 0.375 + getFillLevel() * 0.125, 0.5),
                            LevelEvent.CAULDRON_ADD_DYE,
                            cauldron.getCustomColor().getRGB() << 8 >> 8
                    );
                } else {
                    return true;
                }
        }

        this.level.updateComparatorOutputLevel(this);
        return true;
    }

    public boolean onLavaActivate(@NotNull Item item, Player player, BlockFace blockFace, float fx, float fy, float fz) {
        BlockEntity be = this.level.getBlockEntity(this);

        if (!(be instanceof BlockEntityCauldron cauldron)) {
            return false;
        }

        if (item instanceof ItemBucket bucket) {
            if (bucket.getFishEntityId() != null) {
                return true;
            }

            if (bucket.isEmpty()) {
                if (!isFull() || cauldron.isCustomColor() || cauldron.hasPotion()) {
                    return true;
                }

                PlayerBucketFillEvent ev = new PlayerBucketFillEvent(player, this, null, this, item, Item.get(ItemID.LAVA_BUCKET, 0, 1, bucket.getNbtBytes()));
                this.level.getServer().getPluginManager().callEvent(ev);
                if (!ev.isCancelled()) {
                    replaceBucket(bucket, player, ev.getItem());
                    this.setFillLevel(FILL_LEVEL.getMin(), player);
                    this.level.setBlock(this, new BlockCauldron(), true);
                    cauldron.clearCustomColor();
                    this.getLevel().addSound(this.add(0.5, 1, 0.5), Sound.BUCKET_FILL_LAVA);
                }
            } else if (bucket.isWater() || bucket.isLava() || bucket.isPowderSnow()) {
                if (isFull() && !cauldron.isCustomColor() && !cauldron.hasPotion() && bucket.isLava()) {
                    return true;
                }

                PlayerBucketEmptyEvent ev = new PlayerBucketEmptyEvent(player, this, null, this, item, Item.get(ItemID.BUCKET, 0, 1, bucket.getNbtBytes()));
                this.level.getServer().getPluginManager().callEvent(ev);
                if (!ev.isCancelled()) {
                    replaceBucket(bucket, player, ev.getItem());

                    if (cauldron.hasPotion() || bucket.isWater() || bucket.isPowderSnow()) {
                        clearWithFizz(cauldron, player);
                    } else if (bucket.isLava()) {
                        this.setFillLevel(FILL_LEVEL.getMax(), player);
                        cauldron.clearCustomColor();
                        this.level.setBlock(this, this, true);
                        this.getLevel().addSound(this.add(0.5, 1, 0.5), Sound.BUCKET_EMPTY_LAVA);
                    }
                }
            }

            this.level.updateComparatorOutputLevel(this);
            return true;
        }

        switch (item.getId()) {
            case Item.POTION:
            case Item.SPLASH_POTION:
            case Item.LINGERING_POTION:
                if (!isEmpty() && (cauldron.hasPotion() ? cauldron.getPotionId() != item.getDamage() : item.getDamage() != 0)) {
                    clearWithFizz(cauldron, player);
                    break;
                }
                return super.onActivate(item, player, blockFace, fx, fy, fz);
            case Item.GLASS_BOTTLE:
                if (!isEmpty() && cauldron.hasPotion()) {
                    return super.onActivate(item, player, blockFace, fx, fy, fz);
                }
            default:
                return true;
        }

        this.level.updateComparatorOutputLevel(this);
        return true;
    }

    protected void replaceBucket(Item oldBucket, Player player, Item newBucket) {
        if (player.isSurvival() || player.isAdventure()) {
            if (oldBucket.getCount() == 1) {
                player.getInventory().setItemInMainHand(newBucket);
            } else {
                oldBucket.setCount(oldBucket.getCount() - 1);
                if (player.getInventory().canAddItem(newBucket)) {
                    player.getInventory().addItem(newBucket);
                } else {
                    player.getLevel().dropItem(player.add(0, 1.3, 0), newBucket, player.getDirectionVector().multiply(0.4));
                }
            }
        }
    }

    private void consumePotion(Item item, Player player) {
        if (player.isSurvival() || player.isAdventure()) {
            if (item.getCount() == 1) {
                player.getInventory().setItemInMainHand(new ItemBlock(new BlockAir()));
            } else if (item.getCount() > 1) {
                item.setCount(item.getCount() - 1);
                player.getInventory().setItemInMainHand(item);

                Item bottle = new ItemGlassBottle();
                if (player.getInventory().canAddItem(bottle)) {
                    player.getInventory().addItem(bottle);
                } else {
                    player.getLevel().dropItem(player.add(0, 1.3, 0), bottle, player.getDirectionVector().multiply(0.4));
                }
            }
        }
    }

    public void clearWithFizz(BlockEntityCauldron cauldron) {
        clearWithFizz(cauldron, null);
    }

    public void clearWithFizz(BlockEntityCauldron cauldron, @Nullable Player player) {
        this.setFillLevel(FILL_LEVEL.getMin(), player);
        cauldron.setPotionId(-1);
        cauldron.setType(BlockEntityCauldron.PotionType.NORMAL);
        cauldron.clearCustomColor();
        this.level.setBlock(this, new BlockCauldron(), true);
        this.level.addSound(this.add(0.5, 0, 0.5), Sound.RANDOM_FIZZ);
        for (int i = 0; i < 8; ++i) {
            this.getLevel().addParticle(new SmokeParticle(add(Math.random(), 1.2, Math.random())));
        }
    }

    @Override
    public boolean place(@NotNull Item item, @NotNull Block block, @NotNull Block target, @NotNull BlockFace face, double fx, double fy, double fz, Player player) {
        CompoundTag nbt = new CompoundTag()
            .putShort("PotionId", (short) -1)
            .putByte("SplashPotion", (byte) 0);

        if (item.hasCustomBlockData()) {
            for (var entry : item.getCustomBlockData().getEntrySet()) {
                nbt.put(entry.getKey(), entry.getValue().copy());
            }
        }

        return BlockEntityHolder.setBlockAndCreateEntity(this, false, true, nbt) != null;
    }

    @Override
    public int getComparatorInputOverride() {
        return getFillLevel();
    }

    
    @Override
    public boolean isSolid(BlockFace side) {
        return false;
    }

    
    @Override
    public int getLightFilter() {
        return 3;
    }

    @Override
    public int getLightLevel() {
        return getCauldronLiquid() == CauldronLiquid.LAVA ? 15 : 0;
    }

    
    @Override
    protected AxisAlignedBB recalculateCollisionBoundingBox() {
        return shrink(0.3, 0.3, 0.3);
    }

    @Override
    public void onEntityCollide(Entity entity) {
        EntityCombustByBlockEvent ev = new EntityCombustByBlockEvent(this, entity, 15);
        Server.getInstance().getPluginManager().callEvent(ev);
        if (!ev.isCancelled()) {
            if (getCauldronLiquid() == CauldronLiquid.LAVA && entity.isAlive() && entity.noDamageTicks == 0) {
                entity.setOnFire(ev.getDuration());
                if (!entity.hasEffect(EffectType.FIRE_RESISTANCE)) {
                    entity.attack(new EntityDamageByBlockEvent(this, entity, EntityDamageEvent.DamageCause.LAVA, 4));
                }
            } else if (entity.isAlive() && entity.isOnFire()) {
                entity.setOnFire(0);
            }
        }
    }
}
