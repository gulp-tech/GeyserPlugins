package org.powernukkitx.block;

import org.powernukkitx.block.property.CommonBlockProperties;
import org.jetbrains.annotations.NotNull;
import org.powernukkitx.tags.BlockTags;

import java.util.Set;

public class BlockBlackWoolSlab extends BlockWoolSlab {
    public static final BlockProperties PROPERTIES = new BlockProperties(BLACK_WOOL_SLAB, Set.of(BlockTags.PNX_WOOL), CommonBlockProperties.MINECRAFT_VERTICAL_HALF);

    @Override
    @NotNull public BlockProperties getProperties() {
        return PROPERTIES;
    }

    public BlockBlackWoolSlab() {
        this(PROPERTIES.getDefaultState());
    }

    public BlockBlackWoolSlab(BlockState blockState) {
        super(blockState, "minecraft:black_wool_double_slab");
    }

    @Override
    public String getSlabName() {
        return "Black Wool";
    }

    @Override
    public boolean isSameType(BlockSlab slab) {
        return slab.getId().equals(getId());
    }

}

