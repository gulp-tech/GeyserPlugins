package org.powernukkitx.block;

import org.powernukkitx.Player;
import org.powernukkitx.block.customblock.CustomBlock;
import org.powernukkitx.block.customblock.CustomBlockComponentBehavior;
import org.powernukkitx.block.customblock.CustomBlockDefinition;
import org.powernukkitx.block.customblock.CustomBlockDefinition.BlockTickSettings;
import org.powernukkitx.block.property.type.BlockPropertyType;
import org.powernukkitx.blockentity.BlockEntity;
import org.powernukkitx.entity.Entity;
import org.powernukkitx.entity.effect.Effect;
import org.powernukkitx.entity.effect.EffectType;
import org.powernukkitx.event.player.PlayerInteractEvent;
import org.powernukkitx.item.Item;
import org.powernukkitx.item.ItemBlock;
import org.powernukkitx.item.ItemTool;
import org.powernukkitx.inventory.Inventory;
import org.powernukkitx.inventory.InventoryHolder;
import org.powernukkitx.item.enchantment.Enchantment;
import org.powernukkitx.level.Level;
import org.powernukkitx.level.MovingObjectPosition;
import org.powernukkitx.level.Position;
import org.powernukkitx.math.AxisAlignedBB;
import org.powernukkitx.math.BlockFace;
import org.powernukkitx.math.SimpleAxisAlignedBB;
import org.powernukkitx.math.Vector3;
import org.powernukkitx.metadata.MetadataValue;
import org.powernukkitx.metadata.Metadatable;
import org.powernukkitx.nbt.tag.CompoundTag;
import org.powernukkitx.nbt.tag.ListTag;
import org.powernukkitx.nbt.tag.StringTag;
import org.powernukkitx.plugin.Plugin;
import org.powernukkitx.registry.BlockRegistry;
import org.powernukkitx.registry.Registries;
import org.powernukkitx.tags.BlockTags;
import org.powernukkitx.utils.BlockColor;
import io.netty.util.internal.EmptyArrays;
import org.powernukkitx.block.definition.BlockDefinition;
import org.powernukkitx.nbt.tag.Tag;
import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;
import lombok.extern.slf4j.Slf4j;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.ThreadLocalRandom;
import java.util.function.Predicate;

/**
 * @author MagicDroidX (Nukkit Project)
 */
@Slf4j
public abstract class Block extends Position implements Metadatable, AxisAlignedBB, BlockID {
    public static final BlockDefinition DEFAULT_DEFINITION = BlockDefinition.builder()
            .breaksWhenMoved(false)
            .burnAbility(0)
            .burnChance(0)
            .canBeActivated(false)
            .canBeClimbed(false)
            .canBeFlowedInto(false)
            .canBePlaced(true)
            .canBePulled(true)
            .canBePushed(true)
            .canBeReplaced(false)
            .canHarvestWithHand(true)
            .canStickBlocks(false)
            .canPassThrough(false)
            .canSilkTouch(false)
            .diffusesSkyLight(false)
            .dropExp(0)
            .friction(Block.DEFAULT_FRICTION_FACTOR)
            .hardness(10)
            .hasComparatorInputOverride(false)
            .hasEntityCollision(false)
            .hasEntityStepSensor(false)
            .isFertilizable(false)
            .isPowerSource(false)
            .lightDampening(-1)
            .lightEmission(0)
            .passableFrictionFactor(Block.DEFAULT_AIR_FLUID_FRICTION)
            .isSolid(true)
            .isSoulSpeedCompatible(false)
            .isTransparent(false)
            .lavaResistant(false)
            .resistance(1)
            .maxStackSize(64)
            .sticksToPiston(true)
            .tickRate(10)
            .toolTier(0) //No tier required
            .toolType(ItemTool.TYPE_NONE)
            .walkThroughExtraCost(0)
            .waterloggingLevel(0)
            .build();

    public static final Block[] EMPTY_ARRAY = new Block[0];
    public static final float DEFAULT_FRICTION_FACTOR = 0.4f;
    public static final float DEFAULT_AIR_FLUID_FRICTION = 0.95f;
    public static final Long2ObjectOpenHashMap<BlockColor> VANILLA_BLOCK_COLOR_MAP = new Long2ObjectOpenHashMap<>();
    public int layer;
    protected BlockState blockstate;
    protected BlockDefinition definition;
    protected BlockColor color;

    public Block(@Nullable BlockState blockState) {
        this(blockState, DEFAULT_DEFINITION);
    }

    public Block(@Nullable BlockState blockState, @Nullable BlockDefinition definition) {
        super(0, 0, 0, null);
        if (blockState != null && getProperties().containBlockState(blockState)) {
            this.blockstate = blockState;
        } else {
            this.blockstate = this.getProperties().getDefaultState();
        }

        if (definition != null) {
            this.definition = definition;
        } else {
            this.definition = DEFAULT_DEFINITION;
        }

        // Respect legacy custom blocks' definition
        if (this instanceof CustomBlock && !(this.definition instanceof CustomBlockDefinition)) {
            CustomBlockDefinition custom = BlockRegistry.getCustomBlockDefinitionByIdStatic(this.blockstate.getIdentifier());
            if (custom != null) {
                this.definition = custom;
            }
        }
    }

    public static boolean isNotActivate(Player player) {
        if (player == null) {
            return true;
        }
        Item itemInHand = player.getInventory().getItemInMainHand();
        return (player.isSneaking() || player.isFlySneaking()) && !(itemInHand.isTool() || itemInHand.isNull());
    }

    @NotNull
    public static Block get(String id) {
        id = id.contains(":") ? id : "minecraft:" + id;
        Block block = Registries.BLOCK.get(id);
        if (block == null) return new BlockAir();
        return block;
    }

    @NotNull
    public static Block get(String id, Position pos) {
        id = id.contains(":") ? id : "minecraft:" + id;
        Block block = Registries.BLOCK.get(id, pos.getFloorX(), pos.getFloorY(), pos.getFloorZ(), pos.level);
        if (block == null) {
            BlockAir blockAir = new BlockAir();
            blockAir.x = pos.getFloorX();
            blockAir.y = pos.getFloorY();
            blockAir.z = pos.getFloorZ();
            blockAir.level = pos.level;
            return blockAir;
        }
        return block;
    }

    @NotNull
    public static Block get(String id, Position pos, int layer) {
        id = id.contains(":") ? id : "minecraft:" + id;
        Block block = get(id, pos);
        block.layer = layer;
        return block;
    }

    @NotNull
    public static Block get(String id, Level level, int x, int y, int z) {
        id = id.contains(":") ? id : "minecraft:" + id;
        Block block = Registries.BLOCK.get(id, x, y, z, level);
        if (block == null) {
            BlockAir blockAir = new BlockAir();
            blockAir.x = x;
            blockAir.y = y;
            blockAir.z = z;
            blockAir.level = level;
            return blockAir;
        }
        return block;
    }

    @NotNull
    public static Block get(String id, Level level, int x, int y, int z, int layer) {
        id = id.contains(":") ? id : "minecraft:" + id;
        Block block = get(id, level, x, y, z);
        block.layer = layer;
        return block;
    }

    @NotNull
    public static Block get(BlockState blockState) {
        Block block = Registries.BLOCK.get(blockState);
        if (block == null) {
            return new BlockAir();
        }
        return block;
    }

    @NotNull
    public static Block get(BlockState blockState, Position pos) {
        Block block = Registries.BLOCK.get(blockState, pos.getFloorX(), pos.getFloorY(), pos.getFloorZ(), pos.level);
        if (block == null) {
            BlockAir blockAir = new BlockAir();
            blockAir.x = pos.getFloorX();
            blockAir.y = pos.getFloorY();
            blockAir.z = pos.getFloorZ();
            blockAir.level = pos.level;
            return blockAir;
        }
        return block;
    }

    @NotNull
    public static Block get(BlockState blockState, Position pos, int layer) {
        Block block = get(blockState, pos);
        block.layer = layer;
        return block;
    }

    @NotNull
    public static Block get(BlockState blockState, Level level, int x, int y, int z) {
        Block block = Registries.BLOCK.get(blockState, x, y, z, level);
        if (block == null) {
            BlockAir blockAir = new BlockAir();
            blockAir.x = x;
            blockAir.y = y;
            blockAir.z = z;
            blockAir.level = level;
            return blockAir;
        }
        return block;
    }

    @NotNull
    public static Block get(BlockState blockState, Level level, int x, int y, int z, int layer) {
        Block block = get(blockState, level, x, y, z);
        block.layer = layer;
        return block;
    }

    @NotNull
    public static Block getWithState(String id, BlockState blockState) {
        id = id.contains(":") ? id : "minecraft:" + id;
        Block block = get(id);
        block.setPropertyValues(blockState.getBlockPropertyValues());
        return block;
    }

    private static BlockColor parseHexColor(String hex) {
        if (hex == null || hex.isEmpty()) return new BlockColor(0xFF, 0xFF, 0xFF, 0xFF);
        String s = hex.charAt(0) == '#' ? hex.substring(1) : hex;
        long val;
        try {
            val = Long.parseLong(s, 16);
        } catch (NumberFormatException e) {
            return new BlockColor(0xFF, 0xFF, 0xFF, 0xFF);
        }

        if (s.length() == 6) {
            return new BlockColor((int) ((val >> 16) & 0xFF), (int) ((val >> 8) & 0xFF), (int) (val & 0xFF), 0xFF);
        }
        if (s.length() == 8) {
            return new BlockColor((int) ((val >> 16) & 0xFF), (int) ((val >> 8) & 0xFF), (int) (val & 0xFF), (int) ((val >> 24) & 0xFF));
        }
        return new BlockColor(0xFF, 0xFF, 0xFF, 0xFF);
    }

    private static int toolType0(Item item, Block b) {
        if (b instanceof BlockLeaves && item.isHoe()) {
            return ItemTool.TYPE_SHEARS;
        }
        if (item.isSword()) return ItemTool.TYPE_SWORD;
        if (item.isShovel()) return ItemTool.TYPE_SHOVEL;
        if (item.isPickaxe()) return ItemTool.TYPE_PICKAXE;
        if (item.isAxe()) return ItemTool.TYPE_AXE;
        if (item.isHoe()) return ItemTool.TYPE_HOE;
        if (item.isShears()) return ItemTool.TYPE_SHEARS;
        return ItemTool.TYPE_NONE;
    }

    private static boolean correctTool0(int blockToolType, Item item, Block b) {
        String block = b.getId();
        if (b instanceof BlockLeaves && item.isHoe()) {
            return (blockToolType == ItemTool.TYPE_SHEARS && item.isHoe());
        } else if (block.equals(BAMBOO) && item.isSword()) {
            return (blockToolType == ItemTool.TYPE_AXE && item.isSword());
        } else
            return (blockToolType == ItemTool.TYPE_SWORD && item.isSword()) || (blockToolType == ItemTool.TYPE_SHOVEL && item.isShovel()) || (blockToolType == ItemTool.TYPE_PICKAXE && item.isPickaxe()) || (blockToolType == ItemTool.TYPE_AXE && item.isAxe()) || (blockToolType == ItemTool.TYPE_HOE && item.isHoe()) || (blockToolType == ItemTool.TYPE_SHEARS && item.isShears()) || blockToolType == ItemTool.TYPE_NONE || (block.equals(WEB) && item.isShears());
    }

    public static boolean equals(Block b1, Block b2) {
        return equals(b1, b2, true);
    }

    public static boolean equals(Block b1, Block b2, boolean checkState) {
        if (b1 == null || b2 == null || !b1.getId().equals(b2.getId())) {
            return false;
        }
        if (checkState) {
            boolean b1Default = b1.isDefaultState();
            boolean b2Default = b2.isDefaultState();
            if (b1Default != b2Default) {
                return false;
            } else if (b1Default) { // both are default
                return true;
            } else {
                return b1.blockstate == b2.blockstate;
            }
        } else {
            return true;
        }
    }

    /**
     * Place and initialize sa this block correctly in the world.
     * <p>The current instance must have level, x, y, z, and layer properties already set before calling this method.</p>
     *
     * @param item   The item being used to place the block. Should be used as an optional reference, may mismatch the block that is being placed depending on plugin implementations.
     * @param block  The current block that is in the world and is getting replaced by this instance. It has the same x, y, z, layer, and level as this block.
     * @param target The block that was clicked to create the place action in this block position.
     * @param face   The face that was clicked in the target block
     * @param fx     The detailed X coordinate of the clicked target block face
     * @param fy     The detailed Y coordinate of the clicked target block face
     * @param fz     The detailed Z coordinate of the clicked target block face
     * @param player The player that is placing the block. May be null.
     * @return {@code true} if the block was properly place. The implementation is responsible for reverting any partial change.
     */
    public boolean place(@NotNull Item item, @NotNull Block block, @NotNull Block target, @NotNull BlockFace face, double fx, double fy, double fz, @Nullable Player player) {
        return this.getLevel().setBlock(this, this, true, true);
    }

    public boolean onBreak(Item item) {
        return this.getLevel().setBlock(this, layer, Block.get(AIR), true, true);
    }

    public boolean isSilkTouch(Vector3 vector, int layer, BlockFace face, Item item, Player player) {
        return false;
    }

    /**
     * Handles ticking logic for custom blocks using either RANDOM or SCHEDULED tick types.
     * <p>
     * To enable ticking, configure the block with:
     * <pre>{@code
     *     .blockTick(60, 60, true)
     * }</pre>
     * Where:
     * <ul>
     *   <li><b>minTicks</b> and <b>maxTicks</b>: define the tick interval range (in server ticks).</li>
     *   <li><b>looping</b>: if {@code true}, the block will continue ticking; if {@code false}, it will tick once and stop.</li>
     * </ul>
     *
     * <b>Important:</b> Always call {@code super.onUpdate(type)} in any overridden implementation to preserve base behavior.
     *
     * <b>Note:</b> For custom blocks, ticking logic should only be applied to {@code BLOCK_UPDATE_SCHEDULED} updates.
     * Return early for all other tick types (like {@code BLOCK_UPDATE_RANDOM}) to avoid interfering with the core scheduling system.
     *
     * @return The update type to continue ticking, or 0 to stop future ticks.
     */
    public int onUpdate(int type) {
        if (isTickingDisabled()) return 0;
        if (type != Level.BLOCK_UPDATE_SCHEDULED) return 0;

        CustomBlockDefinition def = getCustomDefinition();
        if (def == null || def.tickSettings() == null) return 0;

        BlockTickSettings tick = def.tickSettings();
        int min = tick.minTicks();
        int max = tick.maxTicks();

        if (tick.looping() && this.getLevel().isChunkLoaded(this.getFloorX() >> 4, this.getFloorZ() >> 4)) {
            int delay = (min == max) ? max : ThreadLocalRandom.current().nextInt(min, max + 1);
            this.getLevel().scheduleUpdate(this, delay);
            return Level.BLOCK_UPDATE_SCHEDULED;
        } else {
            this.getLevel().cancelScheduledUpdate(this, this);
            return 0;
        }
    }

    public void onTouch(@NotNull Vector3 vector, @NotNull Item item, @NotNull BlockFace face, float fx, float fy, float fz, @Nullable Player player, @NotNull PlayerInteractEvent.Action action) {
        onUpdate(Level.BLOCK_UPDATE_TOUCH);
    }

    public void onNeighborChange(@NotNull BlockFace side) {
    }

    public boolean isBreakable(@NotNull Vector3 vector, int layer, @Nullable BlockFace face, @Nullable Item item, @Nullable Player player) {
        return true;
    }

    /**
     * When right-clicked on the block, {@link #canBeActivated()}=true will only be called
     *
     * @param item      used item
     * @param player    player for Activator
     * @param blockFace a direction the player is facing
     * @param fx        the fx at block
     * @param fy        the fy at block
     * @param fz        the fz at block
     * @return the boolean
     */
    public boolean onActivate(@NotNull Item item, @Nullable Player player, BlockFace blockFace, float fx, float fy, float fz) {
        return CustomBlockComponentBehavior.onActivate(this, player);
    }

    public void afterRemoval(Block newBlock, boolean update) {
    }

    /**
     * Check if the above space is greater than 0.5 for chests
     *
     * @return Can chest be opened with the above space?
     */
    public boolean hasFreeSpaceAbove() {
        Block above = this.up();

        if (above instanceof BlockSlab slab) {
            return slab.isOnTop();
        }

        if (above.isTransparent()) {
            return true;
        }

        AxisAlignedBB box = above.getCollisionBoundingBox();
        if (box != null) {
            double minY = box.getMinY();
            double relativeMinY = minY - above.getY();
            return relativeMinY >= 0.5;
        }

        return false;
    }

    /**
     * Check if blocks can be attached in the given side.
     */
    public boolean isSolid(BlockFace side) {
        CustomBlockDefinition def = getCustomDefinition();
        if (def != null) {
            AxisAlignedBB box = def.getBoundingBox(this);
            if (box != null) {
                switch (side) {
                    case UP -> {
                        double height = box.getMaxY() - box.getMinY();
                        return height >= 0.999;
                    }
                    case DOWN -> {
                        double base = box.getMinY();
                        return base <= 0.001;
                    }
                    default -> {
                        return true;
                    }
                }
            }
        }

        return isSideFull(side);
    }

    /**
     * Returns the level of waterlogging for this block.
     * 0 means the block is not waterlogged; a value greater than 0 indicates the degree of waterlogging.
     *
     * @return the waterlogging level (0 if not waterlogged)
     */
    public int getWaterloggingLevel() {
        return definition.getWaterloggingLevel();
    }

    /**
     * Checks if this block is waterlogged.
     * Returns {@code true} if the waterlogging level is greater than 0, otherwise {@code false}.
     *
     * @return {@code true} if waterlogged, {@code false} otherwise
     */
    public boolean isWaterLogged() {
        if (getWaterloggingLevel() == 0) return false;

        Block fluid = this.getLevelBlockAtLayer(1);
        if (fluid == null || fluid.isAir()) return false;

        return fluid instanceof BlockFlowingWater;
    }

    public final boolean canWaterloggingFlowInto() {
        return canBeFlowedInto() || getWaterloggingLevel() > 1;
    }

    /**
     * Returns the level of snowlogging for this block.
     * 0 means the block cannot be snowlogged.
     */
    public int getSnowloggingLevel() {
        return 0;
    }

    /**
     * Returns the Bedrock precipitation behavior, or null when the native component is absent.
     */
    @Nullable
    public PrecipitationBehavior getPrecipitationBehavior() {
        PrecipitationBehavior behavior = getProperties().getPrecipitationBehavior();
        if (behavior != null) return behavior;
        return getSnowloggingLevel() > 0 ? PrecipitationBehavior.SNOWLOGGING : null;
    }

    /**
     * Checks if this block is snowlogged.
     * Returns {@code true} if this block supports snowlogging and has a snow layer on layer 0.
     */
    public boolean isSnowLogged() {
        if (getSnowloggingLevel() == 0) return false;

        Block snow = this.getLevelBlockAtLayer(0);
        if (snow == null || snow.isAir()) return false;

        return snow instanceof BlockSnowLayer;
    }


    public int getComparatorInputOverride() {
        return 0;
    }

    public boolean canHarvest(Item item) {
        return (getToolTier() == 0 || getToolType() == 0) || (correctTool0(getToolType(), item, this) && item.getTier() >= getToolTier());
    }

    public BlockColor getColor() {
        if (color != null) return color;

        CustomBlockDefinition def = getCustomDefinition();
        if (def != null) {
            String hex = def.nbt().getCompound("components").getString("minecraft:map_color");
            color = parseHexColor(hex);
            color.applyTint(level.getBiomeId(getFloorX(), getFloorY(), getFloorZ()));
            return color;
        }

        color = VANILLA_BLOCK_COLOR_MAP.get(this.blockstate.blockStateHash());
        if (color == null) {
            log.error("Failed to get color of block {}", getName());
            log.error("Current block state hash: {}", this.blockstate.blockStateHash());
            color = BlockColor.VOID_BLOCK_COLOR;
        }
        color.applyTint(level.getBiomeId(getFloorX(), getFloorY(), getFloorZ()));
        return color;
    }

/**
     * @return the alias identifiers for this block, or an empty array if it has none
     */
    public String[] getAliases() {
        return EmptyArrays.EMPTY_STRINGS;
    }

    public String getName() {
        var path = this.blockstate.getIdentifier().split(":")[1];
        StringBuilder result = new StringBuilder();
        String[] parts = path.split("_");
        for (String part : parts) {
            if (!part.isEmpty()) {
                result.append(Character.toUpperCase(part.charAt(0))).append(part.substring(1)).append(" ");
            }
        }
        return result.toString().trim();
    }

    /**
     * The properties that fully describe all possible and valid states that this block can have.
     */
    @NotNull
    public abstract BlockProperties getProperties();

    @NotNull
    public final String getId() {
        return this.getProperties().getIdentifier();
    }

    @NotNull
    public String getItemId() {
        return getId();
    }

    public List<BlockPropertyType.BlockPropertyValue<?, ?, ?>> getPropertyValues() {
        try {
            return this.blockstate.getBlockPropertyValues();
        } catch (IllegalArgumentException | NullPointerException e) {
            log.warn("The block does not have this property.");
            return Collections.emptyList();
        }
    }

    public Block setPropertyValues(BlockPropertyType.BlockPropertyValue<?, ?, ?>... values) {
        this.blockstate = blockstate.setPropertyValues(getProperties(), values);
        return this;
    }

    public Block setPropertyValues(List<BlockPropertyType.BlockPropertyValue<?, ?, ?>> values) {
        this.blockstate = blockstate.setPropertyValues(getProperties(), values.toArray(BlockPropertyType.BlockPropertyValue<?, ?, ?>[]::new));
        return this;
    }

    @Nullable
    public Object getPropertyValue(String name) {
        for (BlockPropertyType.BlockPropertyValue<?, ?, ?> prop : this.getPropertyValues()) {
            if (prop.getPropertyType().getName().equals(name)) {
                return prop.getValue();
            }
        }
        return null;
    }

    public boolean isAir() {
        return this.blockstate == BlockAir.STATE;
    }

    public BlockState getBlockState() {
        return blockstate;
    }

    /**
     * @deprecated Use {@link #hasTag(String)} instead.
     */
    @Deprecated
    public boolean is(final String blockTag) {
        return hasTag(blockTag);
    }

    /**
     * @return true if block has a string tag
     */
    public boolean hasTag(final String blockTag) {
        CustomBlockDefinition def = getCustomDefinition();
        if (def != null) {
            CompoundTag nbt = def.nbt();
            if (nbt.contains("blockTags")) {
                ListTag<StringTag> tagList = nbt.getList("blockTags", StringTag.class);
                return tagList.getAll().stream().anyMatch(t -> blockTag.equals(t.data));
            }
        }

        return BlockTags.getTagSet(this.getId()).contains(blockTag);
    }

    /**
     * @return list of tags for the block
     */
    public String[] getTags() {
        CustomBlockDefinition def = getCustomDefinition();
        if (def != null) {
            CompoundTag nbt = def.nbt();
            if (nbt.contains("blockTags")) {
                ListTag<StringTag> tagList = nbt.getList("blockTags", StringTag.class);
                return tagList.getAll().stream().map(tag -> tag.data).toArray(String[]::new);
            }
        }

        return BlockTags.getTagSet(this.getId()).toArray(new String[0]);
    }

    public <DATATYPE, PROPERTY extends BlockPropertyType<DATATYPE>> DATATYPE getPropertyValue(PROPERTY p) {
        return blockstate.getPropertyValue(p);
    }

    public <DATATYPE, PROPERTY extends BlockPropertyType<DATATYPE>> Block setPropertyValue(PROPERTY property, DATATYPE value) {
        this.blockstate = blockstate.setPropertyValue(getProperties(), property, value);
        return this;
    }

    public Block setPropertyValue(BlockPropertyType.BlockPropertyValue<?, ?, ?> propertyValue) {
        this.blockstate = blockstate.setPropertyValue(getProperties(), propertyValue);
        return this;
    }

    public final int getRuntimeId() {
        return this.blockstate.blockStateHash();
    }

    public void addVelocityToEntity(Entity entity, Vector3 vector) {
    }

    public final void position(Position v) {
        this.x = (int) v.x;
        this.y = (int) v.y;
        this.z = (int) v.z;
        this.level = v.level;
    }

    private double toolBreakTimeBonus0(Item item) {
        Integer speed = item.getDiggerSpeed(this);
        if (speed != null) {
            return customToolBreakTimeBonus(customToolType(item), speed);
        }
        return toolBreakTimeBonus0(toolType0(item, this), item.getTier(), getId());
    }

    private double customToolBreakTimeBonus(int toolType, @Nullable Integer speed) {
        if (speed != null) return speed;
        else if (toolType == ItemTool.TYPE_SWORD) {
            if (this instanceof BlockWeb) {
                return 15.0;
            } else if (this instanceof BlockBamboo) {
                return 30.0;
            } else return 1.0;
        } else if (toolType == ItemTool.TYPE_SHEARS) {
            if (this instanceof BlockWool || this instanceof BlockLeaves) {
                return 5.0;
            } else if (this instanceof BlockWeb) {
                return 15.0;
            } else return 1.0;
        } else if (toolType == ItemTool.TYPE_NONE) return 1.0;
        return 0;
    }

    private int customToolType(Item item) {
        if (this instanceof BlockLeaves && item.isHoe()) return ItemTool.TYPE_SHEARS;
        if (item.isSword()) return ItemTool.TYPE_SWORD;
        if (item.isShovel()) return ItemTool.TYPE_SHOVEL;
        if (item.isPickaxe()) return ItemTool.TYPE_PICKAXE;
        if (item.isAxe()) return ItemTool.TYPE_AXE;
        if (item.isHoe()) return ItemTool.TYPE_HOE;
        if (item.isShears()) return ItemTool.TYPE_SHEARS;
        return ItemTool.TYPE_NONE;
    }

    private double toolBreakTimeBonus0(int toolType, int toolTier, String blockId) {
        if (toolType == ItemTool.TYPE_SWORD) {
            if (blockId.equals(WEB)) {
                return 15.0;
            }
            if (blockId.equals(BAMBOO)) {
                return 30.0;
            }
            return 1.0;
        }
        if (toolType == ItemTool.TYPE_SHEARS) {
            if (this instanceof BlockWool || this instanceof BlockLeaves) {
                return 5.0;
            } else if (blockId.equals(WEB)) {
                return 15.0;
            }
            return 1.0;
        }
        if (toolType == ItemTool.TYPE_NONE) return 1.0;
        return switch (toolTier) {
            case ItemTool.TIER_WOODEN -> 2.0;
            case ItemTool.TIER_STONE -> 4.0;
            case ItemTool.TIER_IRON -> 6.0;
            case ItemTool.TIER_DIAMOND -> 8.0;
            case ItemTool.TIER_NETHERITE -> 9.0;
            case ItemTool.TIER_GOLD -> 12.0;
            default -> {
                if (toolTier == ItemTool.TIER_NETHERITE) {
                    yield 9.0;
                }
                yield 1.0;
            }
        };
    }

    public double getBreakTime(Item item, Player player) {
        return this.calculateBreakTime(item, player);
    }

    public double getBreakTime(Item item) {
        return this.calculateBreakTime(item);
    }

    /**
     * @link calculateBreakTime(@ Nonnull Item item, @ Nullable Player player)
     */
    public double calculateBreakTime(@NotNull Item item) {
        return calculateBreakTime(item, null);
    }

    /**
     * Calculating block mining time
     *
     * @param item   Mining items from this block
     * @param player The player who mined the block
     * @return Mining time of blocks
     */
    public double calculateBreakTime(@NotNull Item item, @Nullable Player player) {
        double seconds = this.calculateBreakTimeNotInAir(item, player);

        if (player != null) {
            // The player is considered to be digging on the ground only after 5 ticks have passed since the last time the player was in the air.
            // If you only use onGround detection, the time returned by this method will be discontinuous.
            if (player.getLevel().getTick() - player.getLastInAirTick() < 5) {
                seconds *= 5;
            }
        }
        return seconds;
    }

    /**
     * Ignore when the player is in the air when calculating the mining time of the block
     *
     * @param item   Mining items from this block
     * @param player The player who mined the block
     * @return Mining time of blocks
     */
    public double calculateBreakTimeNotInAir(@NotNull Item item, @Nullable Player player) {
        double seconds;
        double blockHardness = getHardness();
        boolean canHarvest = canHarvest(item);

        if (canHarvest) {
            seconds = blockHardness * 1.5;
        } else {
            seconds = blockHardness * 5;
        }

        double speedMultiplier = 1;
        boolean hasConduitPower = false;
        boolean hasAquaAffinity = false;
        int hasteEffectLevel = 0;
        int miningFatigueLevel = 0;

        if (player != null) {
            hasConduitPower = player.hasEffect(EffectType.CONDUIT_POWER);
            hasAquaAffinity = Optional.ofNullable(player.getInventory().getHelmet().getEnchantment(Enchantment.ID_WATER_WORKER)).map(Enchantment::getLevel).map(l -> l >= 1).orElse(false);
            hasteEffectLevel = Optional.ofNullable(player.getEffect(EffectType.HASTE)).map(Effect::getAmplifier).orElse(0);
            miningFatigueLevel = Optional.ofNullable(player.getEffect(EffectType.MINING_FATIGUE)).map(Effect::getAmplifier).orElse(0);
        }

        CompoundTag digger = item.getCustomItemComponent("minecraft:digger");
        boolean hasCustomDigger = digger != null;
        boolean correctTool = correctTool0(getToolType(), item, this);

        Integer customDiggerSpeed = item.getDiggerSpeed(this);
        int efficiencyLevel = Optional.ofNullable(item.getEnchantment(Enchantment.ID_EFFICIENCY))
                .map(Enchantment::getLevel).orElse(0);

        boolean allowEfficiency = false;

        if (customDiggerSpeed != null) {
            speedMultiplier = customDiggerSpeed;
            allowEfficiency = digger.getBoolean("use_efficiency");
        } else if (correctTool) {
            speedMultiplier = toolBreakTimeBonus0(item);
            allowEfficiency = true;
        } else if (hasCustomDigger) {
            speedMultiplier = 1;
            allowEfficiency = false;
        }

        if ((customDiggerSpeed != null || correctTool || hasCustomDigger) && canHarvest) {
            if (allowEfficiency && efficiencyLevel > 0) {
                speedMultiplier += efficiencyLevel * efficiencyLevel + 1;
            }
        }

        if (hasConduitPower) {
            hasteEffectLevel = Integer.max(hasteEffectLevel, 2);
        }

        if (hasteEffectLevel > 0) {
            speedMultiplier *= 1 + (0.2 * hasteEffectLevel);
        }

        if (miningFatigueLevel > 0) {
            speedMultiplier /= Math.pow(miningFatigueLevel, 3);
        }

        seconds /= speedMultiplier;

        if (player != null) {
            if (player.isInsideOfWater() && !hasAquaAffinity) {
                seconds *= hasConduitPower && blockHardness >= 0.5 ? 2.5 : 5;
            }
        }
        return seconds;
    }

    /**
     * Checks if the block can be destroyed by mining with a specific item.
     */
    public boolean canBeMinedWith(Item item) {
        return this.getHardness() != -1;
    }

    /**
     * Checks if the block can be destroyed by explosions.
     */
    public boolean canBeExploded() {
        return this.getResistance() != -1;
    }
    public Block getTickCachedSide(BlockFace face) {
        return getTickCachedSideAtLayer(layer, face);
    }

    public Block getTickCachedSide(BlockFace face, int step) {
        return getTickCachedSideAtLayer(layer, face, step);
    }

    public Block getTickCachedSideAtLayer(int layer, BlockFace face) {
        if (this.isValid()) {
            return this.getLevel().getTickCachedBlock((int) x + face.getXOffset(), (int) y + face.getYOffset(), (int) z + face.getZOffset(), layer);
        }
        return this.getTickCachedSide(face, 1);
    }

    public Block getTickCachedSideAtLayer(int layer, BlockFace face, int step) {
        if (this.isValid()) {
            if (step == 1) {
                return this.getLevel().getTickCachedBlock((int) x + face.getXOffset(), (int) y + face.getYOffset(), (int) z + face.getZOffset(), layer);
            } else {
                return this.getLevel().getTickCachedBlock((int) x + face.getXOffset() * step, (int) y + face.getYOffset() * step, (int) z + face.getZOffset() * step, layer);
            }
        }
        Block block = Block.get(AIR);
        block.x = (int) x + face.getXOffset() * step;
        block.y = (int) y + face.getYOffset() * step;
        block.z = (int) z + face.getZOffset() * step;
        block.layer = layer;
        return block;
    }

    @Override
    public Block getSide(BlockFace face) {
        return getSideAtLayer(layer, face);
    }

    @Override
    public Block getSide(BlockFace face, int step) {
        return getSideAtLayer(layer, face, step);
    }

    public Block getSideAtLayer(int layer, BlockFace face) {
        if (this.isValid()) {
            return this.getLevel().getBlock((int) x + face.getXOffset(), (int) y + face.getYOffset(), (int) z + face.getZOffset(), layer);
        }
        return this.getSide(face, 1);
    }

    public Block getSideAtLayer(int layer, BlockFace face, int step) {
        if (this.isValid()) {
            if (step == 1) {
                return this.getLevel().getBlock((int) x + face.getXOffset(), (int) y + face.getYOffset(), (int) z + face.getZOffset(), layer);
            } else {
                return this.getLevel().getBlock((int) x + face.getXOffset() * step, (int) y + face.getYOffset() * step, (int) z + face.getZOffset() * step, layer);
            }
        }
        Block block = Block.get(AIR);
        block.x = (int) x + face.getXOffset() * step;
        block.y = (int) y + face.getYOffset() * step;
        block.z = (int) z + face.getZOffset() * step;
        block.layer = layer;
        return block;
    }

    @Override
    public Block up() {
        return up(1);
    }

    @Override
    public Block up(int step) {
        return getSide(BlockFace.UP, step);
    }

    public Block up(int step, int layer) {
        return getSideAtLayer(layer, BlockFace.UP, step);
    }

    @Override
    public Block down() {
        return down(1);
    }

    @Override
    public Block down(int step) {
        return getSide(BlockFace.DOWN, step);
    }

    public Block down(int step, int layer) {
        return getSideAtLayer(layer, BlockFace.DOWN, step);
    }

    @Override
    public Block north() {
        return north(1);
    }

    @Override
    public Block north(int step) {
        return getSide(BlockFace.NORTH, step);
    }

    public Block north(int step, int layer) {
        return getSideAtLayer(layer, BlockFace.NORTH, step);
    }

    @Override
    public Block south() {
        return south(1);
    }

    @Override
    public Block south(int step) {
        return getSide(BlockFace.SOUTH, step);
    }

    public Block south(int step, int layer) {
        return getSideAtLayer(layer, BlockFace.SOUTH, step);
    }

    @Override
    public Block east() {
        return east(1);
    }

    @Override
    public Block east(int step) {
        return getSide(BlockFace.EAST, step);
    }

    public Block east(int step, int layer) {
        return getSideAtLayer(layer, BlockFace.EAST, step);
    }

    @Override
    public Block west() {
        return west(1);
    }

    @Override
    public Block west(int step) {
        return getSide(BlockFace.WEST, step);
    }

    public Block west(int step, int layer) {
        return getSideAtLayer(layer, BlockFace.WEST, step);
    }

    @Override
    public String toString() {
        return this.blockstate.toString() + " at " + super.toString();
    }

    public boolean collidesWithBB(AxisAlignedBB bb) {
        return collidesWithBB(bb, false);
    }

    public boolean collidesWithBB(AxisAlignedBB bb, boolean collisionBB) {
        AxisAlignedBB bb1 = collisionBB ? this.getCollisionBoundingBox() : this.getBoundingBox();
        return bb1 != null && bb.intersectsWith(bb1);
    }

    public void onEntityCollide(Entity entity) {
    }

    /**
     * Called when an entity steps onto this block.<p>
     * Only triggered if isStepSensor() returns true on the builder.
     */
    public void onEntityStepOn(Entity entity) {
    }

    /**
     * Called when an entity steps off this block.<p>
     * Only triggered if isStepSensor() returns true on the builder.
     */
    public void onEntityStepOff(Entity entity) {
    }

    public void onEntityFallOn(Entity entity, float fallDistance) {
    }

    public boolean useDefaultFallDamage() {
        return true;
    }

    public AxisAlignedBB getCollisionBoundingBox() {
        return recalculateCollisionBoundingBox();
    }

    public AxisAlignedBB[] getCollisionBoxes() {
        CustomBlockDefinition def = getCustomDefinition();
        if (def != null && def.getComponents().contains("minecraft:collision_box")) {
            return def.getCollisionBoxes(this);
        }
        AxisAlignedBB box = this.getBoundingBox();
        return box == null ? AxisAlignedBB.EMPTY_ARRAY : new AxisAlignedBB[]{box};
    }

    protected AxisAlignedBB recalculateCollisionBoundingBox() {
        AxisAlignedBB[] boxes = this.getCollisionBoxes();
        if (boxes.length == 0) {
            return null;
        } else if(boxes.length == 1) {
            return boxes[0];
        }

        double minX = Double.POSITIVE_INFINITY;
        double minY = Double.POSITIVE_INFINITY;
        double minZ = Double.POSITIVE_INFINITY;
        double maxX = Double.NEGATIVE_INFINITY;
        double maxY = Double.NEGATIVE_INFINITY;
        double maxZ = Double.NEGATIVE_INFINITY;

        for (AxisAlignedBB box : boxes) {
            minX = Math.min(minX, box.getMinX());
            minY = Math.min(minY, box.getMinY());
            minZ = Math.min(minZ, box.getMinZ());
            maxX = Math.max(maxX, box.getMaxX());
            maxY = Math.max(maxY, box.getMaxY());
            maxZ = Math.max(maxZ, box.getMaxZ());
        }

        return new SimpleAxisAlignedBB(minX, minY, minZ, maxX, maxY, maxZ);
    }

    public AxisAlignedBB getBoundingBox() {
        return this.recalculateBoundingBox();
    }

    protected AxisAlignedBB recalculateBoundingBox() {
        try {
            CustomBlockDefinition def = getCustomDefinition();
            if (def != null && def.getComponents().contains("minecraft:collision_box")) {
                AxisAlignedBB box = def.getBoundingBox(this);
                if (box != null) return box;
            }
        } catch (Exception exception) {
            log.error("Failed to recalculate bounding box for block {}", getName(), exception);
        }
        return this;
    }

    @Override
    public double getMinX() {
        return this.x;
    }

    @Override
    public double getMinY() {
        return this.y;
    }

    @Override
    public double getMinZ() {
        return this.z;
    }

    @Override
    public double getMaxX() {
        return this.x + 1;
    }

    @Override
    public double getMaxY() {
        return this.y + 1;
    }

    @Override
    public double getMaxZ() {
        return this.z + 1;
    }


    @Override
    public MovingObjectPosition calculateIntercept(Vector3 pos1, Vector3 pos2) {
        AxisAlignedBB bb = this.getBoundingBox();
        if (bb == null) {
            return null;
        }

        Vector3 v1 = pos1.getIntermediateWithXValue(pos2, bb.getMinX());
        Vector3 v2 = pos1.getIntermediateWithXValue(pos2, bb.getMaxX());
        Vector3 v3 = pos1.getIntermediateWithYValue(pos2, bb.getMinY());
        Vector3 v4 = pos1.getIntermediateWithYValue(pos2, bb.getMaxY());
        Vector3 v5 = pos1.getIntermediateWithZValue(pos2, bb.getMinZ());
        Vector3 v6 = pos1.getIntermediateWithZValue(pos2, bb.getMaxZ());

        if (v1 != null && !bb.isVectorInYZ(v1)) {
            v1 = null;
        }

        if (v2 != null && !bb.isVectorInYZ(v2)) {
            v2 = null;
        }

        if (v3 != null && !bb.isVectorInXZ(v3)) {
            v3 = null;
        }

        if (v4 != null && !bb.isVectorInXZ(v4)) {
            v4 = null;
        }

        if (v5 != null && !bb.isVectorInXY(v5)) {
            v5 = null;
        }

        if (v6 != null && !bb.isVectorInXY(v6)) {
            v6 = null;
        }

        Vector3 vector = v1;

        if (v2 != null && (vector == null || pos1.distanceSquared(v2) < pos1.distanceSquared(vector))) {
            vector = v2;
        }

        if (v3 != null && (vector == null || pos1.distanceSquared(v3) < pos1.distanceSquared(vector))) {
            vector = v3;
        }

        if (v4 != null && (vector == null || pos1.distanceSquared(v4) < pos1.distanceSquared(vector))) {
            vector = v4;
        }

        if (v5 != null && (vector == null || pos1.distanceSquared(v5) < pos1.distanceSquared(vector))) {
            vector = v5;
        }

        if (v6 != null && (vector == null || pos1.distanceSquared(v6) < pos1.distanceSquared(vector))) {
            vector = v6;
        }

        if (vector == null) {
            return null;
        }

        BlockFace f = null;

        if (vector == v1) {
            f = BlockFace.WEST;
        } else if (vector == v2) {
            f = BlockFace.EAST;
        } else if (vector == v3) {
            f = BlockFace.DOWN;
        } else if (vector == v4) {
            f = BlockFace.UP;
        } else if (vector == v5) {
            f = BlockFace.NORTH;
        } else if (vector == v6) {
            f = BlockFace.SOUTH;
        }

        return MovingObjectPosition.fromBlock((int) this.x, (int) this.y, (int) this.z, f, vector.add(this.x, this.y, this.z));
    }

    public String getSaveId() {
        String name = getClass().getName();
        return name.substring(16);
    }

    @Override
    public void setMetadata(String metadataKey, MetadataValue newMetadataValue) {
        if (this.getLevel() != null) {
            this.getLevel().getBlockMetadata().setMetadata(this, metadataKey, newMetadataValue);
        }
    }

    @Override
    public List<MetadataValue> getMetadata(String metadataKey) {
        if (this.getLevel() != null) {
            return this.getLevel().getBlockMetadata().getMetadata(this, metadataKey);

        }
        return null;
    }

    @Override
    public MetadataValue getMetadata(String metadataKey, Plugin plugin) {
        if (this.getLevel() != null) {
            return this.getLevel().getBlockMetadata().getMetadata(this, metadataKey, plugin);
        }
        return null;
    }

    @Override
    public boolean hasMetadata(String metadataKey) {
        return this.getLevel() != null && this.getLevel().getBlockMetadata().hasMetadata(this, metadataKey);
    }

    @Override
    public boolean hasMetadata(String metadataKey, Plugin plugin) {
        return this.getLevel() != null && this.getLevel().getBlockMetadata().hasMetadata(this, metadataKey, plugin);
    }

    @Override
    public void removeMetadata(String metadataKey, Plugin owningPlugin) {
        if (this.getLevel() != null) {
            this.getLevel().getBlockMetadata().removeMetadata(this, metadataKey, owningPlugin);
        }
    }

    @Override
    public Block clone() {
        return (Block) super.clone();
    }

    public int getWeakPower(BlockFace face) {
        return 0;
    }

    /**
     * Gets strong power.
     *
     * @param side the side
     * @return the strong power
     */
    public int getStrongPower(BlockFace side) {
        return 0;
    }

    public String getLocationHash() {
        return this.getFloorX() + ":" + this.getFloorY() + ":" + this.getFloorZ();
    }

    /**
     * Check if the block is not transparent, is solid and can't provide redstone power.
     */
    public boolean isNormalBlock() {
        return !isTransparent() && isSolid() && !isPowerSource();
    }

    /**
     * Check if the block is not transparent, is solid and is a full cube like a stone block.
     */
    public boolean isSimpleBlock() {
        return !isTransparent() && isSolid() && isFullBlock();
    }

    /**
     * Check if the given face is fully occupied by the block bounding box.
     *
     * @param face The face to be checked
     * @return If and only if the bounding box completely cover the face
     */
    public boolean isSideFull(BlockFace face) {
        AxisAlignedBB boundingBox = getBoundingBox();
        if (boundingBox == null) {
            return false;
        }

        if (face.getAxis().getPlane() == BlockFace.Plane.HORIZONTAL) {
            if (boundingBox.getMinY() != getY() || boundingBox.getMaxY() != getY() + 1) {
                return false;
            }
            int offset = face.getXOffset();
            if (offset < 0) {
                return boundingBox.getMinX() == getX() && boundingBox.getMinZ() == getZ() && boundingBox.getMaxZ() == getZ() + 1;
            } else if (offset > 0) {
                return boundingBox.getMaxX() == getX() + 1 && boundingBox.getMaxZ() == getZ() + 1 && boundingBox.getMinZ() == getZ();
            }

            offset = face.getZOffset();
            if (offset < 0) {
                return boundingBox.getMinZ() == getZ() && boundingBox.getMinX() == getX() && boundingBox.getMaxX() == getX() + 1;
            }

            return boundingBox.getMaxZ() == getZ() + 1 && boundingBox.getMaxX() == getX() + 1 && boundingBox.getMinX() == getX();
        }

        if (boundingBox.getMinX() != getX() || boundingBox.getMaxX() != getX() + 1 || boundingBox.getMinZ() != getZ() || boundingBox.getMaxZ() != getZ() + 1) {
            return false;
        }

        if (face.getYOffset() < 0) {
            return boundingBox.getMinY() == getY();
        }

        return boundingBox.getMaxY() == getY() + 1;
    }

    /**
     * Check if this block type holds a block entity that provides an inventory, like a chest or a furnace.
     * This only looks at the block type, use {@link #getContainer()} to access the actual inventory.
     */
    public boolean hasContainer() {
        return this instanceof BlockEntityHolder<?> holder
                && InventoryHolder.class.isAssignableFrom(holder.getBlockEntityClass());
    }

    /**
     * Get the inventory of the block entity placed at this position.
     *
     * @return The inventory, or null if this block has no container or the block entity is missing
     */
    @Nullable
    public Inventory getContainer() {
        if (!hasContainer() || !isValid()) {
            return null;
        }
        return ((BlockEntityHolder<?>) this).getBlockEntity() instanceof InventoryHolder holder ? holder.getInventory() : null;
    }

    /**
     * Check if the block occupies the entire block space, like a stone and normal glass blocks
     */
    public boolean isFullBlock() {
        AxisAlignedBB boundingBox = getBoundingBox();
        if (boundingBox == null) {
            return false;
        }
        return boundingBox.getMinX() == getX() && boundingBox.getMaxX() == getX() + 1 && boundingBox.getMinY() == getY() && boundingBox.getMaxY() == getY() + 1 && boundingBox.getMinZ() == getZ() && boundingBox.getMaxZ() == getZ() + 1;
    }

    /**
     * Compare whether two blocks are the same, this method compares block entities
     *
     * @param obj the obj
     * @return the boolean
     */
    public boolean equalsBlock(Object obj) {
        if (obj instanceof Block otherBlock) {
            if (!(this instanceof BlockEntityHolder<?>) && !(otherBlock instanceof BlockEntityHolder<?>)) {
                return this.getId().equals(otherBlock.getId()) && this.blockstate == otherBlock.blockstate;
            }
            if (this instanceof BlockEntityHolder<?> holder1 && otherBlock instanceof BlockEntityHolder<?> holder2) {
                BlockEntity be1 = holder1.getOrCreateBlockEntity();
                BlockEntity be2 = holder2.getOrCreateBlockEntity();
                return this.getId().equals(otherBlock.getId()) && this.blockstate == otherBlock.blockstate && be1.getCleanedNBT().equals(be2.getCleanedNBT());
            }
        }
        return false;
    }

    public boolean isDefaultState() {
        return this.blockstate == getProperties().getDefaultState();
    }

    public Item toItem() {
        return new ItemBlock(this.getProperties().getDefaultState().toBlock());
    }

    /**
     * Control the item dropped when a block is broken normally
     *
     * @return An array of dropped items
     */
    public Item[] getDrops(Item item) {
        if (canHarvestWithHand() || canHarvest(item)) {
            return new Item[]{this.toItem()};
        }
        return Item.EMPTY_ARRAY;
    }

    public Optional<Block> firstInLayers(Predicate<Block> condition) {
        return firstInLayers(0, condition);
    }

    public Optional<Block> firstInLayers(int startingLayer, Predicate<Block> condition) {
        int maximumLayer = this.level.requireProvider().getMaximumLayer();
        for (int layer = startingLayer; layer <= maximumLayer; layer++) {
            Block block = this.getLevelBlockAtLayer(layer);
            if (condition.test(block)) {
                return Optional.of(block);
            }
        }

        return Optional.empty();
    }

    public final boolean isBlockChangeAllowed() {
        return getChunk().isBlockChangeAllowed(getFloorX() & 0xF, getFloorY(), getFloorZ() & 0xF);
    }

    public final boolean isBlockChangeAllowed(@Nullable Player player) {
        if (isBlockChangeAllowed()) {
            int height = (int) (this.getY() - 1);
            for (int i = height; i >= getLevel().getMinHeight(); i--) {
                Block block = this.down(height - i);
                if (block instanceof BlockAllow) {
                    return true;
                } else if (block instanceof BlockDeny) {
                    return player == null || player.isCreative();
                }
            }
            if (player == null) return true;

            if(player.isAdventure()) {
                Item itemInHand = player.getInventory().getItemInMainHand();
                if(itemInHand.isNull()) return false;

                CompoundTag tag = (CompoundTag) itemInHand.getNbtEntry("CanDestroy");
                boolean canBreak = false;
                if (tag instanceof List<?> list) {
                    for (Object v : list) {
                        if (!(v instanceof String stringTag)) {
                            continue;
                        }
                        Item entry = Item.get(stringTag);
                        if (!entry.isNull() &&
                                entry.getBlock().getId().equals(this.getId())) {
                            canBreak = true;
                            break;
                        }
                    }
                }

                return canBreak;
            } else {
                return true;
            }
        }
        return player != null && player.isCreative() && player.isOp();
    }

    /**
     * Controls the amount of light absorbed by the block
     *
     * @return Light absorbed by the block 0-15
     */
    public int getLightFilter() {
        int lightLevel = definition.getLightDampening();
        return lightLevel >= 0 ? lightLevel : isSolid() && !isTransparent() ? 15 : 1;
    }

    public final boolean canRandomTick() {
        return Level.canRandomTick(getId());
    }

    public boolean onProjectileHit(@NotNull Entity projectile, @NotNull Position position, @NotNull Vector3 motion) {
        return false;
    }

    /**
     * Check if a block is getting powered threw a block or directly.
     *
     * @return if the gets powered.
     */
    public boolean isGettingPower() {
        if (!this.level.getServer().getSettings().gameplaySettings().enableRedstone()) return false;

        for (BlockFace side : BlockFace.values()) {
            Block b = this.getSide(side).getLevelBlock();

            if (this.level.isSidePowered(b.getLocation(), side)) {
                return true;
            }
        }
        return this.level.isBlockPowered(this.getLocation());
    }

    public boolean cloneTo(Position pos) {
        return cloneTo(pos, true);
    }

    /**
     * Clones the block to the given position.<p/>
     * This method also clones the block entity along with it.<p/>
     * Note that this method first clears the block at the target position to air before cloning.
     *
     * @param pos    the position to clone to
     * @param update whether the cloned block needs to be updated
     * @return whether the clone succeeded
     */
    @SuppressWarnings("null")
    public boolean cloneTo(Position pos, boolean update) {
        //clear the old block
        level.setBlock(pos, this.layer, Block.get(Block.AIR), false, false);
        if (this instanceof BlockEntityHolder<?> holder && holder.getBlockEntity() != null) {
            var clonedBlock = this.clone();
            clonedBlock.position(pos);
            CompoundTag tag = holder.getBlockEntity().getCleanedNBT();
            //block entities require direct=true
            return BlockEntityHolder.setBlockAndCreateEntity((BlockEntityHolder<?>) clonedBlock, false, update, tag) != null;
        } else {
            return pos.level.setBlock(pos, this.layer, this.clone(), true, update);
        }
    }

    /**
     * @return the definition backing this block's property getters. For custom blocks this is their
     * {@link CustomBlockDefinition}.
     */
    public BlockDefinition getDefinition() {
        return this.definition;
    }

    @Nullable
    public CustomBlockDefinition getCustomDefinition() {
        return (this instanceof CustomBlock customBlock)
                ? BlockRegistry.getCustomBlockDefinitionByIdStatic(customBlock.getId())
                : null;
    }

    private static final String MINECRAFT_NAMESPACE = "minecraft:";
    private static final String FLOWING_PREFIX = "flowing_";
    private static final String[] EMPTY_STRING_ARRAY = new String[0];

    /**
     * Copy of the settings list the normalized ids were built from. Kept together in one object so
     * a reader never pairs a new source with old normalized ids.
     */
    private record TickingDisabledCache(List<String> source, String[] normalized) {
    }

    private static volatile TickingDisabledCache tickingDisabledCache = new TickingDisabledCache(List.of(), EMPTY_STRING_ARRAY);

    public static boolean isTickingDisabled(Level level, String id) {
        if (level == null) return false;

        List<String> disabledList = level.getServer().getSettings().chunkSettings().disableBlockTicking();
        if (disabledList == null || disabledList.isEmpty()) return false;

        // compared by content, the settings hand out a plain ArrayList that can be edited in place.
        // the elements are the same String instances between edits, so equals mostly stops at ==
        TickingDisabledCache cache = tickingDisabledCache;
        if (!cache.source().equals(disabledList)) {
            String[] normalized = new String[disabledList.size()];
            for (int i = 0; i < normalized.length; i++) {
                normalized[i] = stripBlockIdPrefixes(disabledList.get(i));
            }
            cache = new TickingDisabledCache(new ArrayList<>(disabledList), normalized);
            tickingDisabledCache = cache;
        }
        String[] normalized = cache.normalized();

        int offset = 0;
        if (id.regionMatches(true, 0, MINECRAFT_NAMESPACE, 0, MINECRAFT_NAMESPACE.length())) {
            offset = MINECRAFT_NAMESPACE.length();
        }
        if (id.regionMatches(true, offset, FLOWING_PREFIX, 0, FLOWING_PREFIX.length())) {
            offset += FLOWING_PREFIX.length();
        }
        int length = id.length() - offset;

        for (String candidate : normalized) {
            if (candidate.length() == length && id.regionMatches(true, offset, candidate, 0, length)) {
                return true;
            }
        }

        return false;
    }

    private static String stripBlockIdPrefixes(String id) {
        String normalized = id.toLowerCase();
        if (normalized.startsWith(MINECRAFT_NAMESPACE)) {
            normalized = normalized.substring(MINECRAFT_NAMESPACE.length());
        }
        if (normalized.startsWith(FLOWING_PREFIX)) {
            normalized = normalized.substring(FLOWING_PREFIX.length());
        }
        return normalized;
    }

    public boolean isTickingDisabled() {
        return isTickingDisabled(this.getLevel(), getId());
    }

    @Override
    public boolean equals(Object obj) {
        if (!super.equals(obj)) {
            return false;
        }
        return !(obj instanceof Block other) || this.layer == other.layer;
    }

    @Override
    public int hashCode() {
        return ((int) x ^ ((int) z << 12)) ^ ((int) (y + 64) << 23) ^ (layer << 31);
    }

    /**
     * Block definitions
     *
     * @Override those to provide custom definitions extending builders limits
     * BlockDefinition does only support static values.
     */

    public boolean canHarvestWithHand() {  //used for calculating breaking time
        return definition.isCanHarvestWithHand();
    }

    public int tickRate() {
        return definition.getTickRate();
    }

    /**
     * When the player break block with canSilkTouch enchantment and the canSilkTouch=true,
     * the drop will be set to the original item {@link Block#toItem()}
     */
    public boolean canSilkTouch() {
        return definition.isCanSilkTouch();
    }


    public boolean isSoulSpeedCompatible() {
        return definition.isSoulSpeedCompatible();
    }

    /**
     * Define the block hardness
     */
    public double getHardness() {
        return definition.getHardness();
    }

    /**
     * Defines the block explosion resistance
     */
    public double getResistance() {
        return definition.getResistance();
    }

    /**
     * The higher this value, the more likely the block itself is to catch fire
     *
     * @return the burn chance
     */
    public int getBurnChance() {
        return definition.getBurnChance();
    }

    /**
     * The higher this value, the more likely it is to be ignited by the fire next to it
     */
    public int getBurnAbility() {
        return definition.getBurnAbility();
    }

    /**
     * Controls the type of tool used to mine blocks
     *
     * @return Types of tools used to mine blocks
     */
    public int getToolType() {
        return definition.getToolType();
    }

    /**
     * The friction, which is used to control the speed that player / entity movement on the block.The larger the value, the faster the movement.
     */
    public double getFrictionFactor() {
        return definition.getFriction();
    }

    /**
     * Controls the block's resistance factor (0-1). The smaller the value, the greater the resistance.<p/>
     * For impassable blocks, this value is always 1 (invalid) unless overridden.<p/>
     */
    public double getPassableBlockFrictionFactor() {
        if (!this.canPassThrough()) return 1;
        return definition.getPassableFrictionFactor();
    }

    /**
     * Get the extra cost required to walk through this block. This is typically used for blocks like water or berry bushes that are difficult for entities to pass through.
     *
     * @return Extra cost required to walk through this block
     */
    public int getWalkThroughExtraCost() {
        return definition.getWalkThroughExtraCost();
    }

    /**
     * Controls the light level of the block
     *
     * @return Luminance Level (0 - 15)
     */
    public int getLightLevel() {
        return definition.getLightEmission();
    }

    public boolean canBePlaced() {
        return definition.isCanBePlaced();
    }

    public boolean canBeReplaced() {
        return definition.isCanBeReplaced();
    }

    /**
     * Controls whether the block is transparent (default is false)
     *
     * @return Is the block transparent?
     */
    public boolean isTransparent() {
        return definition.isTransparent();
    }

    public boolean isSolid() {
        CustomBlockDefinition def = getCustomDefinition();
        if (def != null) {
            AxisAlignedBB box = def.getBoundingBox(this);
            if (box != null) {
                double height = box.getMaxY() - box.getMinY();
                return height >= 0.999;
            }
        }

        return definition.isSolid();
    }

    // https://minecraft.wiki/w/Opacity#Lighting
    public boolean diffusesSkyLight() {
        return definition.isDiffusesSkyLight();
    }

    public boolean canBeFlowedInto() {
        return definition.isCanBeFlowedInto();
    }

    /**
     * Returns true if this block is interactable (can be activated).
     * <p>
     * For custom blocks, set interactability using the builder (isPlayerInteractable)
     * instead of overriding this method, so it is correctly saved in NBT and synced with client.
     */
    public boolean canBeActivated() {
        return definition.isCanBeActivated() || CustomBlockComponentBehavior.canBeActivated(this);
    }

    public boolean hasEntityCollision() {
        return definition.isHasEntityCollision();
    }

    /**
     * Returns true if this block has step-on/off sensor.
     * <p>
     * For custom blocks, can be set this by using the builder (isStepSensor).
     */
    public boolean hasEntityStepSensor() {
        return definition.hasEntityStepSensor();
    }

    public boolean canPassThrough() {
        return definition.isCanPassThrough();
    }

    /**
     * @return whether the block can be pushed by a piston
     */
    public boolean canBePushed() {
        return definition.isCanBePushed() && CustomBlockComponentBehavior.canBePushed(this);
    }

    /**
     * @return whether the block can be pulled by a piston
     */
    public boolean canBePulled() {
        return definition.isCanBePulled() && CustomBlockComponentBehavior.canBePulled(this);
    }

    /**
     * @return whether the block is destroyed when moved by a piston
     */
    public boolean breaksWhenMoved() {
        return definition.isBreaksWhenMoved() || CustomBlockComponentBehavior.breaksWhenMoved(this);
    }

    /**
     * @return whether the block can stick to a sticky piston or sticky moving block
     */
    public boolean sticksToPiston() {
        return this.canBePushed() &&
                this.canBePulled() &&
                definition.isSticksToPiston() &&
                CustomBlockComponentBehavior.sticksToPiston(this);
    }

    /**
     * @return whether the block can move adjacent blocks with it, e.g. slime block, honey block
     */
    public boolean canSticksBlock() {
        return definition.isCanStickBlocks() || CustomBlockComponentBehavior.canSticksBlock(this);
    }

    public boolean hasComparatorInputOverride() {
        return definition.isHasComparatorInputOverride();
    }

    /**
     * Controls the minimum tool level for mining blocks (wood, stone, etc.)
     *
     * @return Minimum tool level for mining blocks
     */
    public int getToolTier() {
        return definition.getToolTier();
    }

    public boolean canBeClimbed() {
        return definition.isCanBeClimbed();
    }

    public boolean isPowerSource() {
        return definition.isPowerSource();
    }

    public int getDropExp() {
        return definition.getDropExp();
    }

    public boolean isFertilizable() {
        return definition.isFertilizable();
    }

    /**
     * If the block, when in item form, is resistant to lava and fire and can float on lava like if it was on water.
     *
     * @since 1.4.0.0-PN
     */
    public boolean isLavaResistant() {
        return definition.isLavaResistant();
    }

    public int getItemMaxStackSize() {
        return definition.getMaxStackSize();
    }
}
