package org.powernukkitx.block;

import org.powernukkitx.block.definition.BlockDefinition;

import org.powernukkitx.Player;
import org.powernukkitx.item.Item;
import org.powernukkitx.math.BlockFace;
import org.powernukkitx.math.Vector3;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/**
 * @author Pub4Game
 * @since 03.01.2016
 */

public class BlockBarrier extends BlockSolid {
    public static final BlockProperties PROPERTIES = new BlockProperties(BARRIER);
    public static final BlockDefinition DEFINITION = SOLID.toBuilder()
            .hardness(-1)
            .resistance(18000000)
            .canBePushed(false)
            .waterloggingLevel(1)
            .build();

    public BlockBarrier() {
        this(PROPERTIES.getDefaultState());
    }

    public BlockBarrier(BlockState blockState) {
        super(blockState, DEFINITION);
    }

    @Override
    public String getName() {
        return "Barrier";
    }

    @Override
    @NotNull public BlockProperties getProperties() {
        return PROPERTIES;
    }

    
    @Override
    public boolean isBreakable(@NotNull Vector3 vector, int layer, @Nullable BlockFace face, @Nullable Item item, @Nullable Player player) {
        return player != null && player.isCreative();
    }

    
    @Override
    public boolean canBePulled() {
        return false;
    }

    @Override
    public int getLightFilter() {
        return 0;
    }
}
