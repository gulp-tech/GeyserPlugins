package org.powernukkitx.block;

import org.powernukkitx.Player;
import org.powernukkitx.item.Item;
import org.powernukkitx.item.ItemID;
import org.powernukkitx.item.ItemTool;
import org.powernukkitx.math.BlockFace;
import org.powernukkitx.utils.Faceable;
import org.powernukkitx.block.definition.BlockDefinition;
import org.jetbrains.annotations.NotNull;

import javax.annotation.Nullable;
import java.util.Arrays;

import static org.powernukkitx.block.property.CommonBlockProperties.MINECRAFT_BLOCK_FACE;

public abstract class BlockAmethystBud extends BlockTransparent implements Faceable {
    public static final BlockDefinition DEFINITION = BlockTransparent.TRANSPARENT.toBuilder()
            .isSolid(false)
            .hardness(1.5f)
            .resistance(1.5f)
            .toolType(ItemTool.TYPE_PICKAXE)
            .toolTier(ItemTool.TIER_IRON)
            .waterloggingLevel(1)
            .build();

    public BlockAmethystBud(BlockState blockState) {
        super(blockState, DEFINITION);
    }

    public BlockAmethystBud(BlockState blockState, BlockDefinition definition) {
        super(blockState, definition);
    }

    @Override
    public String getName() {
        return getNamePrefix() + " Amethyst Bud";
    }

    protected abstract String getNamePrefix();

    @Override
    public Item[] getDrops(Item item) {
        return Item.EMPTY_ARRAY;
    }

    @Override
    public BlockFace getBlockFace() {
        return getPropertyValue(MINECRAFT_BLOCK_FACE);
    }

    @Override
    public void setBlockFace(BlockFace face) {
        setPropertyValue(MINECRAFT_BLOCK_FACE, face);
    }

    @Override
    public boolean place(@NotNull Item item, @NotNull Block block, @NotNull Block target, @NotNull BlockFace face, double fx, double fy, double fz, @Nullable Player player) {
        if (!target.isSolid()) {
            return false;
        }

        setBlockFace(face);
        this.level.setBlock(block, this, true, true);
        return true;
    }

    @Override
    public boolean onBreak(Item item) {
        if (item.isPickaxe()) {
            Arrays.stream(this.getDrops(item)).forEach(item1 -> this.level.dropItem(this.add(0.5,0,0.5), item1));
            this.getLevel().setBlock(this, layer, Block.get(BlockID.AIR), true, true);
        } else {
            this.getLevel().setBlock(this, layer, Block.get(BlockID.AIR), true, true);
        }

        return true;
    }

    @Override
    public int onUpdate(int type) {
        if ((this.getSide(this.getBlockFace().getOpposite()).isAir())) {
            this.onBreak(Item.get(ItemID.DIAMOND_PICKAXE));
        }

        return 0;
    }
}
