package org.powernukkitx.block;

import org.powernukkitx.block.definition.BlockDefinition;

import org.powernukkitx.Player;
import org.powernukkitx.item.Item;
import org.powernukkitx.item.ItemStick;
import org.powernukkitx.level.Level;
import org.powernukkitx.math.BlockFace;
import org.powernukkitx.tags.BlockTags;
import org.jetbrains.annotations.NotNull;

import java.util.Random;

/**
 * @author xtypr
 * @since 2015/12/2
 */
public class BlockDeadbush extends BlockFlowable implements BlockFlowerPot.FlowerPotBlock, Supportable {
    public static final BlockProperties PROPERTIES = new BlockProperties(DEADBUSH);
    public static final BlockDefinition DEFINITION = FLOWABLE.toBuilder()
            .canBeReplaced(true)
            .waterloggingLevel(1)
            .build();

    @Override
    @NotNull public BlockProperties getProperties() {
        return PROPERTIES;
    }

    public BlockDeadbush() {
        this(PROPERTIES.getDefaultState());
    }

    public BlockDeadbush(BlockState blockState) {
        // Dead bushes can't have meta. Also stops the server from throwing an exception with the block palette.
        super(blockState, DEFINITION);
    }

    @Override
    public String getName() {
        return "Dead Bush";
    }

    
    @Override
    public boolean place(@NotNull Item item, @NotNull Block block, @NotNull Block target, @NotNull BlockFace face, double fx, double fy, double fz, Player player) {
        if (isSupportDirtSandClay(down())) {
            this.getLevel().setBlock(block, this, true, true);
            return true;
        }
        return false;
    }

    @Override
    public int onUpdate(int type) {
        if (type == Level.BLOCK_UPDATE_NORMAL) {
            if (!isSupportDirtSandClay(down())) {
                this.getLevel().useBreakOn(this);

                return Level.BLOCK_UPDATE_NORMAL;
            }
        }
        return 0;
    }

    @Override
    public Item[] getDrops(Item item) {
        if (item.isShears()) {
            return new Item[]{
                    toItem()
            };
        } else {
            return new Item[]{
                    new ItemStick(0, new Random().nextInt(3))
            };
        }
    }

}
