package org.powernukkitx.block;

import org.powernukkitx.block.definition.BlockDefinition;

import org.powernukkitx.Player;
import org.powernukkitx.block.property.CommonBlockProperties;
import org.powernukkitx.blockentity.BlockEntity;
import org.powernukkitx.blockentity.BlockEntityBrewingStand;
import org.powernukkitx.inventory.ContainerInventory;
import org.powernukkitx.item.Item;
import org.powernukkitx.item.ItemTool;
import org.powernukkitx.math.BlockFace;
import org.powernukkitx.nbt.tag.CompoundTag;
import org.powernukkitx.nbt.tag.ListTag;
import org.powernukkitx.nbt.tag.StringTag;
import org.powernukkitx.nbt.tag.Tag;
import org.cloudburstmc.protocol.bedrock.packet.ContainerSetDataPacket;
import org.jetbrains.annotations.NotNull;

public class BlockBrewingStand extends BlockTransparent implements BlockEntityHolder<BlockEntityBrewingStand> {

    public static final BlockProperties PROPERTIES = new BlockProperties(BREWING_STAND, CommonBlockProperties.BREWING_STAND_SLOT_A_BIT, CommonBlockProperties.BREWING_STAND_SLOT_B_BIT, CommonBlockProperties.BREWING_STAND_SLOT_C_BIT);
    public static final BlockDefinition DEFINITION = TRANSPARENT.toBuilder()
            .hardness(0.5f)
            .resistance(2.5f)
            .toolType(ItemTool.TYPE_PICKAXE)
            .toolTier(ItemTool.TIER_WOODEN)
            .lightEmission(1)
            .canBeActivated(true)
            .canHarvestWithHand(false)
            .isSolid(false)
            .hasComparatorInputOverride(true)
            .waterloggingLevel(1)
            .build();

    @Override
    @NotNull
    public BlockProperties getProperties() {
        return PROPERTIES;
    }

    public BlockBrewingStand() {
        this(PROPERTIES.getDefaultState());
    }

    public BlockBrewingStand(BlockState blockstate) {
        super(blockstate, DEFINITION);
    }

    @Override
    public String getName() {
        return "Brewing Stand";
    }

    
    @Override
    public boolean place(@NotNull Item item, @NotNull Block block, @NotNull Block target, @NotNull BlockFace face, double fx, double fy, double fz, Player player) {

        CompoundTag nbt = new CompoundTag();
        if (item.hasCustomName()) {
            nbt.putString("CustomName", item.getCustomName());
        }

        if (item.hasCustomBlockData()) {
            for (var entry : item.getCustomBlockData().getEntrySet()) {
                nbt.put(entry.getKey(), entry.getValue().copy());
            }
        }

        return BlockEntityHolder.setBlockAndCreateEntity(this, false, true, nbt) != null;
    }

    @Override
    public boolean onActivate(@NotNull Item item, Player player, BlockFace blockFace, float fx, float fy, float fz) {
        if (player != null) {
            Item itemInHand = player.getInventory().getItemInMainHand();
            if (player.isSneaking() && !(itemInHand.isTool() || itemInHand.isNull())) {
                return false;
            }
            BlockEntity t = getLevel().getBlockEntity(this);
            BlockEntityBrewingStand brewing;
            if (t instanceof BlockEntityBrewingStand) {
                brewing = (BlockEntityBrewingStand) t;
            } else {
                brewing = this.createBrewingStand();
                if (brewing == null) {
                    return false;
                }
            }

            if (brewing.getNbt().contains("Lock")
                    && brewing.getNbt().get("Lock") instanceof StringTag
                    && !brewing.getNbt().getString("Lock").equals(item.getCustomName())) {
                return false;
            }

            player.addWindow(brewing.getInventory());
            // Without this, the brewing stand starts brewing (visually) once opened.
            if (brewing.brewTime == BlockEntityBrewingStand.MAX_BREW_TIME) {
                final ContainerSetDataPacket pk = new ContainerSetDataPacket();
                pk.setContainerID((byte) player.getWindowId(brewing.getInventory()));
                pk.setId(ContainerSetDataPacket.BREWING_STAND_BREW_TIME);
                pk.setValue(0);
                player.sendPacket(pk);
            }
        }

        return true;
    }

    @Override
    public double getMinX() {
        return this.x + 7 / 16.0;
    }

    @Override
    public double getMinZ() {
        return this.z + 7 / 16.0;
    }

    @Override
    public double getMaxX() {
        return this.x + 1 - 7 / 16.0;
    }

    @Override
    public double getMaxY() {
        return this.y + 1 - 2 / 16.0;
    }

    @Override
    public double getMaxZ() {
        return this.z + 1 - 7 / 16.0;
    }

    
    @Override
    public int getComparatorInputOverride() {
        BlockEntity blockEntity = this.level.getBlockEntity(this);

        if (blockEntity instanceof BlockEntityBrewingStand) {
            return ContainerInventory.calculateRedstone(((BlockEntityBrewingStand) blockEntity).getInventory());
        }

        return super.getComparatorInputOverride();
    }

    
    @Override
    @NotNull
    public Class<? extends BlockEntityBrewingStand> getBlockEntityClass() {
        return BlockEntityBrewingStand.class;
    }

    @Override
    @NotNull
    public String getBlockEntityType() {
        return BlockEntity.BREWING_STAND;
    }

    protected BlockEntityBrewingStand createBrewingStand() {
        return this.createBrewingStand(null);
    }

    protected BlockEntityBrewingStand createBrewingStand(CompoundTag additions) {
        CompoundTag nbt = new CompoundTag().putList("Items", new ListTag<>(Tag.TAG_Compound));
        if (additions != null) {
            for (var entry : additions.getEntrySet()) {
                nbt.put(entry.getKey(), entry.getValue().copy());
            }
        }

        return createBlockEntity(nbt);
    }
}
