package org.powernukkitx.block;

import org.powernukkitx.block.definition.BlockDefinition;

import org.powernukkitx.Player;
import org.powernukkitx.inventory.HumanInventory;
import org.powernukkitx.item.Item;
import org.powernukkitx.item.ItemBlock;
import org.powernukkitx.item.ItemTool;
import org.powernukkitx.level.Sound;
import org.powernukkitx.math.BlockFace;
import org.jetbrains.annotations.NotNull;

/**
 * @author MagicDroidX (Nukkit Project), kvetinac97
 */
public class BlockDirt extends BlockSolid implements Natural {
    public static final BlockProperties PROPERTIES = new BlockProperties(DIRT);
    public static final BlockDefinition DEFINITION = SOLID.toBuilder()
            .hardness(0.5f)
            .resistance(0.5f)
            .toolType(ItemTool.TYPE_SHOVEL)
            .canBeActivated(true)
            .build();

    public BlockDirt() {
        this(PROPERTIES.getDefaultState());
    }

    public BlockDirt(BlockState blockState) {
        super(blockState, DEFINITION);
    }

    public BlockDirt(BlockState blockState, BlockDefinition definition) {
        super(blockState, definition);
    }

    @Override
    @NotNull
    public BlockProperties getProperties() {
        return PROPERTIES;
    }

    
    @Override
    public boolean onActivate(@NotNull Item item, Player player, BlockFace blockFace, float fx, float fy, float fz) {

        if(player != null && item.getId().equals(Item.POTION) && item.getDamage() == 0) { // Water Bottle
            item.useOn(this);
            HumanInventory inventory = player.getInventory();
            Item glassBottle = Item.get(Item.GLASS_BOTTLE);
            if(!player.isCreative()) {
                 inventory.setItemInMainHand(glassBottle);
            } else inventory.addItem(glassBottle);
            this.getLevel().addSound(this, Sound.BOTTLE_EMPTY);
            this.getLevel().setBlock(this, get(MUD));
            return true;
        }

        if (item.isHoe()) {
            if (up().isAir()) {
                item.useOn(this);
                this.getLevel().setBlock(this, get(FARMLAND), true);
                if (player != null) {
                    player.getLevel().addSound(player, Sound.USE_GRASS);
                }
                return true;
            }
        } else if (item.isShovel()) {
            if (up().isAir()) {
                item.useOn(this);
                this.getLevel().setBlock(this, get(GRASS_PATH));
                if (player != null) {
                    player.getLevel().addSound(player, Sound.USE_GRASS);
                }
                return true;
            }
        }
        return false;
    }

    @Override
    public Item[] getDrops(Item item) {
        return new Item[]{this.toItem()};
    }

    @Override
    public Item toItem() {
        return new ItemBlock(this);
    }
}
