package org.powernukkitx.block;

import org.powernukkitx.block.definition.BlockDefinition;

import org.powernukkitx.Player;
import org.powernukkitx.item.Item;
import org.powernukkitx.item.ItemID;
import org.powernukkitx.item.ItemTool;
import org.powernukkitx.item.enchantment.Enchantment;
import org.powernukkitx.level.Level;
import org.powernukkitx.level.particle.BoneMealParticle;
import org.powernukkitx.math.BlockFace;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

public class BlockFern extends BlockFlowable implements BlockFlowerPot.FlowerPotBlock, Supportable {
    public static final BlockProperties PROPERTIES = new BlockProperties(FERN);
    public static final BlockDefinition DEFINITION = FLOWABLE.toBuilder()
            .toolType(ItemTool.TYPE_SHEARS)
            .burnChance(60)
            .burnAbility(100)
            .canBeReplaced(true)
            .isFertilizable(true)
            .build();

    @Override
    @NotNull
    public BlockProperties getProperties() {
        return PROPERTIES;
    }

    public BlockFern() {
        this(PROPERTIES.getDefaultState());
    }

    public BlockFern(BlockState blockstate) {
        super(blockstate, DEFINITION);
    }

    
    @Override
    public int getSnowloggingLevel() {
        return 1;
    }

    @Override
    public boolean place(@NotNull Item item, @NotNull Block block, @NotNull Block target, @NotNull BlockFace face, double fx, double fy, double fz, Player player) {
        if (isSupportDirt(down())) {
            this.getLevel().setBlock(block, this, true);
            return true;
        }
        return false;
    }

    @Override
    public int onUpdate(int type) {
        if (type == Level.BLOCK_UPDATE_NORMAL) {
            if (!isSupportDirt(down(1, 0))) {
                this.getLevel().useBreakOn(this);
                return Level.BLOCK_UPDATE_NORMAL;
            }
        }
        return 0;
    }

    @Override
    public boolean onActivate(@NotNull Item item, Player player, BlockFace blockFace, float fx, float fy, float fz) {
        if (item.isFertilizer()) {
            Block up = this.up();

            if (up.isAir()) {
                if (player != null && !player.isCreative()) {
                    item.count--;
                }

                BlockLargeFern doublePlant = new BlockLargeFern();
                doublePlant.setTopHalf(false);

                this.level.addParticle(new BoneMealParticle(this));
                this.level.setBlock(this, doublePlant, true, false);

                doublePlant.setTopHalf(true);
                this.level.setBlock(up, doublePlant, true);
                this.level.updateAround(this);
            }

            return true;
        }

        return false;
    }

    @Override
    public Item[] getDrops(Item item) {
        // https://minecraft.wiki/w/Fortune#Grass_and_ferns
        List<Item> drops = new ArrayList<>(2);
        if (item.isShears()) {
            drops.add(toItem());
        }

        ThreadLocalRandom random = ThreadLocalRandom.current();
        if (random.nextInt(8) == 0) {
            Enchantment fortune = item.getEnchantment(Enchantment.ID_FORTUNE_DIGGING);
            int fortuneLevel = fortune != null ? fortune.getLevel() : 0;
            int amount = fortuneLevel == 0 ? 1 : 1 + random.nextInt(fortuneLevel * 2);
            drops.add(Item.get(ItemID.WHEAT_SEEDS, 0, amount));
        }

        return drops.toArray(Item.EMPTY_ARRAY);
    }

    }